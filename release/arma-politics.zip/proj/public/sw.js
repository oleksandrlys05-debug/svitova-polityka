// «Світова політика»: сервіс-воркер для встановлення як застосунку. Гра завжди береться з сервера (без застарілого кешу);
// кешується лише сторінка «немає з'єднання».
const OFF = 'offline-v1';
const PAGE = `<!doctype html><html lang="uk"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Світова політика</title>
<body style="margin:0;font:16px system-ui,sans-serif;background:#0c0a11;color:#ece8f4;display:grid;place-items:center;height:100vh;text-align:center;padding:20px">
<div><h2>Немає з’єднання з сервером гри</h2><p style="color:#9d95ae">Перевірте інтернет. Можливо, хост вимкнув сервер або посилання змінилося — попросіть нове.</p>
<button onclick="location.reload()" style="padding:10px 18px;border-radius:12px;border:0;background:#a855f7;color:#fff;font-size:16px">Спробувати ще раз</button></div></body></html>`;
self.addEventListener('install', (e) => { self.skipWaiting(); });
self.addEventListener('activate', (e) => { e.waitUntil(self.clients.claim()); });
self.addEventListener('fetch', (e) => {
  const r = e.request; if (r.method !== 'GET' || r.mode !== 'navigate') return;
  e.respondWith(fetch(r).catch(() => new Response(PAGE, { headers: { 'Content-Type': 'text/html; charset=utf-8' } })));
});
