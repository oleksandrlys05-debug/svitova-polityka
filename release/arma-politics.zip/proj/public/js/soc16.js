// Оновлення 16: міста (класи, робоча сила, управління, закони), релігія, області, форма правління, прапори, шари мапи
const genFlagUrl = (seed) => `/api/flag?id=${-Math.abs(seed || 1)}`;
const flagImg = (src, h = 18) => `<img src="${src}" alt="" style="height:${h}px;width:${Math.round(h * 1.5)}px;vertical-align:-3px;border:1px solid #8886;border-radius:2px;object-fit:cover">`;
const BICO = { hospital: 'hospital', school: 'school', univ: 'school', police: 'police', stadium: 'stadium', fort: 'fort', airport: 'airbase', townhall: 'capital', market: 'coin', housing: 'city', warehouse: 'depot', power: 'civ', temple: 'crown' };

// ---------- Міста ----------
async function renderCities(b) {
  const [D, RS, PR] = await Promise.all([api('cities/state'), api('religion/state').catch(() => null), api('protests').catch(() => null)]), defs = D.defs, REL = RS ? RS.REL : {};
  const moodC = (m) => (m >= 60 ? 'pos' : m < 30 ? 'neg' : '');
  const pct = (v, c) => `<div class="bar" style="height:8px;margin:2px 0"><i style="width:${Math.min(100, v)}%;background:${c}"></i></div>`;
  const city = (c) => { const m = c.m || {}, mx = (RS && RS.cities.find((x) => x.id === c.id) || {}).mix || {}, relTop = Object.entries(mx).sort((a, b2) => b2[1] - a[1]);
    return `<div class="card pad"><div class="row" style="flex-wrap:wrap;gap:8px"><h3 class="grow" style="margin:0">${flagImg(genFlagUrl(c.fseed), 20)} ${ico(c.capital ? 'capital' : 'city', 24)} ${esc(c.name)} <span class="muted" style="font-size:14px">рівень ${c.level} · ${exact(c.pop)} осіб${c.capital ? ' · столиця' : ''}${c.prov ? ` · область «${esc(c.prov)}»` : ''}</span></h3>
      <span>Настрій <b class="${moodC(c.mood)}">${c.mood}</b> → ${c.moodTarget}</span>${c.repairCost ? `<button class="ghost sm" data-crep="${c.id}" title="Найгірший стан будівель: ${c.cond}%. Зношені будівлі дають менше настрою.">Ремонт ${short(c.repairCost)} $</button>` : ''}<button class="ghost sm" data-cwhy="${c.id}" title="Що саме впливає на настрій цього міста">Чому?</button>${c.riot ? ` <b class="neg">БУНТ (${c.riot} д.)</b>` : ''}${c.siege ? ` <b class="neg">ОБЛОГА ${c.siege} д.</b>` : ''}${c.occupied ? ' <b class="neg">окуповане</b>' : ''}<button class="ghost sm" data-cflag="${c.id}" title="Згенерувати місту новий прапор">Прапор ↻</button></div>
    <div class="bar" style="margin:6px 0;max-width:300px"><i style="width:${c.mood}%;background:${c.mood >= 60 ? '#22c55e' : c.mood >= 30 ? '#eab308' : '#ef4444'}"></i></div>
    ${c.distPen ? `<div class="hint" style="margin:0 0 6px">Далеко від центру управління: −${c.distPen} настрою. Створіть область із центром ближче (Суспільство → Області).</div>` : ''}
    ${wfPanel(c, defs)}
    <div class="grid g2" style="gap:12px"><div>
      <label style="margin:0">Населення за класами</label>
      <div style="font-size:13px">Робітники ${m.classes ? m.classes.w : 0}%${pct(m.classes ? m.classes.w : 0, '#94a3b8')}Освічені ${m.classes ? m.classes.e : 0}%${pct(m.classes ? m.classes.e : 0, '#60a5fa')}Заможні ${m.classes ? m.classes.r : 0}%${pct((m.classes ? m.classes.r : 0) * 5, '#facc15')}</div>
      <label style="margin:8px 0 0">Податки за класами, %</label>
      <div class="row" style="gap:6px;flex-wrap:wrap;font-size:13px">${[['w', 'Робітники'], ['e', 'Освічені'], ['r', 'Заможні']].map(([k, t]) => `<span>${t} <input type="number" min="0" max="40" step="1" value="${(m.tax || {})[k] || 0}" data-ct="${c.id}:${k}" style="width:58px"></span>`).join('')}<button class="sm" data-ctapply="${c.id}">Застосувати</button></div>
      <div class="muted" style="font-size:13px">Дохід: <b>${exact(c.income)} $/добу</b>. Податок робітників б’є по настрою найсильніше, заможних — найслабше (але їх мало).</div>
      <label style="margin:8px 0 0">Міські закони</label><div class="row" style="gap:4px;flex-wrap:wrap">${Object.entries(D.laws || {}).map(([k, l]) => `<button class="${(m.laws || {})[k] ? '' : 'ghost'} sm" data-claw="${c.id}:${k}" title="${esc(l.d)}">${esc(l.n)}${(m.laws || {})[k] ? ' ✓' : ''}</button>`).join('')}</div>
      <label style="margin:8px 0 0">Губернатор</label><select data-cgov="${c.id}"><option value="">${c.gov ? '— зняти губернатора —' : '— немає (−3 настрою, −25% податків) —'}</option>${c.gov ? `<option value="${c.gov.id}" selected>${esc(c.gov.name)} (вміння ${c.gov.skill}; ${esc(c.gov.traits.join(', '))})</option>` : ''}${D.free.map((p) => `<option value="${p.id}">${esc(p.name)} (вміння ${p.skill}; ${esc(p.traits.join(', '))})</option>`).join('')}</select>
      ${relTop.length ? `<label style="margin:8px 0 0">Віра містян</label><div style="font-size:13px">${relTop.filter(([, v]) => v >= 0.02).map(([k, v]) => `<span class="chip"><span class="sw" style="background:${(REL[k] || {}).color}"></span>${esc((REL[k] || {}).n || k)} ${Math.round(v * 100)}%</span>`).join(' ')}</div>` : ''}
      ${c.capital ? '' : `<button class="ghost sm" data-ccap="${c.id}" style="margin-top:8px" ${D.capCd ? 'disabled' : ''}>Перенести столицю сюди (${short(D.capCost)} $${D.capCd ? `, через ${D.capCd} д.` : ''})</button>`}</div>
    <div><label style="margin:0">Міські будівлі <span class="muted" style="font-weight:normal">(працівники · очки управління)</span></label>${Object.entries(defs).map(([k, d]) => { const s = c.bld[k] || {}, max = d.max || 1; const tRel = k === 'temple' && m.temple ? (m.temple.rel === 'all' ? 'для всіх вір' : (REL[m.temple.rel] || {}).n) : '';
      const btn = !s.building && (s.lv || 0) < max ? (k === 'temple' && !s.lv ? `<select data-ctrel="${c.id}" style="width:auto;font-size:12px"><option value="">храм для…</option><option value="all">усіх вір (+60% ціни)</option>${Object.entries(REL).map(([rk, r]) => `<option value="${rk}">${esc(r.n)}</option>`).join('')}</select>` : `<button class="ghost sm" ${d.req && !(c.bld[d.req] && c.bld[d.req].lv && !c.bld[d.req].building) ? `disabled title="Спочатку: ${esc(defs[d.req].n)}"` : ''} data-cb="${c.id}:${k}" title="${esc(d.d)} Утримання ${exact(d.upk)} $/добу.">${s.lv ? 'Покращити' : 'Збудувати'} ${short(d.price * ((s.lv || 0) + 1))} $</button>`) : '';
      return `<div class="row" style="gap:6px;margin:3px 0"><span class="grow" title="${esc(d.d)}">${ico(BICO[k] || 'city', 18)} ${d.n} <span class="muted" style="font-size:12px">${d.work ? exact(d.work) : ''}·${d.adm == null ? '' : d.adm}</span>${s.building ? ` <span class="muted">будується${max > 1 ? ' рів. ' + s.lv : ''}, ще ${s.building} д.</span>` : s.lv ? ` <b>${max > 1 ? 'рів. ' + s.lv : '✓'}</b>${tRel ? ` <span class="muted">(${esc(tRel)})</span>` : ''}` : ''}</span>${btn}${s.lv && !s.building ? `<button class="ghost sm" data-cdem="${c.id}:${k}" title="Знести один рівень (звільнить працівників і очки управління)">✕</button>` : ''}</div>`; }).join('')}</div></div></div>`; };
  b.innerHTML = `<div class="card pad"><h3>Міста</h3><p class="hint" style="margin-top:0">Місто — це люди трьох класів (робітники, освічені, заможні). Кожна будівля потребує <b>працівників</b> із вільної робочої сили міста і <b>очок управління</b>; якщо їх бракує, будівлі працюють гірше. Очки дають рівень міста, ратуша й губернатор. Податки ставите окремо для кожного класу, закони міняють настрій і порядок. Далекі від столиці чи центру області міста менш задоволені.</p>
    <div>Міські податки разом: <b>${exact(D.cityTax)} $/добу</b>${D.immig ? ` · прийнято мігрантів: <b>${exact(D.immig)}</b>` : ''}</div>
    <div class="row" style="margin-top:8px;gap:6px"><span>Мігранти й біженці з інших держав:</span><button class="${D.migr === 'open' ? '' : 'ghost'} sm" data-migr="open">Приймати</button><button class="${D.migr === 'closed' ? '' : 'ghost'} sm" data-migr="closed">Кордони закрито</button></div></div>
    ${window.protestsHtml ? protestsHtml(PR) : ''}
    ${D.cities.map(city).join('') || '<p class="muted">Міст немає. Збудуйте місто (Виробництво → Міста).</p>'}`;
  const re = () => renderMe();
  b.querySelectorAll('[data-ctapply]').forEach((x) => x.onclick = () => { const id = +x.dataset.ctapply, tax = {}; b.querySelectorAll(`[data-ct^="${id}:"]`).forEach((i) => { tax[i.dataset.ct.split(':')[1]] = +i.value; }); act(async () => { await api('cities/mgmt', { id, tax }); re(); }, 'Податки змінено'); });
  b.querySelectorAll('[data-claw]').forEach((x) => x.onclick = () => { const [id, law] = x.dataset.claw.split(':'); act(async () => { await api('cities/mgmt', { id: +id, law }); re(); }); });
  b.querySelectorAll('[data-cdem]').forEach((x) => x.onclick = () => { const [id, kind] = x.dataset.cdem.split(':'); if (confirm('Знести один рівень будівлі? Гроші не повертаються.')) act(async () => { await api('cities/demolish', { id: +id, kind }); re(); }); });
  b.querySelectorAll('[data-ctrel]').forEach((x) => x.onchange = () => { if (!x.value) return; act(async () => { await api('cities/temple', { id: +x.dataset.ctrel, rel: x.value }); await refreshMe(); re(); }, 'Будівництво храму почалось'); });
  if (window.bindProtests) bindProtests(b, re);
  b.querySelectorAll('[data-crep]').forEach((x) => x.onclick = () => act(async () => { const r = await api('cities/repair', { id: +x.dataset.crep }); toast(r.message); await refreshMe(); re(); }));
  if (me.country && (me.country.stats.oppMode || 0) > (me.world ? me.world.day : 0)) { const ob = document.createElement('div'); ob.className = 'card pad'; ob.style.borderColor = '#f97316'; ob.innerHTML = `<h3 style="margin-top:0">Ви в опозиції</h3><p class="muted" style="margin-top:0">Уряд формує опозиція ще ${Math.ceil(me.country.stats.oppMode - me.world.day)} діб. Протести прихильників наближають повернення влади.</p><div class="row" style="gap:6px"><select id="opc" style="width:auto">${D.cities.map((c) => `<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select><button id="opgo">Вивести прихильників на вулиці (10 млн $)</button></div>`; b.prepend(ob); $('#opgo').onclick = () => act(async () => { const r = await api('opp/protest', { city: +$('#opc').value }); toast(r.message); await refreshMe(); re(); }); }
  b.querySelectorAll('[data-cwhy]').forEach((x) => x.onclick = () => cityWhyModal(+x.dataset.cwhy));
  b.querySelectorAll('[data-cflag]').forEach((x) => x.onclick = () => act(async () => { await api('cities/flag', { id: +x.dataset.cflag }); re(); }));
  b.querySelectorAll('[data-cgov]').forEach((x) => x.onchange = () => { const fid = +x.dataset.cgov, cur = D.cities.find((c) => c.id === fid).gov; act(async () => { if (x.value) await api('court/appoint', { id: +x.value, post: 'gov:' + fid }); else if (cur) await api('court/appoint', { id: cur.id, post: '' }); re(); }, 'Губернатора змінено'); });
  b.querySelectorAll('[data-cb]').forEach((x) => x.onclick = () => { const [id, k] = x.dataset.cb.split(':'); act(async () => { await api('cities/build', { id: +id, kind: k }); await refreshMe(); re(); }, 'Будівництво почалось'); });
  b.querySelectorAll('[data-ccap]').forEach((x) => x.onclick = () => { if (confirm('Перенести столицю? Коштує грошей і −5 стабільності; повторно — через 60 діб.')) act(async () => { await api('cities/capital', { id: +x.dataset.ccap }); await refreshMe(); re(); }, 'Столицю перенесено'); });
  b.querySelectorAll('[data-migr]').forEach((x) => x.onclick = () => act(async () => { await api('cities/migration', { policy: x.dataset.migr }); re(); }));
}

// ---------- Релігія ----------
async function renderRel(b) {
  const D = await api('religion/state'), R0 = D.REL, me0 = R0[D.rel] || {};
  const fx = (f) => Object.entries(f || {}).map(([k, v]) => `${k}: ${v > 0 ? '+' : ''}${Math.abs(v) < 1 ? Math.round(v * 100) + '%' : v}`).join(', ');
  b.innerHTML = `<div class="card pad"><h3><span class="sw" style="background:${me0.color}"></span>Державна віра: ${esc(me0.n || '—')}</h3>
    <div class="muted" style="font-size:13px">${esc(me0.type || '')} · бог: ${esc(me0.god || '')} · символ: ${esc(me0.sym || '')} · храм: ${esc(me0.temple || '')} · головне: ${esc(me0.tenet || '')}</div>
    <p style="margin:6px 0">${esc(me0.d || '')}</p><div>Єдність віри в державі: <b>${D.unity}%</b> населення сповідує державну віру.</div>
    <label style="margin:10px 0 2px">Політика щодо віри</label><div class="row" style="gap:4px;flex-wrap:wrap">${Object.entries(D.POL).map(([k, p]) => `<button class="${D.pol === k ? '' : 'ghost'} sm" data-rpol="${k}" title="${esc(p.d)}">${esc(p.n)}</button>`).join('')}</div>
    <div class="hint">${esc((D.POL[D.pol] || {}).d || '')}</div>
    <label style="margin:10px 0 2px">Змінити державну віру <span class="muted">(−12 стабільності, раз на 120 діб${D.switchCd ? `; ще ${D.switchCd} д.` : ''})</span></label><div class="row" style="gap:4px;flex-wrap:wrap">${Object.entries(R0).filter(([k]) => k !== D.rel).map(([k, r]) => `<button class="ghost sm" data-rrel="${k}" ${D.switchCd ? 'disabled' : ''}><span class="sw" style="background:${r.color}"></span>${esc(r.n)}</button>`).join('')}</div></div>
    <div class="card pad"><h3>Віри у вашій державі</h3>${Object.entries(D.shares).sort((a, b2) => b2[1] - a[1]).map(([k, v]) => `<div class="row" style="gap:6px"><span style="width:220px"><span class="sw" style="background:${(R0[k] || {}).color}"></span>${esc((R0[k] || {}).n || k)}</span><div class="bar grow" style="height:10px"><i style="width:${v}%;background:${(R0[k] || {}).color}"></i></div><b style="width:52px;text-align:right">${v}%</b></div>`).join('')}</div>
    <div class="card pad"><h3>Усі віри світу</h3>${Object.entries(R0).map(([k, r]) => `<div style="margin:6px 0"><b><span class="sw" style="background:${r.color}"></span>${esc(r.n)}</b> <span class="muted">${esc(r.type)}</span><div style="font-size:13px">${esc(r.d)}${r.fx ? ` <span class="muted">(${esc(fx(r.fx))})</span>` : ''}</div>
      <div style="font-size:13px">Святі міста: ${(D.holy[k] || []).map((h) => `<b>${esc(h.name || '?')}</b> <span class="muted">(${esc(h.owner)})</span>`).join(', ') || '<span class="muted">немає</span>'} · держав із цією вірою: ${D.world.filter((w) => w.rel === k).length}</div></div>`).join('')}
      <p class="hint">Свої святі міста дають паломників (гроші) і стабільність. Якщо святе місто вашої віри в чужих руках — це законний привід для війни. Храм для однієї віри дешевший і сильніше радує її вірян, храм для всіх — дорожчий, але мирить громади.</p></div>
    <div class="card pad"><h3>Місіонери</h3><p class="hint" style="margin-top:0">Місія зсуває віру міста до вашої державної. У чужих містах коштує ще й очки дипломатії та псує відносини.</p>${D.cities.map((c) => { const top2 = Object.entries(c.mix).sort((a, b2) => b2[1] - a[1])[0]; return `<div class="row" style="gap:6px;margin:3px 0"><span class="grow">${esc(c.name || 'Місто')} ${top2 ? `<span class="muted">— переважно ${esc((R0[top2[0]] || {}).n || '')} ${Math.round(top2[1] * 100)}%, ваша віра ${Math.round((c.mix[D.rel] || 0) * 100)}%</span>` : ''}</span><button class="ghost sm" data-rmis="${c.id}">Відправити місіонерів</button></div>`; }).join('')}</div>`;
  const re = () => renderMe();
  b.querySelectorAll('[data-rpol]').forEach((x) => x.onclick = () => act(async () => { await api('religion/policy', { pol: x.dataset.rpol }); re(); }, 'Політику змінено'));
  b.querySelectorAll('[data-rrel]').forEach((x) => x.onclick = () => { if (confirm('Змінити державну віру? −12 стабільності, повторно лише через 120 діб.')) act(async () => { await api('religion/policy', { rel: x.dataset.rrel }); re(); }); });
  b.querySelectorAll('[data-rmis]').forEach((x) => x.onclick = () => act(async () => { const r = await api('religion/mission', { city: +x.dataset.rmis }); toast(r.message); await refreshMe(); re(); }));
}

// ---------- Області ----------
async function renderProv(b) {
  const D = await api('prov/state');
  b.innerHTML = `<div class="card pad"><h3>Області</h3><p class="hint" style="margin-top:0">Ви самі креслите області пензликом по своїй території (або не креслите зовсім). У кожній області має бути місто — воно стає її центром. Міста, далекі від столиці чи центру своєї області, менш задоволені й корупція вища; область «наближає» управління. Статус: <b>пряме правління</b>, <b>автономія</b> (менше податків, але спокійніше) або <b>особлива економічна зона</b> (більше податків, менше стабільності). Створення: ${short(D.cost)} $, утримання ${short(D.upk)} $/добу за область. Максимум ${D.max}.</p>
    <button data-pnew>+ Нова область (намалювати на мапі)</button></div>
    ${D.provinces.map((p) => `<div class="card pad"><div class="row" style="gap:8px;flex-wrap:wrap"><h3 class="grow" style="margin:0">${flagImg(genFlagUrl(p.flag), 20)} <span class="sw" style="background:${p.color}"></span>${esc(p.name)} <span class="muted" style="font-size:14px">${p.cells} кл. · ${exact(p.pop)} осіб · центр: ${esc(p.centerName || '—')}</span></h3>
      <button class="ghost sm" data-pren="${p.id}">Перейменувати</button><button class="ghost sm" data-pflag="${p.id}">Прапор ↻</button><button class="ghost sm" data-padd="${p.id}">Домалювати</button><button class="ghost sm" data-prem="${p.id}">Стерти частину</button><button class="danger sm" data-pdel="${p.id}">Розпустити</button></div>
      <div class="row" style="gap:6px;margin-top:6px;flex-wrap:wrap"><span>Статус:</span>${Object.entries(D.STATUS).map(([k, s]) => `<button class="${p.status === k ? '' : 'ghost'} sm" data-pst="${p.id}:${k}" title="${esc(s.d)}">${esc(s.n)}</button>`).join('')}
      <span style="margin-left:10px">Центр:</span><select data-pctr="${p.id}" style="width:auto">${p.cities.map((c) => `<option value="${c.id}" ${c.id === p.center ? 'selected' : ''}>${esc(c.name || 'Місто')}</option>`).join('')}</select></div>
      <div class="muted" style="font-size:13px;margin-top:4px">Міста: ${p.cities.map((c) => esc(c.name || '?')).join(', ') || '—'}</div></div>`).join('') || '<p class="muted">Областей ще немає — уся країна керується зі столиці.</p>'}
    ${D.far.length ? `<div class="card pad"><h3>Міста, далекі від центру управління</h3>${D.far.map((f) => `<div>${esc(f.name || '?')} — <b class="neg">−${f.pen}</b> настрою${f.prov ? ` <span class="muted">(область «${esc(f.prov)}»)</span>` : ''}</div>`).join('')}</div>` : ''}`;
  const re = () => renderMe();
  const draw = (m) => { showTab('map'); setLayer('provinces').then(() => setMode({ kind: 'provdraw', ...m })); };
  b.querySelector('[data-pnew]').onclick = async () => { const name = await askText('Назва нової області:'); if (name && name.trim()) draw({ name: name.trim(), op: 'create' }); };
  b.querySelectorAll('[data-padd]').forEach((x) => x.onclick = () => draw({ pid: +x.dataset.padd, op: 'add' }));
  b.querySelectorAll('[data-prem]').forEach((x) => x.onclick = () => draw({ pid: +x.dataset.prem, op: 'remove' }));
  b.querySelectorAll('[data-pren]').forEach((x) => x.onclick = async () => { const n = await askText('Нова назва:'); if (n) act(async () => { await api('prov/edit', { id: +x.dataset.pren, name: n }); re(); }); });
  b.querySelectorAll('[data-pflag]').forEach((x) => x.onclick = () => act(async () => { await api('prov/edit', { id: +x.dataset.pflag, flag: 1 }); re(); }));
  b.querySelectorAll('[data-pdel]').forEach((x) => x.onclick = () => { if (confirm('Розпустити область? Гроші не повертаються.')) act(async () => { await api('prov/delete', { id: +x.dataset.pdel }); re(); }); });
  b.querySelectorAll('[data-pst]').forEach((x) => x.onclick = () => { const [id, status] = x.dataset.pst.split(':'); act(async () => { await api('prov/edit', { id: +id, status }); re(); }, 'Статус змінено (−2 стабільності)'); });
  b.querySelectorAll('[data-pctr]').forEach((x) => x.onchange = () => act(async () => { await api('prov/edit', { id: +x.dataset.pctr, center: +x.value }); re(); }));
}
async function provCommit() {
  if (!brush.size) return toast('Спочатку намалюй клітинки', true); const cells = [...brush], m = mode;
  act(async () => { if (m.op === 'create') await api('prov/create', { name: m.name, cells }); else await api('prov/edit', { id: m.pid, [m.op === 'remove' ? 'remove' : 'add']: cells });
    toast(m.op === 'create' ? 'Область створено' : 'Межі області змінено'); setMode({ kind: 'idle' }); await refreshMe(); await loadLayer16('provinces'); repaint(); drawMap(); legend(); });
}
{ const wb = window.warBanner; window.warBanner = function (m, b) {
    if (m.kind === 'provdraw') { brush.clear(); previewBad = []; b.innerHTML = `<span>${m.op === 'create' ? `Нова область «${esc(m.name)}»: малюй пензликом по своїй території (обов’язково захопи хоча б одне місто)` : m.op === 'remove' ? 'Стирання: малюй по клітинках, які треба вилучити з області' : 'Домальовування: малюй по своїй території'} (Shift — стирати, права кнопка — рух мапи). Пензель: <input type="range" id="bsz" min="1" max="30" value="${brushR}" style="width:90px"> <b id="bannerCost"></b></span><button id="bok">Готово</button><button class="ghost" id="bclr">Очистити</button><button id="bcancel">Скасувати</button>`;
      b.classList.remove('hidden'); $('#bsz').oninput = (e) => { brushR = +e.target.value; drawMap(); }; $('#bclr').onclick = () => { brush.clear(); atCalc(); }; $('#bok').onclick = provCommit; atCalc(); return true; }
    return wb ? wb(m, b) : false; }; }

// ---------- Форма правління ----------
async function renderGov(b) {
  const D = await api('gov/state');
  b.innerHTML = `<div class="card pad"><h3>Форма правління: ${esc(D.FORMS[D.form].n)}</h3><p class="hint" style="margin-top:0">Форма правління визначає, чи бувають вибори, і дає власні бонуси. Зміна: −15 стабільності, −10 підтримки влади, не частіше ніж раз на 180 діб${D.cd ? ` (ще ${D.cd} д.)` : ''}.</p>
    ${Object.entries(D.FORMS).map(([k, f]) => `<div class="card pad" style="margin:6px 0;${k === D.form ? 'border-color:var(--accent)' : ''}"><div class="row"><b class="grow">${esc(f.n)}${k === D.form ? ' ✓' : ''}</b>${k === D.form ? '' : `<button class="ghost sm" data-gf="${k}" ${D.cd ? 'disabled' : ''}>Перейти</button>`}</div><div style="font-size:13px">${esc(f.d)}</div><div class="muted" style="font-size:12px">${f.elect ? 'Вибори є' : 'Виборів немає'}</div></div>`).join('')}</div>`;
  b.querySelectorAll('[data-gf]').forEach((x) => x.onclick = () => { if (confirm('Змінити форму правління? −15 стабільності.')) act(async () => { await api('gov/form', { form: x.dataset.gf }); await refreshMe(); renderMe(); }, 'Форму правління змінено'); });
}

// ---------- шари мапи: релігії й області ----------
let REL16 = null, PROV16 = null, provIdx16 = null;
async function loadLayer16(l) {
  if (l === 'religion') REL16 = await api('map/religions').catch(() => null);
  if (l === 'provinces') { PROV16 = (await api('map/provinces').catch(() => ({ provinces: [] }))).provinces; if (land) { provIdx16 = new Int32Array(land.gw * land.gh); for (const p of PROV16) for (const [s, n] of p.runs) for (let i = s; i < s + n; i++) provIdx16[i] = p.id; } }
}
function paintLayer16(img, l) {
  if (l === 'religion' && REL16) { const cache = {}; for (let i = 0; i < owners.length; i++) { const id = owners[i]; if (!id) continue; const r = REL16.countries[id], col = cache[id] || (cache[id] = hexRgb((REL16.REL[r] || {}).color || '#888888')); img.data.set([col[0], col[1], col[2], 255], i * 4); } return true; }
  if (l === 'provinces' && PROV16 && provIdx16) { const pc = {}, cc = {}; for (const p of PROV16) pc[p.id] = hexRgb(p.color); for (let i = 0; i < owners.length; i++) { const id = owners[i]; if (!id) continue; const p = provIdx16[i]; let col; if (p && pc[p]) { const k = cc[id] || (cc[id] = hexRgb((countries[id] || {}).color || '#888888')); col = pc[p].map((v, j) => Math.round(v * 0.6 + k[j] * 0.4)); } else col = cc['d' + id] || (cc['d' + id] = hexRgb(mixDark((countries[id] || {}).color || '#888888', 0.55))); img.data.set([col[0], col[1], col[2], 255], i * 4); } return true; }
  return false;
}
function drawLayer16(C) {
  if (layer === 'religion' && REL16) { cx.save(); for (const c of REL16.cities) { const r = REL16.REL[c.rel]; if (!r) continue; cx.fillStyle = r.color; cx.strokeStyle = '#000a'; cx.lineWidth = 1 / view.s; const rad = Math.max(2.5 * C, 4 / view.s) * (0.8 + c.level * 0.15); cx.beginPath(); cx.arc((c.x + 0.5) * C, (c.y + 0.5) * C, rad, 0, 7); cx.fill(); cx.stroke(); } cx.restore(); }
  if (layer === 'provinces' && PROV16) { cx.save(); const fs = Math.max(9 / view.s, 3 * C); cx.font = `600 ${fs}px sans-serif`; cx.textAlign = 'center'; cx.lineWidth = fs * 0.2; cx.strokeStyle = 'rgba(0,0,0,.6)'; cx.fillStyle = '#fff';
    for (const p of PROV16) { const x = (p.cx + 0.5) * C, y = (p.cy + 0.5) * C - fs; cx.strokeText(p.name, x, y); cx.fillText(p.name, x, y); } cx.restore(); }
}
function legend16(l) {
  const row = (c, t) => `<div><span class="sw" style="background:${c}"></span>${t}</div>`;
  if (l === 'religion' && REL16) return Object.values(REL16.REL).map((r) => row(r.color, esc(r.n))).join('') + '<div class="muted" style="max-width:220px">Заливка — державна віра; кружки — переважна віра в місті.</div>';
  if (l === 'provinces' && PROV16) return (PROV16.filter((p) => me.country && p.cid === me.country.id).map((p) => row(p.color, esc(p.name))).join('') || '<div class="muted">У вас ще немає областей</div>') + '<div class="muted" style="max-width:220px">Темніше — території без області (керуються зі столиці). Створити: Моя держава → Суспільство → Області.</div>';
  return null;
}

// ---------- головний блок міста: робоча сила й управління ----------
function wfPanel(c, defs) {
  const m = c.m || {}; if (!m.force) return '';
  const rows = Object.entries(c.bld || {}).filter(([k, s]) => defs[k] && s.lv && !s.building).map(([k, s]) => ({ k, n: defs[k].n, lv: s.lv, work: (defs[k].work || 0) * s.lv, adm: (defs[k].adm || 0) * s.lv })).sort((a, b) => b.work - a.work);
  const staffC = m.staff >= 95 ? '#22c55e' : m.staff >= 80 ? '#eab308' : '#ef4444', admPct = m.cap ? Math.round(m.adm / m.cap * 100) : 0, admC = admPct <= 85 ? '#22c55e' : admPct <= 100 ? '#eab308' : '#ef4444', effC = m.eff >= 95 ? '#22c55e' : m.eff >= 75 ? '#eab308' : '#ef4444';
  const tile = (t, v, sub, col) => `<div class="wft"><div class="muted">${t}</div><b style="font-size:24px;${col ? `color:${col}` : ''}">${v}</b>${sub ? `<div class="muted" style="font-size:12px">${sub}</div>` : ''}</div>`;
  const cp = m.capParts || {}, adv = [];
  if (m.staff < 95) adv.push(`Бракує працівників: потрібно ${exact(m.jobs)}, а для міських служб вільно лише ${exact(m.avail)}. ${m.mobCut ? `Призов (${m.mobPct}%) забрав ${exact(m.mobCut)} робітників — знизьте його у «Військо → Армія». ` : ''}Знесіть зайві будівлі або чекайте, поки місто виросте (житлові квартали).`);
  if (m.adm > m.cap) adv.push(`Управління перевантажене (${m.adm}/${m.cap}): збудуйте чи покращте ратушу (+8 очок), призначте вмілого губернатора, підніміть рівень міста.`);
  if (!c.gov) adv.push('Немає губернатора: −3 настрою, −25% податків і менше очок управління.');
  if (!adv.length) adv.push('Усе в порядку: будівлі працюють на повну. Можна будувати ще — запас працівників і очок управління видно вище.');
  return `<div class="wfp"><h4 style="margin:0 0 8px">Робоча сила й управління — від цього залежить, як працює все місто</h4>
    <div class="wfg">${tile('Робоча сила', exact(m.force), `${m.mobCut ? `призов забрав ${exact(m.mobCut)}` : 'усі працездатні'}`)}${tile('Вільно для міських служб', exact(m.avail), '15% робочої сили')}${tile('Потрібно будівлям', exact(m.jobs), `${rows.length} будівель`)}
      ${tile('Укомплектованість', m.staff + '%', m.staff < 100 ? 'будівлі недоукомплектовані' : 'повна', staffC)}${tile('Очки управління', `${m.adm}/${m.cap}`, `база ${cp.base || 6} + рівень ${cp.lvl || 0} + ратуша ${cp.th || 0} + губернатор ${cp.gov || 0}`, admC)}${tile('Ефективність будівель', m.eff + '%', 'укомплектованість × управління', effC)}</div>
    <div class="row" style="gap:10px;margin:8px 0 2px;font-size:13px"><span style="width:150px">Працівники</span><div class="bar grow" style="height:12px"><i style="width:${Math.min(100, m.avail ? m.jobs / m.avail * 100 : 0)}%;background:${staffC}"></i></div><span style="width:140px;text-align:right">${exact(m.jobs)} / ${exact(m.avail)}</span></div>
    <div class="row" style="gap:10px;margin:2px 0 8px;font-size:13px"><span style="width:150px">Управління</span><div class="bar grow" style="height:12px"><i style="width:${Math.min(100, admPct)}%;background:${admC}"></i></div><span style="width:140px;text-align:right">${m.adm} / ${m.cap}</span></div>
    ${rows.length ? `<table class="wftab"><tr><th>Будівля</th><th class="r">Рівень</th><th class="r">Працівники</th><th class="r">Очки управління</th></tr>${rows.map((r) => `<tr><td>${ico(BICO[r.k] || 'city', 16)} ${esc(r.n)}</td><td class="r">${r.lv}</td><td class="r">${exact(r.work)}</td><td class="r">${r.adm}</td></tr>`).join('')}</table>` : '<p class="muted" style="margin:4px 0">Міських будівель ще немає — і працівники, і очки управління вільні.</p>'}
    <div class="wfadv">${adv.map((t) => `<div>• ${esc(t)}</div>`).join('')}</div></div>`;
}
