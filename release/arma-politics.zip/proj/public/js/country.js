// Велике вікно держави (як у HOI4 / Songs of Syx): огляд, дипломатія, торгівля, відносини
let cw = null, tradeSt = {};
const CW_TABS = [['overview', 'Огляд'], ['diplo', 'Дипломатія'], ['ties', 'Договори й посольство'], ['trade', 'Торгівля'], ['rel', 'Відносини']];
const RESN = { aluminium: 'Алюміній', chromium: 'Хром', oil: 'Нафта', rubber: 'Гума', steel: 'Сталь', tungsten: 'Вольфрам', fuel: 'Паливо', food: 'Їжа', cotton: 'Бавовна', clothing: 'Одяг', medicine: 'Ліки', goods: 'Товари вжитку', power: 'Електроенергія' };
const emptyBundle = () => ({ money: 0, res: {}, eq: {}, men: 0, cells: 0 });
window.cwClosed = () => { cw = null; window.refreshCwChat = null; };
const cwOpen = () => !!cw;

async function openCountry(id, tab) {
  if (!me || !me.country || id === me.country.id) return;
  cw = { id, tab: tab || (cw && cw.id === id ? cw.tab : 'overview') }; await cwRender(true);
}
async function cwRender(first) {
  if (!cw) return; const id = cw.id;
  let d, O, T, X; try { [d, O, T, X] = await Promise.all([api('intel/country?id=' + id), api('diplo/overview'), api('trade/info?id=' + id), api('diplo/extra')]); } catch (e) { return toast(e.message, true); }
  const sel = O.countries.find((c) => c.id === id); if (!sel) return closeDrawer();
  try { cw.J = sel.war ? null : await api('war/justify/state?target=' + id); } catch { cw.J = null; }
  cw.d = d; cw.O = O; cw.T = T; cw.X = X; cw.sel = sel;
  const html = `<div class="cwhead"><span class="sw" style="background:${esc(d.color)};width:22px;height:22px"></span><div><h2 style="margin:0">${flagTag(countries[id], 22)}${esc(d.name)} ${countries[id] && countries[id].ideology ? `<small class="badge">${IDN[countries[id].ideology]}</small>` : ''} <small class="badge" title="Міжнародна репутація">Репутація ${X.reps[id] == null ? 50 : X.reps[id]}</small></h2><div class="muted">${d.bot ? 'Керує ШІ' : 'Керує: ' + esc(d.owner || '—')} · територія ${exact(d.cells)} кл.${chips(d) ? ' · ' + chips(d) : ''}</div></div>
    <div class="relbox" title="Відносини від −100 до +100"><div class="muted" style="font-size:12px">Відносини</div><b class="${d.relation < 0 ? 'neg' : d.relation > 0 ? 'pos' : ''}" style="font-size:22px">${d.relation > 0 ? '+' : ''}${d.relation}</b></div></div>
    <div class="subtabs">${CW_TABS.map(([k, n]) => `<button data-cwt="${k}" class="${cw.tab === k ? 'on' : ''}">${n}${k === 'diplo' && O.incoming.some((r) => r.from_c === id) ? ' •' : ''}</button>`).join('')}</div><div id="cwbody"></div>`;
  if (first || !drawerOpen('country')) openDrawer(html, 'country'); else drawerBody().innerHTML = html;
  document.querySelectorAll('[data-cwt]').forEach((b) => b.onclick = () => { cw.tab = b.dataset.cwt; cwRender(); });
  const body = $('#cwbody'); ({ overview: cwOverview, diplo: cwDiplo, ties: (x) => window.cwTies && cwTies(x), trade: cwTrade, rel: cwRel }[cw.tab] || window['cwTab_' + cw.tab] || cwOverview)(body);
}
const cwAct = (fn, ok) => act(async () => { await fn(); await refreshMe(); await cwRender(); }, ok);

// ---------- статус: васали й санкції ----------
function cwExtraCard(sel) {
  const X = cw.X, O = cw.O, has = (t, a, b2) => X[t === 'access' ? 'access' : 'guarantees'].some((g) => g.a === a && g.b === b2), pend = (t) => O.outgoing.some((r) => r.to_c === sel.id && r.type === t);
  const me2 = me.country.id, myBloc = O.myBloc && sel.bloc && O.myBloc.id === sel.bloc.id, mine = X.myWars.filter((w) => w.foe !== sel.id), their = (X.theirWars[sel.id] || []);
  const given = X.access.filter((g) => g.a === me2 && g.b === sel.id), got = X.access.filter((g) => g.a === sel.id && g.b === me2), gMine = X.guarantees.filter((g) => g.a === me2 && g.b === sel.id), gTheirs = X.guarantees.filter((g) => g.a === sel.id && g.b === me2);
  return `<div class="card pad"><h3>Військова дипломатія</h3>
    <div class="row" style="gap:8px"><button class="ghost" data-imp="1" title="Дипломатична делегація: ≈ +12 до відносин, коштує 10 очок дипломатії, пауза 3 доби">Покращити відносини (10 ОД)</button>
      ${given.length ? '' : '<button class="ghost" data-grant="1" title="Дозволити їхнім військам заходити на вашу територію без війни">Надати право проходу</button>'}${got.length || pend('access') ? '' : '<button class="ghost" data-rq="access" title="Попросити дозвіл на прохід ваших військ їхньою територією (без нього вхід оголосить війну)">Просити право проходу</button>'}${gMine.length || pend('guarantee') ? '' : '<button class="ghost" data-rq="guarantee" title="Ви гарантуєте їхню незалежність: якщо на них нападуть, ботові-гаранти зазвичай вступають у війну">Гарантувати незалежність</button>'}</div>
    ${[...given.map((g) => `<div class="muted" style="margin-top:6px">Ви дозволили їм прохід. <button class="ghost sm" data-rev="${g.id}">Скасувати</button></div>`), ...got.map(() => '<div class="muted" style="margin-top:6px">Вони дозволили вам прохід.</div>'), ...gMine.map((g) => `<div class="muted" style="margin-top:6px">Ви гарантуєте їхню незалежність. <button class="ghost sm" data-rev="${g.id}">Відмовитись (−репутація)</button></div>`), ...gTheirs.map(() => '<div class="muted" style="margin-top:6px">Вони гарантують вашу незалежність.</div>')].join('')}
    ${myBloc ? `<h4 style="margin:12px 0 4px">Спільні війни (альянс)</h4>
      ${mine.length ? `<div class="row"><select id="wcs" style="width:auto">${mine.map((w) => `<option value="${w.id}">проти ${esc(w.foeName)}</option>`).join('')}</select><button class="sm" data-wc="1">Закликати у війну</button></div>` : '<div class="muted">У вас немає воєн, до яких можна закликати.</div>'}
      ${their.length ? `<div class="row" style="margin-top:6px"><select id="wjs" style="width:auto">${their.map((w) => `<option value="${w.id}">їхня війна проти ${esc(w.foeName)}</option>`).join('')}</select><button class="sm" data-wj="1">Попроситись приєднатися</button></div>` : ''}
      <div class="hint">Союзники самі у війну не вступають: потрібна їхня згода (боти погоджуються залежно від відносин, характеру й сили ворога).</div>` : ''}
    <h4 style="margin:12px 0 4px">${ico('aid', 18)} Військова допомога</h4>
    <div class="row" style="gap:6px"><select id="aidk" style="width:auto"><option value="equip">Техніка й зброя</option><option value="money">Гроші</option><option value="res">Ресурси (паливо, ліки, їжа, одяг)</option><option value="volunteers">Новобранці (бригада назавжди)</option></select>${X.myWars.length ? '<button class="sm" data-aidreq="1">Попросити в них</button>' : ''}<button class="ghost sm" data-aidsend="1">Надати їм</button></div>
    <div class="hint">Боти допомагають союзникам і тим, хто воює з їхніми ворогами. Надати: гроші (4% казни), техніку (10% запасу), ресурси (15%) або новобранців (1500 о/с — назавжди стануть їхньою бригадою). Щоб відправити власні підрозділи тимчасово, як у HoI4, — блок «Добровольці» нижче. Вороги отримувача будуть незадоволені.</div><div id="cwvol"></div></div>`;
}
function cwStatus(sel) {
  const v = sel.vs, k = (x) => (x === 'puppet' ? 'маріонетка' : 'васал'); let h = '';
  if (v && v.role === 'vassal') h += `<div><b>${esc(sel.name)} — ваш ${k(v.kind)}.</b> Кожні 30 діб сплачує вам податок.</div>`;
  else if (v && v.role === 'master') h += `<div class="neg"><b>Ви — ${k(v.kind)} цієї держави.</b> Кожні 30 діб сплачуєте їй податок.</div>`;
  else if (v) h += `<div>Є ${k(v.kind)} держави ${esc(v.masterName)}.</div>`;
  if (sel.sanc.embByMe) h += '<div class="neg"><b>Ви ввели ембарго проти цієї держави.</b></div>'; if (sel.sanc.embOnMe) h += '<div class="neg"><b>Ця держава ввела ембарго проти вас:</b> торгівля з нею неможлива.</div>';
  if (sel.sanc.byMe) h += '<div class="neg">Ви наклали санкції на цю державу.</div>'; if (sel.sanc.onMe) h += '<div class="neg">Ця держава наклала на вас санкції.</div>'; if (sel.sanc.count) h += `<div class="muted">Санкцій проти неї від різних держав: ${sel.sanc.count}.</div>`;
  return h;
}
// ---------- огляд ----------
function cwOverview(b) {
  const d = cw.d, c = countries[d.id];
  b.innerHTML = `<div class="grid g2"><div>${dossierHtml(d, false)}</div><div>
    <div class="card pad"><h3>Швидкі дії</h3><div class="row"><button class="sm" data-t="diplo">Дипломатія</button><button class="sm" data-t="trade">Торгівля</button><button class="ghost sm" data-t="rel">Відносини</button>${c ? '<button class="ghost sm" id="cwmap">Столиця на мапі</button>' : ''}<button class="ghost sm" id="cwintel">Розвідка</button></div>
      <p class="hint">Точність даних залежить від агентів у цій державі. Чим більше агентів, тим точніші цифри; без агентів дані взагалі невідомі.</p></div>
    <div class="card pad"><h3>Ситуація</h3>${d.war ? '<div class="neg"><b>Ви воюєте з цією державою.</b></div>' : '<div>Мирні відносини.</div>'}<div>Угоди: ${d.agreements.length ? d.agreements.map((a) => agt(a.type)[0]).join(', ') : 'немає'}</div>${cwStatus(cw.sel)}</div></div></div>`;
  b.querySelectorAll('[data-t]').forEach((x) => x.onclick = () => { cw.tab = x.dataset.t; cwRender(); });
  const m = $('#cwmap'); if (m) m.onclick = () => { showTab('map'); const r = cv.getBoundingClientRect(), s2 = view.fs * 5, x = c.capital % land.gw, y = (c.capital / land.gw) | 0; view.s = s2; view.x = r.width / 2 + 280 - (x + .5) * land.cell * s2; view.y = r.height / 2 - (y + .5) * land.cell * s2; drawMap(); };
  $('#cwintel').onclick = () => { const id = d.id; closeDrawer(); window.intelSel = id; window.meSub = 'intel'; showTab('me'); };
}

// ---------- дипломатія ----------
function cwDiplo(b) {
  const { sel, O, d } = cw, has = (t) => sel.agreements.some((a) => a.type === t), pend = (t) => O.outgoing.some((r) => r.to_c === sel.id && r.type === t), inc = O.incoming.filter((r) => r.from_c === sel.id);
  const btn = (t, n, hint) => has(t) ? '' : `<button class="ghost" data-rq="${t}" ${pend(t) ? 'disabled' : ''} title="${hint}">${pend(t) ? n + ' (очікує)' : n}</button>`, J = cw.J;
  const justHtml = sel.war || !J ? '' : `<div class="justbox">${J.state === 'ready' ? '<b class="pos">Цілі війни обґрунтовано</b> — війна буде виправданою, мораль і підтримка війни вищі 90 діб.' : J.state === 'progress' ? `<b>Обґрунтування цілей війни</b>: ще ${nf(J.daysLeft, 1)} діб <button class="ghost sm" id="cwjc">Скасувати</button>` : J.justified ? '<span class="muted">У вас уже є законна причина для війни (обґрунтування не потрібне).</span>' : `<button class="ghost" id="cwjust" title="100–150 діб підготовки: після цього війна не вважатиметься агресією">Виправдати війну (${J.dp || 35} ОД)</button>`}</div>`;
  b.innerHTML = `<div class="grid g2"><div>
    ${inc.length ? `<div class="card pad"><h3>Вхідні запити від них</h3>${inc.map((r) => `<div style="margin:6px 0"><b>${esc(r.typeName)}</b>${r.terms && r.terms.enemy && countries[r.terms.enemy] ? ' — проти ' + esc(countries[r.terms.enemy].name) : ''}${r.type === 'ultimatum' ? ' — ' + (r.terms.kind === 'pay' ? 'виплатити ' + exact(r.terms.amount) + ' $' : r.terms.kind === 'cede' ? 'поступитись ' + r.terms.cells + ' кл.' : 'вимога') : ''}${r.type === 'bloc' ? ' — альянс «' + esc((r.terms || {}).name || '') + '»' : ''}${r.type === 'deal' ? '<div>' + dealTxt(r.terms) + '</div>' : ''}${r.type === 'peace' && r.terms.demand ? ' — умова: стати ' + (r.terms.demand === 'puppet' ? 'маріонеткою' : 'васалом') : ''}${r.text ? `<div class="muted">«${esc(r.text)}»</div>` : ''}<div class="row" style="margin-top:4px"><button class="sm" data-ok="${r.id}">Прийняти</button><button class="ghost sm" data-no="${r.id}">Відхилити</button></div></div>`).join('')}</div>` : ''}
    <div class="card pad"><h3>Угоди та дії</h3><div class="row" style="gap:8px">${sel.war ? `<button data-conf="peace">Мирна конференція</button><button class="danger" data-conf="capitulation" title="Капітулювати: переможець продиктує умови">Капітулювати</button>` : `${btn('alliance', 'Союз', 'Взаємна підтримка')}${btn('nonaggression', 'Пакт про ненапад', 'Не нападати одне на одного')}${btn('trade', 'Торгова угода', 'Дає ріст ВВП і вигідніші ціни')}<button class="danger" id="cwwar">Оголосити війну</button>`}</div>
      ${sel.war ? '' : `<label class="chk" title="Угоду бачать лише учасники та ті, чия політична розвідка у вас сильна. Її можна викрити шпигунською операцією"><input type="checkbox" id="cwsec" style="width:auto"> Таємна угода (без новин, приховано від інших)</label>`}${justHtml}
      ${sel.war || sel.vs ? '' : `<div class="row" style="margin-top:8px"><button class="ghost" data-rq="vassal" title="Запропонувати стати вашим васалом: платитиме вам податок раз на 30 діб">Запропонувати васалітет</button><button class="ghost" data-rq="puppet" title="Запропонувати стати маріонеткою: платитиме більший податок і не діятиме без вас">Запропонувати маріонетку</button></div>`}
      <div class="row" style="margin-top:8px">${O.myBloc && O.myBloc.leader && !sel.bloc && !sel.war ? `<button class="ghost" data-binv="${sel.id}" ${O.outgoing.some((r) => r.to_c === sel.id && r.type === 'bloc') ? 'disabled' : ''} title="Запросити до альянсу «${esc(O.myBloc.name)}»">Запросити в альянс «${esc(O.myBloc.name)}»</button>` : ''}${sel.bloc ? `<span class="badge" style="background:${esc(sel.bloc.color)};color:#fff">Альянс «${esc(sel.bloc.name)}»</span>` : ''}<button class="ghost" data-tosanc="1" title="Усі види санкцій і ембарго — в одному місці">Санкції й ембарго…</button></div>${cwStatus(sel) ? `<div style="margin-top:8px">${cwStatus(sel)}</div>` : ''}
      <div class="row" style="margin-top:10px">${sel.agreements.map((a) => `<button class="ghost sm" data-br="${a.id}">Розірвати: ${agt(a.type)[0].toLowerCase()}</button>`).join('')}</div>
      ${O.outgoing.filter((r) => r.to_c === sel.id).map((r) => `<div class="muted" style="margin-top:6px">Очікує відповіді: ${esc(r.typeName)} <button class="ghost sm" data-cn="${r.id}">Відкликати</button></div>`).join('')}</div>
    ${sel.war ? '' : cwExtraCard(sel)}
    ${sel.war ? '' : `<div class="card pad"><h3>Ультиматум</h3><div class="row"><select id="uk" style="width:auto"><option value="pay">Виплатити гроші</option><option value="cede">Поступитись територією</option><option value="text">Інша вимога</option></select><span id="uv"></span></div><label for="ut2">Текст</label><input id="ut2" maxlength="300"><p class="hint">Якщо відхилять, відносини впадуть, а бот може оголосити війну.</p><button class="sm" id="usnd">Надіслати ультиматум</button></div>`}
  </div><div><div class="card pad"><h3>Листування</h3><div class="chat" id="cwchat"></div><div class="row" style="margin-top:8px"><input id="cwct" class="grow" maxlength="500" placeholder="Повідомлення..."><button id="cws">Надіслати</button></div></div></div></div>`;
  { const rq = b.querySelector('[data-aidreq]'); if (rq) rq.onclick = () => cwAct(async () => { const r = await api('aid/request', { to: sel.id, kind: $('#aidk').value }); toast(r.message, r.accepted === false); }); }
  if (typeof cwVolFill === 'function' && !sel.war) cwVolFill(sel);
  { const sd = b.querySelector('[data-aidsend]'); if (sd) sd.onclick = () => { if ($('#aidk').value === 'equip' && window.aidEquipPick) return aidEquipPick(sel); if (confirm('Надати військову допомогу цій державі?')) cwAct(async () => { const r = await api('aid/send', { to: sel.id, kind: $('#aidk').value }); toast(r.message); }); }; }
  b.querySelectorAll('[data-imp]').forEach((x) => x.onclick = () => cwAct(async () => { const r = await api('diplo/improve', { to: sel.id }); toast(`Відносини покращились на ${r.gain}`); }));
  b.querySelectorAll('[data-grant]').forEach((x) => x.onclick = () => cwAct(() => api('diplo/grant', { to: sel.id }), 'Право проходу надано'));
  b.querySelectorAll('[data-rev]').forEach((x) => x.onclick = () => cwAct(() => api('diplo/revoke', { id: +x.dataset.rev }), 'Скасовано'));
  b.querySelectorAll('[data-wc]').forEach((x) => x.onclick = () => { const sl = $('#wcs'); if (!sl || !sl.value) return toast('Обери війну', true); cwAct(() => api('diplo/request', { to: sel.id, type: 'warcall', text: '', terms: { war: +sl.value } }), 'Заклик надіслано'); });
  b.querySelectorAll('[data-wj]').forEach((x) => x.onclick = () => { const sl = $('#wjs'); if (!sl || !sl.value) return toast('Обери війну', true); cwAct(() => api('diplo/request', { to: sel.id, type: 'warjoin', text: '', terms: { war: +sl.value } }), 'Прохання надіслано'); });
  b.querySelectorAll('[data-rq]').forEach((x) => x.onclick = () => { const sec = $('#cwsec') && $('#cwsec').checked && ['alliance', 'nonaggression', 'trade'].includes(x.dataset.rq); cwAct(() => api('diplo/request', { to: sel.id, type: x.dataset.rq, terms: sec ? { secret: true } : {} }), sec ? 'Таємну пропозицію надіслано' : 'Запит надіслано'); });
  { const j = $('#cwjust'); if (j) j.onclick = () => { if (confirm(`Почати обґрунтування цілей війни проти ${sel.name}? Це триватиме 100–150 діб, розвідка цілі може про це дізнатись.`)) cwAct(async () => { const r = await api('war/justify', { target: sel.id }); toast(`Обґрунтування триватиме ${r.days} діб`); }); }; const jc = $('#cwjc'); if (jc) jc.onclick = () => cwAct(() => api('war/justify/cancel', { target: sel.id }), 'Обґрунтування скасовано'); }
  b.querySelectorAll('[data-conf]').forEach((x) => x.onclick = () => { const k = x.dataset.conf; if (k === 'capitulation' && !confirm('Капітулювати перед ' + sel.name + '? Переможець диктує умови, ви зможете лише писати в чат.')) return; act(async () => { const r = await api('conf/open', { to: sel.id, kind: k }); closeDrawer(); await refreshMe(); openConfWin(r.id); }); });
  b.querySelectorAll('[data-binv]').forEach((x) => x.onclick = () => cwAct(() => api('bloc/invite', { to: sel.id }), 'Запрошення надіслано'));
  b.querySelectorAll('[data-tosanc]').forEach((x) => x.onclick = () => { cw.tab = 'sanc'; if (window.cwRender) cwRender(); });
  b.querySelectorAll('[data-emb]').forEach((x) => x.onclick = () => { if (x.dataset.emb === 'on' && !confirm('Ввести повне торговельне ембарго? Відносини погіршаться на 20.')) return; cwAct(() => api('embargo/set', { target: sel.id, on: x.dataset.emb === 'on' }), x.dataset.emb === 'on' ? 'Ембарго введено' : 'Ембарго знято'); });
  b.querySelectorAll('[data-sanc]').forEach((x) => x.onclick = () => cwAct(() => api('sanction/set', { target: sel.id, on: x.dataset.sanc === 'on' }), x.dataset.sanc === 'on' ? 'Санкції накладено' : 'Санкції знято'));
  b.querySelectorAll('[data-br]').forEach((x) => x.onclick = () => { if (confirm('Розірвати угоду? Це погіршить відносини.')) cwAct(() => api('diplo/break', { id: +x.dataset.br })); });
  b.querySelectorAll('[data-cn]').forEach((x) => x.onclick = () => cwAct(() => api('diplo/cancel', { id: +x.dataset.cn })));
  b.querySelectorAll('[data-ok]').forEach((x) => x.onclick = () => cwAct(() => api('diplo/respond', { id: +x.dataset.ok, accept: true })));
  b.querySelectorAll('[data-no]').forEach((x) => x.onclick = () => cwAct(() => api('diplo/respond', { id: +x.dataset.no, accept: false })));
  const w = $('#cwwar'); if (w) w.onclick = async () => { if (window.warDepsOk && !(await warDepsOk(sel))) return; const r = await askText(`Оголосити війну: ${sel.name}? Вкажи причину (можна пусто):`); if (r !== null) cwAct(() => api('diplo/war', { target: sel.id, text: r })); };
  const uk = $('#uk'); if (uk) { cw.ult = cw.ult || { id: sel.id, list: [] }; if (cw.ult.id !== sel.id) cw.ult = { id: sel.id, list: [] }; const U = cw.ult;
    const f = () => { $('#uv').innerHTML = uk.value === 'pay' ? '<input id="ua" type="number" value="50000000" style="width:160px"> $' : uk.value === 'cede' ? (U.list.length ? `<b>${U.list.length} кл.</b> позначено на мапі <button class="ghost sm" id="umap">Змінити</button> <button class="ghost sm" id="uclr">Очистити</button>` : `<button class="sm" id="umap">Позначити території на мапі</button> <span class="muted">або кількість:</span> <input id="ua" type="number" value="100" style="width:90px"> кл.`) : '';
      const um = $('#umap'); if (um) um.onclick = () => { cw.tab = 'diplo'; cw.ultKind = 'cede'; startTradeDraw(sel.id, { get: U.list, give: [] }, 20000, (take) => { U.list = take; }, true, true); }; const uc = $('#uclr'); if (uc) uc.onclick = () => { U.list = []; f(); }; };
    if (cw.ultKind) uk.value = cw.ultKind; f(); uk.onchange = () => { cw.ultKind = uk.value; f(); };
    $('#usnd').onclick = () => { const k = uk.value, a = $('#ua') ? +$('#ua').value : 0; cwAct(async () => { await api('diplo/request', { to: sel.id, type: 'ultimatum', text: $('#ut2').value, terms: k === 'pay' ? { kind: 'pay', amount: a } : k === 'cede' ? (U.list.length ? { kind: 'cede', list: U.list } : { kind: 'cede', cells: a }) : { kind: 'text' } }); cw.ult = null; cw.ultKind = null; }, 'Ультиматум надіслано'); }; }
  const chat = $('#cwchat'), load = async () => { const m = await api('diplo/chat?with=' + sel.id); chat.innerHTML = m.messages.map((x) => `<div class="msg ${x.mine ? 'me' : ''}"><small>${esc(x.fromName)}</small>${esc(x.text)}${x.deal && window.dealCard ? dealCard(x.deal) : ''}</div>`).join('') || '<span class="muted">Повідомлень ще немає.</span>'; chat.scrollTop = chat.scrollHeight; };
  window.refreshCwChat = load; load(); const send = () => { const t = $('#cwct').value.trim(); if (t) act(async () => { await api('diplo/send', { to: sel.id, text: t }); $('#cwct').value = ''; await load(); if (window.refreshChat) window.refreshChat(); }); };
  $('#cws').onclick = send; $('#cwct').onkeydown = (e) => { if (e.key === 'Enter') send(); };
}
function dealTxt(t) { const one = (b) => [b.money && exact(b.money) + ' $', ...Object.entries(b.res || {}).map(([k, v]) => `${RESN[k]} ×${v}`), ...Object.entries(b.eq || {}).map(([k, v]) => `${window.eqKeyLabel ? eqKeyLabel(k) : EQN[k]} ×${v}`), b.men && exact(b.men) + ' людських ресурсів', b.cells && b.cells + ' кл. території'].filter(Boolean).join(', ') || 'нічого'; return `Вони віддають: <b>${one(t.give)}</b><br>Просять: <b>${one(t.get)}</b>`; }
window.dealTxt = dealTxt;

// ---------- торгівля ----------
const EQ_ORDER = ['small_arms', 'support', 'trucks', 'apc', 'artillery', 'tanks', 'aa_guns', 'destroyers', 'submarines', 'fighters', 'bombers'];
function bundleValue(b, P) { return (+b.money || 0) + (+b.men || 0) * P.men + (+b.cells || 0) * P.cells + Object.entries(b.res).reduce((s, [k, v]) => s + v * P.res[k], 0) + Object.entries(b.eq).reduce((s, [k, v]) => s + v * (window.eqKeyPrice ? eqKeyPrice(P, k) : P.eq[k]), 0); }
function cwTrade(b) {
  const T = cw.T, P = T.prices, id = cw.id, S = tradeSt[id] = tradeSt[id] || { give: emptyBundle(), get: emptyBundle(), msg: null };
  S.lists = S.lists || { give: [], get: [] };
  if (T.war) { b.innerHTML = '<div class="card pad neg"><h3>Ви воюєте</h3>Під час війни торгівля неможлива. Запропонуйте мир у вкладці «Дипломатія».</div>'; return; }
  const col = (side, title) => { const B = S[side], lim = side === 'give', LN = S.lists[side].length;
    return `<div class="card pad tcol2"><h3>${title}</h3>
      <div class="trow"><label>Гроші, $${lim ? ` <span class="muted">(казна ${short(T.my.treasury)})</span>` : ''}</label><input type="number" min="0" step="1000000" data-f="${side}.money" value="${B.money || ''}" placeholder="0"></div>
      <h4>Ресурси</h4>${Object.keys(P.res).map((k) => `<div class="trow"><label>${icon(k)}${RESN[k]} <span class="muted">· ${short(P.res[k])} $/од.${lim ? ' · маєш ' + nf(T.my.res[k], 1) : ''}</span></label><input type="number" min="0" step="0.5" data-f="${side}.res.${k}" value="${B.res[k] || ''}" placeholder="0"></div>`).join('')}
      <h4>Зброя й техніка</h4>${window.tradeEqRows ? tradeEqRows(side, lim ? T.myModels : T.theirModels, P, B, lim, T) : ''}
      <h4>Люди й територія</h4><div class="trow"><label>Людські ресурси <span class="muted">· ${short(P.men)} $/особу${lim ? ' · вільно ' + exact(T.my.men) : ''}</span></label><input type="number" min="0" step="100" data-f="${side}.men" value="${B.men || ''}" placeholder="0"></div>
      <div class="trow"><label>Територія, клітинок <span class="muted">· ${short(P.cells)} $/кл. · до ${T.maxCells}${lim ? ' · маєш ' + exact(T.my.cells) : ''}</span></label><input type="number" min="0" step="10" data-f="${side}.cells" value="${LN || B.cells || ''}" placeholder="0" ${LN ? 'readonly title="Задано виділенням на мапі"' : ''}></div>
      ${LN ? `<div class="muted">Позначено на мапі: ${LN} кл. (інфраструктура на них знижує охоту бота віддавати)</div>` : ''}<div class="tsum">Вартість за ринком: <b id="v-${side}">0 $</b></div></div>`; };
  const items = [['res', 'Ресурс', Object.keys(P.res).map((k) => [k, RESN[k]])], ['eq', 'Зброя й техніка (точна модель)', window.tradeEqQuick ? tradeEqQuick(T) : EQ_ORDER.map((k) => [k, EQN[k]])]];
  b.innerHTML = `<div class="card pad"><h3>Швидка угода</h3><div class="row"><select id="qk" style="width:auto">${items.map(([g, gn, list]) => `<optgroup label="${gn}">${list.map(([k, n]) => `<option value="${g}.${k}">${n}</option>`).join('')}</optgroup>`).join('')}<optgroup label="Інше"><option value="men">Людські ресурси</option><option value="cells">Територія (клітинки)</option></optgroup></select>
    <input id="qn" type="number" min="1" value="10" style="width:110px"><button class="sm" id="qbuy">Купити</button><button class="ghost sm" id="qsell">Продати</button><span class="muted">Ціна: ринкова ${T.bot ? '' : '(пропозиція піде гравцеві)'}. Відносини ${T.relation > 0 ? 'знижують' : T.relation < 0 ? 'підвищують' : 'не змінюють'} ціну${T.trade ? '; торгова угода дає знижку' : ''}.</span></div></div>
    <div class="grid g2">${col('give', 'Ти віддаєш')}${col('get', 'Ти отримуєш')}</div>
    <div class="card pad"><div class="row"><button class="ghost sm" id="tmap">Позначити території на мапі</button><span class="muted">Обери конкретні клітинки: що купити в них і що віддати.</span></div></div>
    <div class="card pad"><div class="row"><b id="tbal"></b><span class="grow"></span><button class="ghost sm" id="tbalb">Урівняти грошима</button><button class="ghost sm" id="tclr">Очистити</button><button id="tgo">Запропонувати угоду</button></div>
      <div id="tmsg" class="${S.msg && S.msg.accepted === false ? 'neg' : S.msg ? 'pos' : ''}" style="margin-top:8px">${S.msg ? esc(S.msg.message) : ''}</div>
      <p class="hint">${T.bot ? 'Бот оцінює угоду миттєво: враховує відносини, характер і те, що він залишає собі резерв.' : 'Гравець побачить пропозицію у вкладці «Дипломатія» й може прийняти або відхилити її.'}</p></div>`;
  const read = () => { for (const side of ['give', 'get']) S[side] = emptyBundle(); b.querySelectorAll('[data-f]').forEach((i) => { const v = +i.value || 0; if (!v) return; const [side, a, k] = i.dataset.f.split('.'); if (a === 'res') S[side].res[k] = v; else if (a === 'eq') S[side].eq[k] = v; else S[side][a] = v; }); for (const side of ['give', 'get']) if (S.lists[side].length) { S[side].list = S.lists[side]; S[side].cells = S.lists[side].length; } };
  const upd = () => { read(); const vg = bundleValue(S.give, P), vr = bundleValue(S.get, P); $('#v-give').textContent = exact(vg) + ' $'; $('#v-get').textContent = exact(vr) + ' $'; const d = vg - vr; $('#tbal').textContent = d === 0 ? 'Баланс: рівно' : d > 0 ? `Ти віддаєш більше на ${exact(d)} $` : `Ти отримуєш більше на ${exact(-d)} $`; $('#tbal').className = d >= 0 ? 'pos' : 'warn'; };
  b.querySelectorAll('[data-f]').forEach((i) => i.oninput = upd); upd();
  const setField = (path, v) => { const i = b.querySelector(`[data-f="${path}"]`); if (i) i.value = v; };
  $('#tmap').onclick = () => { read(); startTradeDraw(id, S.lists, T.maxCells, (take, give) => { S.lists.get = take; S.lists.give = give; }); };
  $('#tclr').onclick = () => { tradeSt[id] = null; S.msg = null; cwTrade(b); };
  $('#tbalb').onclick = () => { read(); const vg = bundleValue(S.give, P), vr = bundleValue(S.get, P), d = vg - vr; if (d < 0) setField('give.money', Math.round((S.give.money || 0) - d)); else if (d > 0) setField('get.money', Math.round((S.get.money || 0) + d)); upd(); };
  const quick = (buy) => { const [g, k] = $('#qk').value.split('.'), n = +$('#qn').value; if (g === 'cells') { read(); const f0 = Math.max(0.8, Math.min(1.4, 1 - T.relation / 400 - (T.trade ? 0.08 : 0))); return startTradeDraw(id, S.lists, T.maxCells, (take, give) => { S.lists.get = take; S.lists.give = give; if (buy && take.length && !S.give.money) S.give.money = Math.round(take.length * P.cells * 1.12 * f0); if (!buy && give.length && !S.get.money) S.get.money = Math.round(give.length * P.cells * 0.9 / f0); }, buy); } if (!(n > 0)) return; for (const f of b.querySelectorAll('[data-f]')) f.value = ''; const price = g === 'res' ? P.res[k] : g === 'eq' ? (window.eqKeyPrice ? eqKeyPrice(P, k) : P.eq[k]) : g === 'men' ? P.men : P.cells; const key = g === 'res' || g === 'eq' ? `${g}.${k}` : g;
    const f = Math.max(0.8, Math.min(1.4, 1 - T.relation / 400 - (T.trade ? 0.08 : 0)));
    if (buy) { setField('get.' + key, n); setField('give.money', Math.round(n * price * 1.12 * f)); } else { setField('give.' + key, n); setField('get.money', Math.round(n * price * 0.9 / f)); } upd(); };
  $('#qbuy').onclick = () => quick(true); $('#qsell').onclick = () => quick(false);
  $('#tgo').onclick = async () => { read(); try { const r = await api('trade/offer', { to: id, give: S.give, get: S.get }); S.msg = r; if (r.accepted) { toast(r.message); tradeSt[id] = { give: emptyBundle(), get: emptyBundle(), msg: r, lists: { give: [], get: [] } }; await refreshMe(); } else if (r.accepted === null) toast(r.message); await cwRender(); } catch (e) { S.msg = { accepted: false, message: e.message }; $('#tmsg').className = 'neg'; $('#tmsg').textContent = e.message; } };
}

// ---------- відносини ----------
async function cwRel(b) {
  const { sel, d, T } = cw, war = await api('war/log').catch(() => ({ wars: [] })), mine = war.wars.filter((w) => (w.a === me.country.id && w.b === d.id) || (w.b === me.country.id && w.a === d.id)), r = d.relation;
  b.innerHTML = `<div class="grid g2"><div><div class="card pad"><h3>Рівень відносин</h3><div class="relbar"><i style="left:${(r + 100) / 2}%"></i></div><div class="row" style="justify-content:space-between"><span class="muted">−100 ворожість</span><b class="${r < 0 ? 'neg' : r > 0 ? 'pos' : ''}">${r > 0 ? '+' : ''}${r}</b><span class="muted">+100 дружба</span></div>
    <p class="hint">Відносини впливають на згоду ботів: союзи, пакти, ціни в торгівлі. Вони зростають від угод, дарунків і торгівлі, падають від ультиматумів, розриву угод і війни.</p></div>
  <div class="card pad"><h3>Дарунок</h3><p class="hint" style="margin-top:0">Гроші з казни покращують відносини: приблизно +1 за кожні 4 млн $, не більше +15 за раз.</p><div class="row"><input id="ga" type="number" value="10000000" min="1000000" step="1000000" style="width:170px"> $<button class="sm" id="gbtn">Надіслати</button></div></div></div>
  <div><div class="card pad"><h3>Угоди</h3>${sel.agreements.length ? sel.agreements.map((a) => `<div class="row" style="margin:4px 0"><span class="chip ${agt(a.type)[1]}">${agt(a.type)[0]}</span><span class="grow"></span><button class="ghost sm" data-br="${a.id}">Розірвати</button></div>`).join('') : '<p class="muted">Діючих угод немає.</p>'}</div>
  <div class="card pad"><h3>Історія війн</h3>${mine.length ? mine.map((w) => `<div style="margin:4px 0">${gdate(w.start_day)}${w.status === 'active' ? ' — <b class="neg">триває</b>' : ' — завершена на добу ' + Math.floor(w.end_day || 0)}${w.reason ? `<div class="muted">${esc(w.reason)}</div>` : ''}</div>`).join('') : '<p class="muted">Війн між вами не було.</p>'}</div></div></div>`;
  $('#gbtn').onclick = () => cwAct(() => api('trade/gift', { to: d.id, amount: +$('#ga').value }), 'Дарунок надіслано');
  b.querySelectorAll('[data-br]').forEach((x) => x.onclick = () => { if (confirm('Розірвати угоду? Це погіршить відносини.')) cwAct(() => api('diplo/break', { id: +x.dataset.br })); });
  const L = await api('rel/log?with=' + d.id).catch(() => null); if (L) b.insertAdjacentHTML('beforeend', `<div class="card pad"><h3>Чому змінювались відносини</h3>${L.rows.length ? `<table>${L.rows.slice(0, 25).map((x) => `<tr><td class="muted" style="white-space:nowrap">доба ${nf(x.day, 1)}</td><td>${esc(x.why)}</td><td class="r"><b class="${x.delta < 0 ? 'neg' : 'pos'}">${x.delta > 0 ? '+' : ''}${nf(x.delta, 1)}</b></td><td class="r muted">→ ${nf(x.after, 0)}</td></tr>`).join('')}</table>` : '<p class="muted">Змін ще не було.</p>'}<p class="hint">Відносини між двома державами за добу можуть упасти не більше ніж на 25 (крім оголошення війни).</p></div>`);
}
