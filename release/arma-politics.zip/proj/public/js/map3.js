// Мапа 3: міста, річки, постачання, ППО й дрони, польоти, конвої, армії (фронти), значки об'єктів
let mapVerSeen = 0, cities = [], rivers = [], armyDraw = [], convoysD = [], adSites = [], flightsD = [], knownFacs = [], blockades = [], supplyCv = null, supplyKey = '', adState = null, selLaunch = null, flightsAt = 0, flightAnim = false;
const SUPC = [[0.75, '#2ecc71'], [0.5, '#c6d94a'], [0.3, '#f39c12'], [0, '#e74c3c']];
const zoomK = () => view.s / view.fs;

// ---------- завантаження ----------
async function loadCities() { try { cities = (await api('map/cities')).cities; } catch { cities = []; } }
async function loadRivers() { if (rivers.length) return; try { rivers = (await api('map/rivers')).lines; } catch { rivers = []; } }
async function loadArmyDraw() { if (!me || !me.country) { armyDraw = []; return; } try { armyDraw = (await api('armies/draw')).armies; } catch { armyDraw = []; } }
async function loadConvoysMap() { if (!me || !me.country) { convoysD = []; return; } try { const d = await api('convoys/world'); convoysD = d.convoys.filter((c) => c.status === 'move' || c.status === 'back'); convoysD.day = d.day; convoysD.at = Date.now(); } catch { convoysD = []; } }
async function loadAD() { if (!me || !me.country) { adSites = []; return; } try { adSites = (await api('ad/map')).sites; } catch { adSites = []; } }
async function loadADState() { if (!me || !me.country) return; try { adState = await api('ad/state'); } catch { adState = null; } }
async function loadKnown() { if (!me || !me.country) { knownFacs = []; return; } try { knownFacs = (await api('intel/facs')).facs; } catch { knownFacs = []; } }
async function loadBlockades() { try { blockades = (await api('map/blockades')).fleets; } catch { blockades = []; } }
let flBusy = false;
async function loadFlights() {
  if (flBusy || !me || !me.country) return; flBusy = true;
  try { const d = await api('air/live'); flightsD = d.flights.map((f) => { const old = flightsD.find((o) => o.id === f.id); return { ...f, px: old ? old.px : f.x, py: old ? old.py : f.y }; }); flightsAt = performance.now(); if (flightsD.some((f) => !f.dead)) startFlightAnim(); } catch { /* наступного разу */ }
  flBusy = false;
}
function startFlightAnim() { if (flightAnim) return; flightAnim = true; const step = () => { if (!flightsD.some((f) => !f.dead) || tab !== 'map') { flightAnim = false; drawMap(); return; } const dt = (performance.now() - flightsAt) / 1000; for (const f of flightsD) { if (f.dead) continue; const d = Math.hypot(f.tx - f.x, f.ty - f.y), k = d ? Math.min(1, f.speed * dt / d) : 1, ex = f.x + (f.tx - f.x) * k, ey = f.y + (f.ty - f.y) * k; f.px += (ex - f.px) * 0.35; f.py += (ey - f.py) * 0.35; } drawMap(); setTimeout(() => requestAnimationFrame(step), 50); }; step(); }
setInterval(() => { if (me && me.country && tab === 'map' && (flightsD.some((f) => !f.dead) || layer === 'drones' || layer === 'air')) loadFlights(); }, 1500);
async function refreshLayerData() { await Promise.all([loadCities(), loadRivers(), loadArmyDraw(), loadConvoysMap(), loadBlockades(), (layer === 'drones' || layer === 'air') ? Promise.all([loadAD(), loadADState(), loadKnown()]) : null, (layer === 'facilities' || layer === 'logistics') ? loadKnown() : null]); buildSupply(); }

// ---------- річки ----------
function drawRivers(C) {
  if (!rivers.length) return; cx.save(); cx.lineCap = 'round'; cx.lineJoin = 'round';
  const w = Math.max(1.6 * C, 2.2 / view.s); cx.strokeStyle = getComputedStyle(document.documentElement).getPropertyValue('--river') || '#6fa0e8';
  cx.lineWidth = w; cx.beginPath(); for (const l of rivers) { cx.moveTo(l[0] * C, l[1] * C); for (let i = 2; i < l.length; i += 2) cx.lineTo(l[i] * C, l[i + 1] * C); } cx.stroke(); cx.restore();
}
// ---------- постачання (як у HOI4): зелене — добре, червоне — немає ----------
function buildSupply() {
  if (layer !== 'supply' || !me || !me.country || !logi || !logi.src) { supplyCv = null; return; } const key = JSON.stringify(logi.src).length + ':' + (logi.src[0] || []).join(','); if (supplyCv && supplyKey === key && supplyCv.ver === mapVerSeen) return;
  const S = 4, W = Math.ceil(land.gw / S), H = Math.ceil(land.gh / S), cvs = document.createElement('canvas'); cvs.width = W; cvs.height = H; const g = cvs.getContext('2d'), img = g.createImageData(W, H), my = me.country.id, rs = logi.railSpeed || 1;
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { const X = x * S + 2, Y = y * S + 2, i = Y * land.gw + X; if (owners[i] !== my) continue; let f = 0; for (const p of logi.src) { const d = Math.hypot(p[0] - X, p[1] - Y), k = d <= p[3] ? 1 : Math.max(0.15, 1 - (d - p[3]) / (120 * rs)); if (k * p[2] > f) f = k * p[2]; }
    const col = SUPC.find((s) => f >= s[0])[1], [r, gg, b] = hexRgb(col), o = (y * W + x) * 4; img.data[o] = r; img.data[o + 1] = gg; img.data[o + 2] = b; img.data[o + 3] = 150; }
  g.putImageData(img, 0, 0); supplyCv = cvs; supplyCv.S = S; supplyCv.ver = mapVerSeen; supplyKey = key;
}
function drawSupply(C) { if (!supplyCv) buildSupply(); if (!supplyCv) return; cx.save(); cx.imageSmoothingEnabled = true; cx.drawImage(supplyCv, 0, 0, supplyCv.width * supplyCv.S * C, supplyCv.height * supplyCv.S * C); cx.restore(); }

// ---------- міста ----------
function drawCities(C) {
  if (!cities.length || !['owners', 'diplo', 'alliances', 'supply', 'logistics', 'facilities', 'drones', 'air'].includes(layer)) return; const z = zoomK(), r = Math.max(4.2, Math.min(9, 3 + z * 0.9)) / view.s;
  const myC = typeof me !== 'undefined' && me && me.country ? me.country.id : 0; // (21) свої міста видно завжди, навіть малі
  for (const c of cities) { if (!c.cap && c.level < 2 && z < 1.6 && c.cid !== myC) continue; const x = (c.x + .5) * land.cell, y = (c.y + .5) * land.cell, own = countries[c.cid];
    drawBadge(cx, c.cap ? 'capital' : 'city', x, y, c.cap ? r * 1.25 : r, { bg: c.cap ? '#c49a1e' : own ? '#3a3046' : '#55606b', stroke: own ? own.color : '#e8e8e8', lw: 1.6 / view.s });
    if (z > 1.35 || c.cap) { cx.font = `${c.cap ? 700 : 600} ${(c.cap ? 12 : 10.5) / view.s}px system-ui,sans-serif`; cx.textAlign = 'left'; cx.lineJoin = 'round'; cx.lineWidth = 3 / view.s; cx.strokeStyle = 'rgba(15,12,22,.85)'; cx.strokeText(c.name, x + r + 3 / view.s, y + 4 / view.s); cx.fillStyle = '#f2eefa'; cx.fillText(c.name, x + r + 3 / view.s, y + 4 / view.s); }
  }
}
function cityAt(e) { if (!cities.length) return null; const r = cv.getBoundingClientRect(); let hit = null, best = 11; for (const c of cities) { const d = Math.hypot(view.x + (c.x + .5) * land.cell * view.s - (e.clientX - r.left), view.y + (c.y + .5) * land.cell * view.s - (e.clientY - r.top)); if (d < best) { best = d; hit = c; } } return hit; }

// ---------- значки об'єктів ----------
function drawFacBadges(C, list, enemy) {
  const r = Math.max(6.5, Math.min(11, 4.5 + zoomK() * 0.7)) / view.s;
  for (const f of list) { if (f.kind === 'city') continue; const x = (f.x + .5) * C, y = (f.y + .5) * C; drawBadge(cx, f.kind, x, y, r, { square: true, stroke: enemy ? '#ff4d4d' : selFac === f.id ? '#e6007e' : 'rgba(255,255,255,.95)', lw: (enemy || selFac === f.id ? 2.6 : 1.4) / view.s });
    if (f.level > 1) { cx.fillStyle = '#fff'; cx.strokeStyle = '#111'; cx.lineWidth = 2.5 / view.s; cx.font = `800 ${8.5 / view.s}px sans-serif`; cx.textAlign = 'center'; const t = '★'.repeat(Math.min(f.level, 5)); cx.strokeText(t, x, y + r + 8 / view.s); cx.fillText(t, x, y + r + 8 / view.s); cx.textAlign = 'start'; } }
}
// ---------- ППО, радари ----------
function drawAD(C) {
  const showR = layer === 'drones' || layer === 'air'; if (!adSites.length || !showR) return;
  for (const s of adSites) { let px = s.x, py = s.y; if (s.move) { const t = Math.max(0, Math.min(1, (nowDay() - s.move.dep) / Math.max(1e-6, s.move.arr - s.move.dep))); px = s.x + (s.move.tx - s.x) * t; py = s.y + (s.move.ty - s.y) * t; }
    const x = (px + .5) * C, y = (py + .5) * C, col = s.own ? '#a855f7' : s.ally ? '#2ecc71' : '#ff4d4d';
    if (s.move) { cx.globalAlpha = .8; cx.setLineDash([3 / view.s, 4 / view.s]); cx.strokeStyle = col; cx.lineWidth = 1.6 / view.s; cx.beginPath(); cx.moveTo(x, y); cx.lineTo((s.move.tx + .5) * C, (s.move.ty + .5) * C); cx.stroke(); cx.setLineDash([]); cx.globalAlpha = 1; drawBadge(cx, s.kind, x, y, 8.5 / view.s, { stroke: col, lw: 2 / view.s, bg: '#666' }); continue; }
    if (s.rr) { cx.globalAlpha = s.broken ? .04 : .08; cx.fillStyle = s.own ? '#22c3a6' : col; cx.beginPath(); cx.arc(x, y, s.rr * C, 0, 7); cx.fill(); cx.globalAlpha = .55; cx.setLineDash([2 / view.s, 4 / view.s]); cx.strokeStyle = s.own ? '#22c3a6' : col; cx.lineWidth = 1.2 / view.s; cx.stroke(); cx.setLineDash([]); cx.globalAlpha = 1; }
    if (!/^r\d$/.test(s.kind)) { cx.globalAlpha = .7; cx.setLineDash([6 / view.s, 4 / view.s]); cx.strokeStyle = col; cx.lineWidth = 1.5 / view.s; cx.beginPath(); cx.arc(x, y, s.r * C, 0, 7); cx.stroke(); cx.setLineDash([]); cx.globalAlpha = 1; }
    drawBadge(cx, s.kind, x, y, 8.5 / view.s, { stroke: col, lw: 2 / view.s, bg: s.broken ? '#555' : undefined }); }
}
// ---------- польоти (дрони, ракети, літаки) ----------
function drawFlights(C) {
  for (const f of flightsD) { const x = ((f.px == null ? f.x : f.px) + .5) * C, y = ((f.py == null ? f.y : f.py) + .5) * C, sx = (f.sx + .5) * C, sy = (f.sy + .5) * C, col = f.mine ? '#f5b041' : '#ff4d4d';
    cx.globalAlpha = f.dead ? .25 : .75; cx.setLineDash([4 / view.s, 4 / view.s]); cx.strokeStyle = col; cx.lineWidth = 1.4 / view.s; cx.beginPath(); cx.moveTo(sx, sy); cx.lineTo(x, y); cx.stroke(); cx.setLineDash([]); cx.globalAlpha = 1;
    if (f.dead) { cx.fillStyle = '#ff6b35'; cx.globalAlpha = .8; cx.beginPath(); cx.arc(x, y, 7 / view.s, 0, 7); cx.fill(); cx.globalAlpha = 1; continue; }
    const ang = Math.atan2(f.ty - f.y, f.tx - f.x) + Math.PI / 2, key = f.kind === 'plane' ? 'plane' : f.item, img = iconImg(key), s = (f.kind === 'missile' ? 15 : f.kind === 'plane' ? 18 : 14) / view.s;
    cx.save(); cx.translate(x, y); cx.rotate(ang); cx.beginPath(); cx.arc(0, 0, s * 0.62, 0, 7); cx.fillStyle = f.mine ? 'rgba(120,70,0,.75)' : 'rgba(120,0,0,.75)'; cx.fill(); if (img) cx.drawImage(img, -s / 2, -s / 2, s, s); cx.restore();
    if (zoomK() > 1.8) { cx.font = `600 ${9.5 / view.s}px sans-serif`; cx.fillStyle = col; cx.fillText(f.name, x + s * 0.7, y - s * 0.6); }
  }
}
// ---------- конвої ----------
function convoyPos(cv0) { const now = convoysD.day + (Date.now() - convoysD.at) / 3.6e6 * ((me && me.world && me.world.scale) || 1), t = Math.max(0, Math.min(1, (now - cv0.start) / Math.max(1e-6, cv0.eta - cv0.start))), p = cv0.status === 'back' ? cv0.path.slice().reverse() : cv0.path; let L = 0; for (let i = 1; i < p.length; i++) L += Math.hypot(p[i][0] - p[i - 1][0], p[i][1] - p[i - 1][1]); let need = L * t, acc = 0; for (let i = 1; i < p.length; i++) { const d = Math.hypot(p[i][0] - p[i - 1][0], p[i][1] - p[i - 1][1]); if (acc + d >= need) { const k = d ? (need - acc) / d : 0; return [p[i - 1][0] + (p[i][0] - p[i - 1][0]) * k, p[i - 1][1] + (p[i][1] - p[i - 1][1]) * k]; } acc += d; } return p[p.length - 1]; }
const CONVOY_LAYERS = ['owners', 'logistics', 'supply', 'diplo', 'alliances', 'facilities'];
// каравани й кораблі реально рухаються: перемальовуємо мапу, поки на ній є вантажі
setInterval(() => { if (document.hidden || typeof tab === 'undefined' || tab !== 'map' || brushing || flightAnim) return;
  const mv = (layer === 'drones' || layer === 'air') && adSites.some((x) => x.move); if (mv && adSites.some((x) => x.move && nowDay() > x.move.arr)) { loadAD().then(drawMap); return; }
  if (mv || (convoysD.length && CONVOY_LAYERS.includes(layer))) drawMap(); }, 1000);
function drawConvoys(C) {
  if (!convoysD.length || !CONVOY_LAYERS.includes(layer) || (window.mapShow && !mapShow.convoys)) { drawBlk(); return; }
  for (const c of convoysD) { const isSea = c.mode === 'sea' || c.mode === 'hired', col = isSea ? '#5dade2' : c.mode === 'air' ? '#e5e7eb' : '#f5b041'; 
    const [x, y] = convoyPos(c), onLand = land.arr ? !!land.arr[Math.round(y) * land.gw + Math.round(x)] : !isSea; drawBadge(cx, c.mode === 'air' ? 'plane' : !onLand ? (c.ships && c.ships.tanker ? 'tanker' : 'cargo') : 'truck', (x + .5) * land.cell, (y + .5) * land.cell, Math.max(8, Math.min(13, 5 + zoomK())) / view.s, { bg: c.mode === 'air' ? '#555' : !onLand ? '#1f6f8b' : '#8a6d3f', stroke: c.mine ? '#fff' : c.through ? '#2ecc71' : (countries[c.from] || {}).color || '#ffd166' }); }
  drawBlk(); }
function drawBlk() {
  for (const b of blockades) { const col = (countries[b.cid] || {}).color || '#888'; cx.globalAlpha = .12; cx.fillStyle = col; cx.beginPath(); cx.arc((b.x + .5) * land.cell, (b.y + .5) * land.cell, b.r * land.cell, 0, 7); cx.fill(); cx.globalAlpha = .8; cx.setLineDash([8 / view.s, 5 / view.s]); cx.strokeStyle = col; cx.lineWidth = 2 / view.s; cx.stroke(); cx.setLineDash([]); cx.globalAlpha = 1; }
}
// ---------- армії: фронти, зони оборони, зони прориву, стрілки ----------
function drawArmies(C) {
  if (!armyDraw.length || !me || !me.country) return; const col = '#c084fc';
  for (const a of armyDraw) {
    if (a.zone) { cx.globalAlpha = .22; cx.fillStyle = '#7dd3fc'; const s = Math.max(1, Math.sqrt(a.step || 1)); for (const i of a.zone) cx.fillRect((i % land.gw) * C, ((i / land.gw) | 0) * C, C * s, C * s); cx.globalAlpha = 1; }
    if (a.attack) { cx.globalAlpha = .28; cx.fillStyle = '#ef4444'; for (const i of a.attack) cx.fillRect((i % land.gw) * C, ((i / land.gw) | 0) * C, C * 1.5, C * 1.5); cx.globalAlpha = 1; }
    if (a.line && a.line.length > 1) { cx.save(); cx.lineCap = 'round'; cx.lineJoin = 'round'; cx.strokeStyle = 'rgba(20,10,30,.8)'; cx.lineWidth = 7 / view.s; cx.beginPath(); { let brk = true; for (const p of a.line) { if (!p) { brk = true; continue; } if (brk) cx.moveTo((p[0] + .5) * C, (p[1] + .5) * C); else cx.lineTo((p[0] + .5) * C, (p[1] + .5) * C); brk = false; } } cx.stroke(); cx.strokeStyle = col; cx.lineWidth = 3.6 / view.s; cx.stroke();
      cx.setLineDash([2 / view.s, 7 / view.s]); cx.strokeStyle = '#fff'; cx.lineWidth = 1.6 / view.s; cx.stroke(); cx.setLineDash([]);
      cx.restore(); const m = a.line.filter(Boolean)[Math.floor(a.line.filter(Boolean).length / 2)]; cx.font = `700 ${11 / view.s}px sans-serif`; cx.lineWidth = 3 / view.s; cx.strokeStyle = '#120a1c'; cx.strokeText(a.name, (m[0] + 2) * C, (m[1] - 2) * C); cx.fillStyle = '#e9d5ff'; cx.fillText(a.name, (m[0] + 2) * C, (m[1] - 2) * C); }
    if (a.from && a.target) drawArrow(C, a.from, a.target, a.attacking ? '#ef4444' : 'rgba(239,68,68,.55)');
  }
}
function drawArrow(C, a, b, col) {
  const x1 = (a[0] + .5) * C, y1 = (a[1] + .5) * C, x2 = (b[0] + .5) * C, y2 = (b[1] + .5) * C, ang = Math.atan2(y2 - y1, x2 - x1), L = Math.hypot(x2 - x1, y2 - y1), w = Math.max(6 / view.s, Math.min(L * 0.12, 26 / view.s));
  cx.save(); cx.translate(x1, y1); cx.rotate(ang); cx.beginPath(); cx.moveTo(0, -w * 0.45); cx.quadraticCurveTo(L * 0.5, -w * 0.7, L - w * 1.6, -w * 0.5); cx.lineTo(L - w * 1.6, -w * 1.1); cx.lineTo(L, 0); cx.lineTo(L - w * 1.6, w * 1.1); cx.lineTo(L - w * 1.6, w * 0.5); cx.quadraticCurveTo(L * 0.5, w * 0.7, 0, w * 0.45); cx.closePath();
  cx.fillStyle = col; cx.fill(); cx.lineWidth = 1.5 / view.s; cx.strokeStyle = 'rgba(30,0,0,.8)'; cx.stroke(); cx.restore();
}
// ---------- символи підрозділів (як NATO, більші) ----------
function drawUnitSymbol(u, x, y, fill, stroke, dash) {
  const r = 10 / view.s, dom = UTD[u.type] || 'land', w = r * 1.5, h = r * 1.05; cx.save(); cx.lineWidth = 1.8 / view.s; cx.strokeStyle = stroke; cx.fillStyle = fill; if (dash) cx.setLineDash([3 / view.s, 2 / view.s]);
  cx.beginPath(); if (dom === 'sea') cx.arc(x, y, r * 1.05, 0, 7); else if (dom === 'air') { cx.moveTo(x, y - r * 1.3); cx.lineTo(x + r * 1.3, y + r); cx.lineTo(x - r * 1.3, y + r); cx.closePath(); } else cx.rect(x - w, y - h, 2 * w, 2 * h); cx.fill(); cx.stroke(); cx.setLineDash([]);
  if (dom === 'land') { cx.strokeStyle = '#111'; cx.lineWidth = 1.5 / view.s; cx.beginPath(); const t = u.type;
    if (t === 'infantry' || t === 'mechanized') { cx.moveTo(x - w, y - h); cx.lineTo(x + w, y + h); cx.moveTo(x + w, y - h); cx.lineTo(x - w, y + h); }
    if (t === 'armor' || t === 'mechanized') { cx.moveTo(x + w * 0.55, y); cx.ellipse(x, y, w * 0.55, h * 0.5, 0, 0, 7); }
    if (t === 'recon') { cx.moveTo(x - w, y + h); cx.lineTo(x + w, y - h); }
    if (t === 'antiair') { cx.moveTo(x - w * 0.7, y + h * 0.4); cx.quadraticCurveTo(x, y - h * 1.1, x + w * 0.7, y + h * 0.4); }
    cx.stroke(); if (t === 'artillery') { cx.fillStyle = '#111'; cx.beginPath(); cx.arc(x, y, r * 0.28, 0, 7); cx.fill(); } }
  else { cx.fillStyle = '#111'; cx.font = `800 ${9.5 / view.s}px sans-serif`; cx.textAlign = 'center'; cx.fillText(UTL[u.type] || '?', x, y + 3.3 / view.s); cx.textAlign = 'start'; }
  cx.restore(); return r;
}

// ---------- бічна панель шару «Безпілотники та ППО» ----------
let adPlaceKind = null, launchSel = { item: '', count: 1, unit: 0, missile: '' };
function adPanelHtml() {
  if (!adState) return '<div class="card pad"><div class="muted">Завантаження ППО…</div></div>';
  const S = adState, rows = [...S.radars, ...S.ad].filter((r) => r.unlocked || r.stock || r.placed), total = rows.reduce((n, r) => n + r.placed, 0);
  let h = `<div class="adbox"><div class="adhead"><b>Засоби ППО</b><span class="muted">розміщено ${total}</span></div>${rows.map((r) => `<div class="adrow ${adPlaceKind === r.k ? 'on' : ''}" data-adk="${r.k}" title="${esc(r.d)}">${ico(r.k, 26)}<div class="grow"><div class="adn">${esc(r.n)}</div><div class="muted adm">${r.kind === 'radar' ? `радар · ${r.r} кл. · бачить: дрони ${Math.round(r.p[0] * 100)}%, ракети ${Math.round(r.p[1] * 100)}%, літаки ${Math.round(r.p[2] * 100)}% · поломки ${Math.round(r.fail * 100)}%/добу` : `${r.r} кл. · боєкомплект ${r.ammo} · дрони ${Math.round(r.p[0] * 100)}%, ракети ${Math.round(r.p[1] * 100)}%, літаки ${Math.round(r.p[2] * 100)}%${r.vis ? '' : ' · потрібен радар'}${r.base ? ' · біля аеродрому' : ''}`}</div></div><div class="adc"><b>${r.stock}</b><span class="muted">на складі</span><b>${r.placed}</b><span class="muted">на мапі</span></div></div>`).join('')}
    <button class="adplace" id="adgo" ${adPlaceKind ? '' : ''}>${adPlaceKind ? 'Клікни на мапі, де поставити: ' + esc((rows.find((r) => r.k === adPlaceKind) || {}).n || '') : 'Розмістити'}</button>
    <p class="hint" style="margin:6px 2px 0">Обери засіб у списку, натисни «Розмістити» й клікни на своїй території. Клік по своєму засобу на мапі — керування. Виготовити більше: Моя держава → Виробництво.</p></div>`;
  if (S.stats && (S.stats.down || S.stats.lost || S.stats.hit)) h += `<div class="muted" style="font-size:13px;margin:6px 2px">Збито ворожих цілей: <b>${S.stats.down || 0}</b> · втрачено своїх: <b>${S.stats.lost || 0}</b> · влучань: <b>${S.stats.hit || 0}</b></div>`;
  return h;
}
function launchPanelHtml() {
  if (!adState) return ''; const L = adState.launchers.find((l) => l.id === selLaunch); if (!L) return `<div class="card pad"><h3>${ico('launcher', 22)} Удари</h3><p class="hint" style="margin:0">Клікни на мапі по своїй пусковій установці (дрони) або аеродрому (дрони й ракети з літаків). Пускових: ${adState.launchers.filter((l) => l.kind === 'launcher').length}/15.</p></div>`;
  const drones = adState.strike.filter((s) => s.kind === 'drone' && (s.unlocked || s.stock)), missiles = adState.strike.filter((s) => s.kind === 'missile' && (s.unlocked || s.stock)), planes = adState.planes.filter((p) => Math.hypot(p.x - L.x, p.y - L.y) <= 6);
  return `<div class="card pad"><h3>${ico(L.kind, 22)} ${L.kind === 'launcher' ? 'Пускова установка' : 'Аеродром'} <span class="muted">(${L.x}, ${L.y})</span></h3>
    <h4 style="margin:6px 0 4px">Запуск дронів</h4>${drones.length ? `<div class="row"><select id="lsi" style="width:auto">${drones.map((d) => `<option value="${d.k}" ${launchSel.item === d.k ? 'selected' : ''}>${esc(d.n)} · ${d.stock} шт · ${d.range} кл.</option>`).join('')}</select><input id="lsn" type="number" min="1" max="10" value="${launchSel.count}" style="width:64px" title="кількість"><button class="sm" id="lsgo">Обрати ціль і пуск</button></div>` : '<div class="muted">Немає досліджених дронів (Технології → Безпілотники).</div>'}
    ${L.kind === 'airfield' ? `<h4 style="margin:10px 0 4px">Запуск ракети з літака</h4>${missiles.length ? (planes.length ? `<div class="row"><select id="lpu" style="width:auto">${planes.map((p) => `<option value="${p.id}" data-max="${p.max || 1}" title="${esc(p.pd || '')}" ${p.busy ? 'disabled' : ''}>${esc(p.name)} · ${UTN[p.type] || ''} (до ${p.max || 1} рак.)${p.busy ? ' (у польоті)' : ''}</option>`).join('')}</select><select id="lpm" style="width:auto">${missiles.map((m) => `<option value="${m.k}">${esc(m.n)} · ${m.stock} шт · ${m.range} кл.</option>`).join('')}</select><select id="lpn" style="width:auto"></select><button class="sm" id="lpgo">Обрати ціль і виліт</button></div><p class="hint">Літак летить до цілі, за дальністю ракети пускає її й повертається. Бомбардувальники несуть до 4 ракет, але їх легко збити; винищувачі — 1 ракету, зате швидкі й маневрові. По рухомому підрозділу ракета доводиться за його поточною позицією.</p>` : '<div class="muted">На цьому аеродромі немає авіаційних підрозділів.</div>') : '<div class="muted">Немає досліджених ракет (Технології → Ракети).</div>'}` : ''}
    <div class="row" style="margin-top:8px"><button class="ghost sm" id="lsx">Закрити</button></div></div>`;
}
function bindAdPanel() {
  document.querySelectorAll('[data-adk]').forEach((x) => x.onclick = () => { adPlaceKind = adPlaceKind === x.dataset.adk ? null : x.dataset.adk; renderSide(); });
  const g = $('#adgo'); if (g) g.onclick = () => { if (!adPlaceKind) return toast('Спочатку обери засіб у списку', true); setMode({ kind: 'adplace', adk: adPlaceKind }); };
  const ls = $('#lsgo'); if (ls) ls.onclick = () => { launchSel.item = $('#lsi').value; launchSel.count = +$('#lsn').value || 1; setMode({ kind: 'target', what: 'drone', from: selLaunch, item: launchSel.item, count: launchSel.count }); };
  const lpu = $('#lpu'), lpn = $('#lpn'); if (lpu && lpn) { const fill = () => { const o = lpu.selectedOptions[0], mx = o ? +o.dataset.max || 1 : 1, cur = +lpn.value || 1; lpn.innerHTML = Array.from({ length: mx }, (_, i) => `<option value="${i + 1}" ${i + 1 === Math.min(cur, mx) ? 'selected' : ''}>${i + 1} ${i ? (i < 4 ? 'ракети' : 'ракет') : 'ракета'}</option>`).join(''); }; fill(); lpu.onchange = fill; }
  const lp = $('#lpgo'); if (lp) lp.onclick = () => setMode({ kind: 'target', what: 'missile', from: selLaunch, item: $('#lpm').value, count: +$('#lpn').value, unit: +$('#lpu').value });
  const lx = $('#lsx'); if (lx) lx.onclick = () => { selLaunch = null; renderSide(); };
}
// клік на мапі в режимах ППО/ударів; true — оброблено
async function mapClick3(e, c) {
  if (mode.kind === 'adplace') { const k = mode.adk; await act(async () => { await api('ad/place', { kind: k, x: c.x, y: c.y }); toast('Засіб розміщено'); await Promise.all([loadAD(), loadADState()]); drawMap(); renderSide(); }); return true; }
  if (mode.kind === 'target') {
    const m = mode; let t; try { t = (await api(`air/target?x=${c.x}&y=${c.y}`)).target; } catch (er) { toast(er.message, true); return true; } if (!t) { toast('Тут немає цілі: клікни по ворожому об’єкту, ППО, місту або підрозділу', true); return true; }
    if (!confirm(`${m.what === 'drone' ? `Запустити ${m.count} × ${(adState.strike.find((s) => s.k === m.item) || {}).n}` : `Виліт з ракетами (${m.count})`} по цілі: ${t.name} (${t.owner})?${t.war ? '' : '\nВи не воюєте з цією державою — удар оголосить війну.'}`)) return true;
    const body = { from: m.from, item: m.item, count: m.count, unit: m.unit, x: t.x, y: t.y, ttype: t.type, tid: t.id };
    await act(async () => { const r = await orderApi(m.what === 'drone' ? 'air/launch' : 'air/strike', body); toast(m.what === 'drone' ? `Пуск: ${r.n} дронів на «${r.target}»` : `Літак вилетів на «${r.target}»`); setMode({ kind: 'idle' }); await Promise.all([loadADState(), loadFlights()]); renderSide(); }); return true;
  }
  if (layer === 'drones' || layer === 'air') {
    const rr = cv.getBoundingClientRect(), px = (q0) => Math.hypot(view.x + (q0.x + .5) * land.cell * view.s - (e.clientX - rr.left), view.y + (q0.y + .5) * land.cell * view.s - (e.clientY - rr.top));
    if (adState) { const L = adState.launchers.find((l) => px(l) < 12); if (L) { selLaunch = L.id; renderSide(); return true; } }
    const s = adSites.find((q0) => q0.own && px(q0) < 11); if (s) { openAdSite(s); return true; }
  }
  if (layer !== 'resources' && layer !== 'facilities') { const ct = cityAt(e); if (ct && !(mode.kind !== 'idle')) { openCity(ct.id); return true; } }
  return false;
}
function openAdSite(s) {
  const st = (adState && adState.sites.find((x) => x.id === s.id)) || s;
  openModal(`<h3>${ico(s.kind, 28)} ${esc(s.name)}</h3><div class="muted">(${s.x}, ${s.y})${st.broken ? ' · <span class="neg">несправний</span>' : ''}</div>${s.move ? `<div class="warn" style="margin:8px 0">Переїжджає на (${s.move.tx}, ${s.move.ty}) — прибуде через ${nf(Math.max(0, s.move.arr - nowDay()), 2)} доби гри. У дорозі не стріляє й не бачить цілі.</div>` : ''}
    ${st.max ? `<div style="margin:8px 0">Боєкомплект: <b>${Math.floor(st.ammo)}</b> з ${st.max} · вишкіл розрахунку: <b>${Math.round(st.skill)}</b>/90</div>` : `<div style="margin:8px 0">Дальність виявлення: <b>${s.rr || s.r}</b> кл.</div>`}
    <p class="hint">Шанс збити залежить від виучки розрахунку, наявності радара, кількості цілей і хитрощів ворога. Без радарного покриття далекобійні комплекси не бачать ціль.</p>
    <div class="row">${st.max ? `<button class="sm" id="adtr">Навчання розрахунку (+10, ${short((adState || {}).trainCost || 2e6)} $)</button>` : ''}${s.move ? '' : '<button class="ghost sm" id="admv">Перемістити</button>'}<button class="danger sm" id="adrm">Прибрати на склад</button><button class="ghost sm" id="adcl">Закрити</button></div>`);
  $('#adcl').onclick = closeModal; const tr = $('#adtr'); if (tr) tr.onclick = () => act(async () => { await api('ad/train', { id: s.id }); closeModal(); await loadADState(); }, 'Розрахунок підготовлено');
  $('#adrm').onclick = () => act(async () => { await api('ad/remove', { id: s.id }); closeModal(); await Promise.all([loadAD(), loadADState()]); drawMap(); renderSide(); }, 'Засіб повернуто на склад');
  { const mv = $('#admv'); if (mv) mv.onclick = () => { closeModal(); setMode({ kind: 'admove', id: s.id }); }; }
}

// ---------- ліва панель: місто ----------
async function openCity(id) {
  let d; try { d = await api('city/info?id=' + id); } catch (e) { return toast(e.message, true); }
  const own = d.owner, near = d.near.map((n) => `${ico(n.kind, 18)} ${esc(n.name)} ×${n.n}`).join('<br>') || '<span class="muted">немає</span>';
  openDrawer(`<div class="dhead">${ico(d.capital ? 'capital' : 'city', 40)}<div><h2 style="margin:0">${esc(d.name)}</h2><div class="muted">${d.capital ? 'Столиця · ' : ''}рівень ${d.level} з ${d.maxLevel} · (${d.x}, ${d.y})</div></div></div>
    <div class="stat-grid"><div><span class="muted">Населення</span><b>${exact(d.pop)}</b><small class="muted">місткість ${exact(d.cap)}</small></div><div><span class="muted">Власник</span><b>${own ? `<span class="sw" style="background:${esc(own.color)}"></span>${esc(own.name)}` : 'нейтральна земля'}</b><small class="muted">${own ? (own.bot ? 'керує ШІ' : 'гравець') : 'ще нічия'}</small></div>
      <div><span class="muted">Бонус оборони</span><b>+${d.defense}%</b><small class="muted">для військ у радіусі 4 кл.</small></div><div><span class="muted">Пошкодження</span><b class="${d.dmg > 0 ? 'neg' : ''}">${d.dmg}%</b><small class="muted">відновлюється з часом</small></div></div>
    ${d.mood != null ? `<div class="card pad"><div class="row"><span class="grow">Настрій містян: <b class="${d.mood >= 60 ? 'pos' : d.mood < 30 ? 'neg' : ''}">${d.mood}</b>/100</span>${d.riot ? '<b class="neg">БУНТ</b>' : ''}${d.siege ? ` <b class="neg">ОБЛОГА ${d.siege} д.</b>` : ''}</div>${d.ext ? `<div class="muted" style="font-size:13px;margin-top:4px">Губернатор: ${d.ext.gov ? esc(d.ext.gov.name) : 'немає'} · податок: ${['немає', 'низький', 'середній', 'високий'][d.ext.tax]} · ${exact(d.ext.income)} $/добу</div><button class="ghost sm" id="cman" style="margin-top:6px">Керувати містом (податки, будівлі, губернатор)</button>` : ''}</div>` : ''}
    ${d.occupiedBy ? `<div class="card pad neg">Місто окуповане військами ${esc(d.occupiedBy)}.</div>` : ''}
    <div class="card pad"><h3>Околиці</h3><div>${d.river ? '🌊 поруч річка · ' : ''}${d.coast ? '⚓ узбережжя · ' : ''}засновано на добу ${Math.floor(d.founded || 0)}</div><h4 style="margin:10px 0 4px">Об’єкти поблизу (15 кл.)</h4><div>${near}</div>
      ${d.mine ? `<h4 style="margin:10px 0 4px">Для власника</h4><div>Гарнізон поруч: <b>${d.garrison.units}</b> підрозділів (${exact(d.garrison.personnel)} о/с)</div><div>До найближчого джерела постачання: <b>${d.supplyDist}</b> кл.</div>` : ''}</div>
    ${d.hist.length ? `<div class="card pad"><h3>Історія власників</h3>${d.hist.slice().reverse().map((h) => `<div><span class="muted">доба ${h.day}</span> — ${esc(h.name)}</div>`).join('')}</div>` : ''}
    ${d.mine ? `<div class="card pad"><h3>Керування</h3><label for="cnm">Назва міста</label><div class="row"><input id="cnm" maxlength="30" value="${esc(d.name)}" class="grow"><button class="sm" id="cren">Перейменувати</button></div>
      <div class="row" style="margin-top:10px">${d.upCost ? `<button class="sm" id="cup" ${d.queued ? 'disabled' : ''}>${d.queued ? 'Покращення вже будується' : `Покращити до рівня ${d.level + 1} (${short(d.upCost)} $, ${nf(d.upDays, 1)} діб)`}</button>` : ''}<button class="ghost sm" id="cgo">Показати на мапі</button></div></div>` : `<div class="row"><button class="ghost sm" id="cgo">Показати на мапі</button>${own && me.country && own.id !== me.country.id ? `<button class="ghost sm" id="cctry">Вікно держави</button>` : ''}</div>`}`, 'city');
  const go = $('#cgo'); if (go) go.onclick = () => { const r = cv.getBoundingClientRect(), s = view.fs * 6; view.s = s; view.x = r.width / 2 - (d.x + .5) * land.cell * s; view.y = r.height / 2 - (d.y + .5) * land.cell * s; drawMap(); };
  const ren = $('#cren'); if (ren) ren.onclick = () => act(async () => { await api('city/rename', { id: d.id, name: $('#cnm').value }); await loadCities(); drawMap(); openCity(id); }, 'Місто перейменовано');
  const up = $('#cup'); if (up) up.onclick = () => act(async () => { const f = myFacs.find((q0) => q0.x === d.x && q0.y === d.y) || (await api('fac/list')).facilities.find((q0) => q0.x === d.x && q0.y === d.y); await api('fac/upgrade', { id: f.id }); openCity(id); await refreshMe(); }, 'Покращення додано до черги');
  const cc = $('#cctry'); if (cc) cc.onclick = () => openCountry(own.id);
  const cm = $('#cman'); if (cm) cm.onclick = () => { closeDrawer(); window.meSub = 'cities'; showTab('me'); };
}

// ---------- бічна панель: армії (швидкі кнопки як у HOI4) ----------
let armyQuick = null;
async function loadArmyQuick() { if (!me || !me.country) { armyQuick = null; return; } try { armyQuick = await api('armies'); } catch { armyQuick = null; } }
function armyQuickHtml() {
  if (!armyQuick || !armyQuick.armies.length) return ''; const tn = { none: 'без задачі', defend: 'оборона зони', front: 'фронт' };
  return `<div class="card pad armyq"><h3>${ico('army', 20, '#5b3f8c')} Армії</h3>${armyQuick.armies.map((a) => `<div class="aq"><div class="row" style="gap:6px"><b class="grow">${esc(a.name)}</b><span class="muted" style="font-size:12px">${a.units.length}/${armyQuick.max} · ${tn[a.task]}${a.task === 'front' ? ' · ' + esc(a.foeName) : ''}${a.attacking ? ' · <b class="neg">наступ</b>' : ''}</span></div>
    <div class="row" style="gap:4px;margin-top:4px"><button class="ghost sm" data-aqd="${a.id}" title="Виділити зону оборони пензликом">Оборона</button><select class="sm" data-aqf="${a.id}" style="width:auto;padding:3px 6px"><option value="">Фронт…</option>${armyQuick.neighbours.map((n) => `<option value="${n.id}" ${a.foe === n.id && a.task === 'front' ? 'selected' : ''}>${esc(n.name)}${n.war ? ' ⚔' : ''}</option>`).join('')}</select>${a.task === 'front' ? `<button class="ghost sm" data-aqa="${a.id}" title="Накреслити зону прориву">Атака</button><button class="sm arrowbtn" data-aqg="${a.id}" title="Почати наступ" ${a.attack ? '' : 'disabled'}>${ico('arrow', 18, '#b91c1c')}</button>${a.attack && !a.attacking ? `<button class="ghost sm" data-aqc="${a.id}" title="Прибрати накреслену зону прориву">✕ зону</button>` : ''}` : ''}${a.task !== 'none' ? `<button class="ghost sm" data-aqs="${a.id}" title="Зупинити">■</button>` : ''}</div></div>`).join('')}</div>`;
}
function bindArmyQuick() {
  const after = async (msg) => { if (msg) toast(msg); await Promise.all([loadArmyQuick(), loadArmyDraw()]); drawMap(); renderSide(); };
  document.querySelectorAll('[data-aqd]').forEach((x) => x.onclick = () => setMode({ kind: 'armyzone', aid: +x.dataset.aqd, purpose: 'defend' }));
  document.querySelectorAll('[data-aqa]').forEach((x) => x.onclick = () => setMode({ kind: 'armyzone', aid: +x.dataset.aqa, purpose: 'attack' }));
  document.querySelectorAll('[data-aqf]').forEach((x) => x.onchange = () => { if (!x.value) return; act(async () => { await api('armies/task', { id: +x.dataset.aqf, task: 'front', foe: +x.value }); await after('Армію поставлено на фронт'); }); });
  document.querySelectorAll('[data-aqg]').forEach((x) => x.onclick = () => act(async () => { await api('armies/go', { id: +x.dataset.aqg }); await after('Наступ!'); }));
  document.querySelectorAll('[data-aqc]').forEach((x) => x.onclick = () => act(async () => { await api('armies/clearzone', { id: +x.dataset.aqc }); await after('Зону прориву прибрано'); }));
  document.querySelectorAll('[data-aqs]').forEach((x) => x.onclick = () => act(async () => { await api('armies/task', { id: +x.dataset.aqs, task: 'none' }); await api('armies/halt', { id: +x.dataset.aqs }); await after('Армію зупинено'); }));
}
// пензлик зони армії
async function armyZoneCommit() {
  if (!brush.size) return toast('Спочатку намалюй зону', true); const m = mode, cells = [...brush];
  act(async () => { if (m.purpose === 'defend') await api('armies/task', { id: m.aid, task: 'defend', zone: cells }); else await api('armies/attackzone', { id: m.aid, zone: cells }); toast(m.purpose === 'defend' ? 'Зону оборони призначено' : 'Зону прориву накреслено. Натисни стрілку, щоб почати наступ'); setMode({ kind: 'idle' }); await Promise.all([loadArmyQuick(), loadArmyDraw()]); drawMap(); renderSide(); });
}
