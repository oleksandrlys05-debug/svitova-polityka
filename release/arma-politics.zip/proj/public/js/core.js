// Спільні функції, довідники, підказки, повідомлення
const $ = (s) => document.querySelector(s);
// дії від імені маріонетки: зовнішньополітичні запити йдуть з ?as=<id>
let ACT_AS = null; const ACT_P = ['diplo/', 'bloc/', 'trade/', 'sanction/', 'embargo/', 'conf/', 'war/justify', 'world/vote', 'world/propose', 'market/', 'vassal/info', 'me/as'];
const asQ = (p) => (ACT_AS && ACT_P.some((x) => p.startsWith(x)) ? (p.includes('?') ? '&' : '?') + 'as=' + ACT_AS.id : '');
const api = async (p, body) => { const r = await fetch('/api/' + p + asQ(p), body !== undefined ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) } : {}); const j = await r.json().catch(() => ({})); if (r.status === 426) needUpdate(j); if (!r.ok) throw Object.assign(new Error(j.error || 'Помилка'), { status: r.status }); return j; };
// (21.1) хост оновив гру, а ця програма ще стара — закриваємо гру екраном «Спершу оновіть гру»
function needUpdate(j) { if (document.getElementById('needupd')) return; const d = document.createElement('div'); d.id = 'needupd'; d.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(10,8,20,.92);display:flex;align-items:center;justify-content:center;color:#ece9f7;font:16px/1.6 system-ui,sans-serif';
  d.innerHTML = `<div style="max-width:560px;background:#1b1830;border:1px solid #2e2a48;border-radius:20px;padding:26px 30px"><h2 style="margin:0 0 8px">Спершу оновіть гру</h2><p>${(j && j.error) || 'Вийшла нова версія гри.'}</p><p>Закрийте програму й відкрийте знову — на головному екрані натисніть «Оновити зараз». Це кілька секунд, збереження не зачіпаються.</p>${window.desktop && window.desktop.toLauncher ? '<button id="needupdb" style="padding:10px 16px;border-radius:12px;border:0;background:#7c3aed;color:#fff;font-weight:600;cursor:pointer">До головного меню програми</button>' : ''}</div>`;
  document.body.appendChild(d); const b = document.getElementById('needupdb'); if (b) b.onclick = () => window.desktop.toLauncher(); }
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const exact = (n) => Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
const nf = (n, d = 2) => (+(+n).toFixed(d)).toLocaleString('uk-UA');
const short = (n) => { const a = Math.abs(n); return a >= 1e9 ? nf(n / 1e9) + ' млрд' : a >= 1e6 ? nf(n / 1e6) + ' млн' : a >= 1e3 ? nf(n / 1e3) + ' тис.' : nf(n, 0); };
const pc = (x) => nf(x * 100, 1) + '%';
const lvl = (v) => v < 25 ? 'дуже низька' : v < 50 ? 'низька' : v < 75 ? 'помірна' : 'висока';
const typing = () => /INPUT|TEXTAREA|SELECT/.test((document.activeElement || {}).tagName || '');
let me = null;
const toast = (msg, bad) => { const t = document.createElement('div'); t.className = 'toast' + (bad ? ' bad' : ''); t.textContent = msg; $('#toasts').append(t); setTimeout(() => t.remove(), bad ? 6000 : 4500); };
const act = async (fn, okMsg) => { try { const r = await fn(); if (okMsg) toast(okMsg); return r; } catch (e) { toast(e.message, true); } };
// власне вікно для введення тексту (замість window.prompt, якого немає в програмі для Windows)
const askText = (title, def = '') => new Promise((ok) => {
  openModal(`<h3 style="margin-top:0">${esc(String(title))}</h3><input id="askv" value="${esc(def == null ? '' : String(def))}" maxlength="300" style="margin:8px 0"><div class="row"><button id="askok">Гаразд</button><button class="ghost" id="askno">Скасувати</button></div>`);
  const i = $('#askv'); i.focus(); i.select(); const done = (v) => { closeModal(); ok(v); };
  $('#askok').onclick = () => done(i.value); $('#askno').onclick = () => done(null); i.onkeydown = (e) => { if (e.key === 'Enter') done(i.value); if (e.key === 'Escape') done(null); }; });
window.askText = askText;
const openModal = (html) => { $('#modal').innerHTML = `<div class="box">${html}</div>`; $('#modal').classList.remove('hidden'); };
const openBig = (html) => { $('#modal').innerHTML = `<div class="box big"><button class="ghost sm xbtn" id="mx">✕ Закрити</button>${html}</div>`; $('#modal').classList.remove('hidden'); $('#mx').onclick = closeModal; $('#modal').onmousedown = (e) => { if (e.target.id === 'modal') closeModal(); }; };
function mountFx() { if (window.FD) return Promise.resolve(window.FD); return api('fac/list').then((d) => (window.FD = d.defs)).catch(() => ({})); }
const closeModal = () => { $('#modal').classList.add('hidden'); $('#modal').onmousedown = null; window.cwClosed && window.cwClosed(); };
// діапазон від розвідки: {exact} | {lo,hi} | null
const rng = (r, f) => !r ? '<span class="muted">немає даних</span>' : r.exact !== undefined ? f(r.exact) : `${f(r.lo)} – ${f(r.hi)}`;

// ---- довідники ----
const STAT = {
  gdp: { n: 'ВВП', t: 'usd' }, budget: { n: 'Доходи бюджету', t: 'usd' }, expenses: { n: 'Витрати бюджету', t: 'usd' }, debt: { n: 'Державний борг', t: 'usd' }, treasury: { n: 'Казна', t: 'usd' }, population: { n: 'Населення', t: 'pop' },
  civFactories: { n: 'Цивільні фабрики', t: 'num' }, milFactories: { n: 'Військові заводи', t: 'num' }, shipyards: { n: 'Верфі', t: 'num' }, infrastructure: { n: 'Інфраструктура', t: 'pct' },
  warSupport: { n: 'Підтримка війни', t: 'pct' }, stability: { n: 'Стабільність', t: 'pct' }, presidentSupport: { n: 'Підтримка президента', t: 'pct' }, happy: { n: 'Щастя людей', t: 'pct' }, counterIntel: { n: 'Контррозвідка', t: 'pct' } };
const RESM = {
  aluminium: { n: 'Алюміній', c: '#8896a5', d: 'Потрібен для літаків, ракет і легкої техніки.' }, chromium: { n: 'Хром', c: '#5d8aa8', d: 'Потрібен для броні, танків і верстатів.' },
  oil: { n: 'Нафта', c: '#33363b', d: 'Видобувається нафтокачками. НПЗ переробляє її на паливо.' }, rubber: { n: 'Гума', c: '#4b4f55', d: 'Потрібна для вантажівок, коліс і літаків.' },
  steel: { n: 'Сталь', c: '#6f7a86', d: 'Виплавляється на сталеливарнях з використанням палива. Основа зброї, техніки, кораблів і будівництва.' }, tungsten: { n: 'Вольфрам', c: '#8a6d3f', d: 'Потрібен для боєприпасів і броні.' },
  food: { n: 'Їжа', c: '#6f9a34', d: 'Вирощується на фермах (трохи дає й сама земля). Її їсть населення; міста — більше. Без їжі — голод: падають стабільність і населення.' },
  fuel: { n: 'Паливо', c: '#c47f1f', d: 'Виробляється на НПЗ з нафти (плюс невеликий кустарний видобуток). Потрібне техніці, флоту, авіації, сталеливарням і електростанціям.' },
  cotton: { n: 'Бавовна', c: '#b8a77a', d: 'Сировина для одягу. Вирощується на бавовняних плантаціях — лише на родовищах бавовни.' },
  clothing: { n: 'Одяг', c: '#8e5ea2', d: 'Цивільний одяг і форма для армії. Шиють цивільні фабрики з бавовни (Виробництво → Цивільне виробництво). Брак: −стабільність, армія втрачає мораль.' },
  medicine: { n: 'Ліки', c: '#d9534f', d: 'Виробляють цивільні фабрики з нафти. Потрібні населенню, армії — особливо на війні. Брак: росте смертність.' },
  goods: { n: 'Товари вжитку', c: '#2f9e8f', d: 'Побутова техніка, авто, меблі: цивільні фабрики зі сталі, гуми й алюмінію. Брак: −стабільність, −підтримка, −ВВП.' },
  power: { n: 'Електроенергія', c: '#d4a017', d: 'Дають електростанції (з палива) і ГЕС (біля річок). Майже не запасається. Брак: фабрики й будівництво сповільнюються, люди незадоволені.' } };
let CONS = { civFactories: { steel: .15 }, milFactories: { steel: .4, aluminium: .1, tungsten: .1, chromium: .1, rubber: .1 }, shipyards: { steel: .3, rubber: .05, oil: .1 } }; // оновлюється з сервера (me.cons)
const consume = (st, r) => (st.flow && st.flow[r] ? st.flow[r].cons : Object.keys(CONS).reduce((n, b) => n + (st[b] || 0) * (CONS[b][r] || 0), 0));
const SRC = { food: 'Ферми (і трохи — сама земля)', oil: 'Нафтокачка', aluminium: 'Бокситова шахта', chromium: 'Хромова шахта', rubber: 'Каучукова плантація', steel: 'Сталеливарня', tungsten: 'Вольфрамова шахта', fuel: 'НПЗ (з нафти) і кустарне виробництво', cotton: 'Бавовняна плантація', clothing: 'Цивільні фабрики (з бавовни) і трохи кустарі', medicine: 'Цивільні фабрики (з нафти) і трохи кустарі', goods: 'Цивільні фабрики (сталь, гума, алюміній)', power: 'Електростанція (паливо), ГЕС (річка)' };
const GLYPH = { aluminium: 'Al', chromium: 'Cr', steel: 'Fe', tungsten: 'W' };
const SVGS = { food: '<path d="M15 25V9" stroke="#fff" stroke-width="2.2"/><path d="M15 11c-3-1-5-4-5-6 3 0 5 2 5 6zm0 0c3-1 5-4 5-6-3 0-5 2-5 6zm0 6c-3-1-6-4-6-6 3 0 6 2 6 6zm0 0c3-1 6-4 6-6-3 0-6 2-6 6z" fill="#fff"/>', oil: '<path d="M15 5C15 5 7 14 7 19a8 8 0 0016 0C23 14 15 5 15 5z" fill="#fff"/>', rubber: '<circle cx="15" cy="15" r="8.5" fill="none" stroke="#fff" stroke-width="4.5"/>', fuel: '<path d="M9 8h9l3 3v12H9z" fill="#fff"/><rect x="12" y="4" width="5" height="4" fill="#fff"/>',
  cotton: '<circle cx="11" cy="12" r="4" fill="#fff"/><circle cx="19" cy="12" r="4" fill="#fff"/><circle cx="15" cy="8" r="4" fill="#fff"/><path d="M15 14v10" stroke="#fff" stroke-width="2"/>', clothing: '<path d="M10 6l-5 4 3 4 2-1v11h10V13l2 1 3-4-5-4c-1 2-3 3-5 3s-4-1-5-3z" fill="#fff"/>',
  medicine: '<path d="M12 6h6v6h6v6h-6v6h-6v-6H6v-6h6z" fill="#fff"/>', goods: '<rect x="7" y="11" width="16" height="12" rx="1" fill="#fff"/><path d="M11 11V8a4 4 0 018 0v3" fill="none" stroke="#fff" stroke-width="2"/>', power: '<path d="M17 3L8 17h6l-2 10 9-14h-6z" fill="#fff"/>' };
const icon = (k) => `<span class="ric" style="--c:${RESM[k].c}"><svg viewBox="0 0 30 30">${GLYPH[k] ? `<text x="15" y="20.5" text-anchor="middle" font-size="14" font-weight="700" fill="#fff" font-family="system-ui,sans-serif">${GLYPH[k]}</text>` : SVGS[k]}</svg></span>`;
const fmt = (k, v) => { const t = STAT[k].t; return t === 'usd' ? short(v) + ' $' : t === 'pop' ? short(v) : t === 'pct' ? nf(v == null ? 50 : v, 1) + '%' : nf(v, 0); };
const UTN = { infantry: 'Піхота', mechanized: 'Механізована піхота', armor: 'Танковий', artillery: 'Артилерія', recon: 'Розвідка', antiair: 'ППО', navy: 'Флот (ескадра)', submarines: 'Підводний флот', fighters: 'Винищувальна авіація', bombers: 'Бомбардувальна авіація' };
const UTL = { infantry: 'П', mechanized: 'М', armor: 'Т', artillery: 'А', recon: 'Р', antiair: 'З', navy: 'Ф', submarines: 'Пл', fighters: 'Вн', bombers: 'Бм' };
const UTD = { infantry: 'land', mechanized: 'land', armor: 'land', artillery: 'land', recon: 'land', antiair: 'land', navy: 'sea', submarines: 'sea', fighters: 'air', bombers: 'air' };
const EQN = { small_arms: 'Стрілецька зброя', support: 'Підтримка', trucks: 'Вантажівки', apc: 'БТР', artillery: 'Артилерія', tanks: 'Танки', aa_guns: 'Зенітні гармати', destroyers: 'Есмінці', submarines: 'Підводні човни', fighters: 'Винищувачі', bombers: 'Бомбардувальники' };
const EFFN = { attack: 'Атака', defense: 'Оборона', supply: 'Постачання', morale: 'Мораль', research_speed: 'Швидкість досліджень', construction_speed: 'Швидкість будівництва', gdp_growth: 'Ріст ВВП (за рік)', military_production: 'Військове виробництво' };
const effText = (k, v) => { let [b, t] = k.split(':'); let n = EFFN[b] || (b === 'res_prod' ? 'Видобуток: ' + (RESM[t] ? RESM[t].n.toLowerCase() : t) : b); if (t && b !== 'res_prod') n += ' (' + (UTN[t] || t).toLowerCase() + ')'; return `${n} ${v > 0 ? '+' : '−'}${b === 'supply' && Math.abs(v) >= 1 || b === 'morale' ? Math.abs(v) : nf(Math.abs(v) * 100, 1) + '%'}`; };

// ---- підказки при наведенні ----
const infoEl = $('#info'), hideInfo = () => infoEl.classList.add('hidden');
function bindInfo(el, get) {
  el.onmousemove = (e) => {
    const tr = e.target.closest('[data-k]'), i = tr && me && get(tr); if (!i) return hideInfo();
    infoEl.innerHTML = `<h4>${esc(i.t)}</h4>${i.r.map((x) => `<div class="ir"><span>${x[0]}</span><b>${x[1]}</b></div>`).join('')}${i.d ? `<p>${i.d}</p>` : ''}`; infoEl.classList.remove('hidden');
    const w = infoEl.offsetWidth, h = infoEl.offsetHeight; let x = e.clientX + 20, y = e.clientY + 20; if (x + w > innerWidth - 8) x = e.clientX - w - 20; if (y + h > innerHeight - 8) y = innerHeight - h - 8; infoEl.style.left = x + 'px'; infoEl.style.top = y + 'px';
  };
  el.onmouseleave = hideInfo;
}
// ---- тема ----
let appReady = false;
const setTheme = (t) => { document.documentElement.dataset.theme = t; try { localStorage.theme9 = t; } catch {} if (appReady && window.drawMap) drawMap(); };
try { setTheme(localStorage.theme9 || 'dark'); } catch { setTheme('dark'); }
$('#theme').onclick = () => setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');

// ігрова дата: доба 0 = 01/01/0001, григоріанський календар
function gdate(d, withTime) { d = +d || 0; const n = Math.floor(d), dt = new Date(0); dt.setUTCHours(0, 0, 0, 0); dt.setUTCFullYear(1, 0, Math.max(1, n)); const p2 = (v) => String(v).padStart(2, '0'); let s = `${p2(dt.getUTCDate())}/${p2(dt.getUTCMonth() + 1)}/${String(dt.getUTCFullYear()).padStart(4, '0')}`; if (withTime) { const m = Math.floor((d - n) * 1440); s += ` ${p2(Math.floor(m / 60))}:${p2(m % 60)}`; } return s; }
