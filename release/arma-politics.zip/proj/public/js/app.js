// Запуск: вхід, вкладки, годинник, сповіщення, події
let reg = false, tab = 'map', es = null;
const TABS = [['map', 'Мапа'], ['me', 'Моя держава'], ['diplo', 'Дипломатія'], ['parl', 'Парламент'], ['market', 'Торгівля'], ['news', 'Новини'], ['war', 'Війна'], ['admin', 'Адмін']];
const VIEW = { me: '#v-me', diplo: '#v-diplo', parl: '#v-parl', market: '#v-market', news: '#v-news', war: '#v-war', admin: '#v-admin' }, RENDER = { parl: () => renderParl(), me: () => renderMe(), diplo: () => renderDiplo(), market: () => renderMarket(), news: () => renderNews(), war: () => renderWar(), admin: () => renderAdmin() };
const showAuth = () => { ['#top', '#app'].forEach((s) => $(s).classList.add('hidden')); $('#auth').classList.remove('hidden'); };
$('#swap').onclick = () => { reg = !reg; $('#dRow').classList.toggle('hidden', !reg); $('#go').textContent = reg ? 'Зареєструватись' : 'Увійти'; $('#swap').textContent = reg ? 'Вже є акаунт' : 'Створити акаунт'; $('#aerr').textContent = ''; };
$('#go').onclick = async () => { try { const pick = reg && window.mapChoice ? mapChoice : undefined, r = await api(reg ? 'register' : 'login', { name: $('#n').value, password: $('#p').value, discord: $('#d').value, email: ($('#em') || {}).value || '', map: pick }); if (r && r.restart) return waitRestart(r.map); start(); } catch (e) { $('#aerr').textContent = e.message; } };
// світ створюється заново (вибір мапи, відновлення з копії): чекаємо, поки сервер перезапуститься, і оновлюємо сторінку
function waitRestart(mapId, text) {
  let o = $('#restartBox'); if (!o) { o = document.createElement('div'); o.id = 'restartBox'; document.body.appendChild(o); }
  o.innerHTML = `<div class="spinner"></div><div>${text || 'Створюю світ на новій мапі…'}</div><small class="muted">Сторінка оновиться сама за кілька секунд.</small>`;
  const t0 = Date.now(); let seenDown = false;
  const poll = async () => { try { const r = await fetch('/api/ping', { cache: 'no-store' }); const p = await r.json(); if (!p.restarting && (seenDown || (mapId && p.map === mapId)) && Date.now() - t0 > 1500) return location.reload(); } catch { seenDown = true; } setTimeout(poll, 900); };
  setTimeout(poll, 1200);
}
// перший гравець (адмін) обирає мапу світу
window.mapChoice = null;
async function initMapPick() {
  let D; try { D = await (await fetch('/api/maps')).json(); } catch { return; } if (!D.fresh || !D.list || D.list.length < 2) return;
  window.mapChoice = D.current; if (!reg) $('#swap').click();
  const box = $('#mapPick'); box.classList.remove('hidden'); $('#auth').classList.add('wide');
  const groups = [...new Set(D.list.map((m) => m.group))];
  box.innerHTML = `<h3 style="margin:14px 0 4px">Ви перший гравець — оберіть мапу світу</h3><p class="muted" style="margin:0 0 8px;font-size:13px">Мапу можна змінити й пізніше (Адмін → Новий світ), але це почне гру спочатку.</p>${groups.map((g) => `<div class="mpg">${esc(g)}</div><div class="mpgrid">${D.list.filter((m) => m.group === g).map((m) => `<button type="button" class="mpcard ${m.id === D.current ? 'on' : ''}" data-mp="${m.id}"><img src="${m.img}" alt="" loading="lazy"><b>${esc(m.name)}</b><small>${esc(m.desc)}</small><span class="muted">${m.cities} міст${m.rivers ? ` · ${m.rivers} річок` : ''}${m.presets ? ` · ${m.presets} держав-ботів` : ''}</span></button>`).join('')}</div>`).join('')}`;
  box.querySelectorAll('[data-mp]').forEach((x) => x.onclick = () => { window.mapChoice = x.dataset.mp; box.querySelectorAll('[data-mp]').forEach((y) => y.classList.toggle('on', y === x)); });
}
$('#p').onkeydown = (e) => { if (e.key === 'Enter') $('#go').click(); };
$('#out').onclick = async () => { await api('logout', {}); location.reload(); };
function buildNav() { $('#nav').innerHTML = TABS.filter(([k]) => k !== 'admin' || me.user.role === 'admin').map(([k, n]) => `<button data-t="${k}" class="${k === tab ? 'on' : ''}">${svgOf({ map: 'globe', me: 'flag', diplo: 'dip', parl: 'parl', market: 'coin', news: 'news', war: 'battle', admin: 'gear' }[k] || 'star')}${n}</button>`).join(''); $('#nav').querySelectorAll('button').forEach((b) => b.onclick = () => showTab(b.dataset.t)); }
function showTab(t) {
  tab = t; document.body.dataset.tab = t; hideInfo(); buildNav(); const isMap = t === 'map';
  $('#mapWrap').classList.toggle('hidden', !isMap); $('#side').classList.toggle('hidden', !isMap);
  for (const k in VIEW) $(VIEW[k]).classList.toggle('hidden', k !== t);
  if (isMap) { resizeMap(); loadUnits(); } else RENDER[t]();
}
let lastMapV = '', lastLayerRefresh = 0;
async function refreshMe(auto) {
  me = await api('me'); if (me.cons) CONS = me.cons; clock(); renderSide();
  // мапу перезавантажуємо лише коли змінилась територія чи окупація; інакше — тільки легкі дані шарів (не частіше ніж раз на 5 с)
  { const mv = me.world.mapVer + ':' + me.world.occVer, onlyOcc = lastMapV && lastMapV.split(':')[0] === String(me.world.mapVer); if (mv !== lastMapV) { lastMapV = mv; if (onlyOcc) { await loadOcc(); if (tab === 'map') drawMap(); } else await loadMap(); } else if (Date.now() - lastLayerRefresh > 5000) { lastLayerRefresh = Date.now(); Promise.all([refreshLayerData(), ['facilities', 'resources', 'drones'].includes(layer) ? loadFacs() : null]).then(() => { if (tab === 'map') drawMap(); }); } }
  loadUnits(); if (tab !== 'map' && tab !== 'admin' && !typing() && !(auto === true && autoSkip())) { lastAutoRender = Date.now(); keepScroll(() => RENDER[tab]()); }
  if (me.country) { pollBattles(); pollConfs(); pollEvents(); pollIncur(); loadAlerts(); }
}
// плавний годинник: між оновленнями сервера час іде локально щосекунди
let clockBase = { day: 1, at: Date.now(), scale: 1, paused: false };
function syncClock(w) { if (!w) return; clockBase = { day: w.day, at: Date.now(), scale: w.scale || 1, paused: !!w.paused }; }
function nowDay() { const b = clockBase; return b.paused ? b.day : b.day + (Date.now() - b.at) / 3.6e6 * b.scale; }
function clockTick() { const el = $('#clock'); if (!el || !me) return; const d = nowDay(), t = gdate(d, true).split(' '); el.innerHTML = `<b>${t[1] || ''}</b><span>${t[0]}</span><small>${clockBase.paused ? 'пауза' : `1 год = ${clockBase.scale} доб${clockBase.scale === 1 ? 'а' : clockBase.scale < 5 ? 'и' : ''}`}</small>`; }
setInterval(clockTick, 1000);
function clock() { if (!me) return; updateWarBox(); syncClock(me.world); { const pb = $('#pauseb'); if (pb) { pb.classList.toggle('hidden', me.user.role !== 'admin'); pb.innerHTML = me.world.paused ? '<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z" fill="#fff"/></svg>' : '<svg viewBox="0 0 24 24"><path d="M7 5h4v14H7zM13 5h4v14h-4z" fill="#fff"/></svg>'; pb.title = me.world.paused ? 'Продовжити гру' : 'Поставити гру на паузу'; pb.onclick = () => act(async () => { await api('admin/settings', { paused: me.world.paused ? 0 : 1 }); await refreshMe(); }); } } clockTick(); syncDP(); $('#bell').innerHTML = `<svg viewBox="0 0 24 24" width="18" height="18"><path d="M12 3a6 6 0 00-6 6v4l-2 3h16l-2-3V9a6 6 0 00-6-6zM10 19a2 2 0 004 0" fill="none" stroke="currentColor" stroke-width="2"/></svg>${me.unread ? `<span class="pill${me.unreadImp ? ' imp' : ''}">${me.unread > 99 ? '99+' : me.unread}</span>` : ''}`; }
// ---- сповіщення ----
$('#bell').onclick = () => toggleBell();
addEventListener('click', (e) => { if (!e.target.closest('#bell') && !e.target.closest('#bellPanel')) $('#bellPanel').classList.add('hidden'); });
// ---- політичні події ----
let evOpen = false;
async function pollEvents() {
  if (evOpen || !me.country) return; const d = await api('events/active').catch(() => ({ events: [] })); const e = d.events[0]; if (!e) return; evOpen = true;
  openModal(`${illus(illusFor(e.title + ' ' + e.text))}<h3>${esc(e.title)}</h3><p>${esc(e.text)}</p><p class="hint">Залишилось ${nf(e.daysLeft, 1)} діб. Інакше спрацює варіант за замовчуванням.</p>${e.options.map((o, i) => `<button class="opt" data-o="${i}" ${o.afford === false ? 'disabled title="Не вистачає коштів"' : ''}>${esc(o.text)}${o.effects.length ? `<small>${esc(o.effects.join(' · '))}</small>` : ''}${o.afford === false ? `<small class="neg">Не вистачає коштів: потрібно ${short(o.cost)} $</small>` : ''}${i === e.def ? '<small>за замовчуванням</small>' : ''}</button>`).join('')}<div class="row"><button class="ghost sm" id="evl">Вирішу пізніше</button></div>`);
  $('#modal').querySelectorAll('[data-o]').forEach((b) => b.onclick = () => act(async () => { await api('events/choose', { id: e.id, option: +b.dataset.o }); closeModal(); evOpen = false; await refreshMe(); }));
  $('#evl').onclick = () => { closeModal(); setTimeout(() => evOpen = false, 60000); };
}
// ---- живе оновлення ----
let rt = null; const later = (fn, ms = 1200) => { clearTimeout(rt); rt = setTimeout(fn, ms); };
function connect() {
  if (es) es.close(); es = new EventSource('/api/events');
  es.onmessage = (m) => { const t = m.data;
    if (t === 'chat') { const vis = window.refreshChat && tab === 'diplo', cwv = window.refreshCwChat && cwOpen(); if (vis) window.refreshChat(); if (cwv) window.refreshCwChat(); if (!vis && !cwv) if (me.country) { me.unread++; clock(); } return; }
    if (t === 'notify') { onNotify(); return; }
    if (t === 'tick') { later(async () => { me = await api('me'); if (me.cons) CONS = me.cons; clock(); loadUnits(); pollBattles(); loadAlerts(); if (tab === 'map') renderSide(); }); return; }
    if (t === 'move') { loadLive(); return; }
    if (t === 'weather') { loadWeather().then(() => { if (tab === 'map' && layer === 'weather') { drawMap(); renderSide(); } }); return; }
    if (t === 'air') { if (tab === 'map') loadFlights(); return; }
    if (t === 'convoy') { if (tab === 'map') loadConvoysMap().then(drawMap); if (tab === 'market' && window.renderConvoys) renderConvoys(); return; }
    if (t === 'battle') { pollBattles(); if (window.loadBattlesMap) loadBattlesMap(); }
    if (t === 'conf') { confRefresh(); pollConfs(); return; }
    later(() => refreshMe(true)); };
}
async function start() {
  try { me = await api('me'); } catch { showAuth(); initMapPick(); return; }
  $('#auth').classList.add('hidden'); $('#top').classList.remove('hidden'); $('#app').classList.remove('hidden'); $('#who').textContent = me.user.name;
  if (me.cons) CONS = me.cons; $('#tutb').onclick = () => tutorial(); $('#helpb').onclick = () => helpWin(); $('#tutb').innerHTML = svgOf('star'); $('#helpb').innerHTML = svgOf('book'); $('#theme').innerHTML = svgOf('sun'); loadAlerts(true); loadWeather(); initShare(); appReady = true; buildNav(); resizeMap(); clock(); renderSide(); await loadMap(); lastMapV = me.world.mapVer + ':' + me.world.occVer; loadUnits(); connect(); pollEvents(); if (me.country) { pollBattles(); pollConfs(); pollIncur(); }
  setInterval(() => { if (me && me.country) pollEvents(); }, 60000);
  // запасне оновлення (якщо події з сервера губляться через VPN чи тунель): мапа й держава раз на ~20–60 с
  let lastPing = null; setInterval(async () => { if (document.hidden) return; try { const p = await api('ping'); syncClock({ day: p.day, scale: p.scale, paused: p.paused }); clockTick(); if (lastPing && (p.mapVer !== lastPing.mapVer || p.occVer !== lastPing.occVer) && p.mapVer + ':' + p.occVer !== lastMapV) { lastMapV = p.mapVer + ':' + p.occVer; await loadMap(); if (tab === 'map') loadUnits(); } lastPing = p; if (me && me.country) pollBattles(); if (!es || es.readyState === 2) connect(); } catch { /* сервер недоступний */ } }, 20000);
  setInterval(() => { if (!document.hidden && me) refreshMe(true); }, 60000);
  if (me.country && !tutSeen()) setTimeout(() => tutorial(), 600);
}
start();

// зберігає позицію прокрутки при автооновленні вкладки (щоб не кидало вгору)
let lastAutoRender = 0;
// автооновлення вкладки не частіше ніж раз на 6 с, не під час наведення на підказку чи затискання миші
function autoSkip() { const inf = $('#info'); return Date.now() - lastAutoRender < 6000 || (inf && !inf.classList.contains('hidden')) || document.hidden; }
function keepScroll(fn) {
  const cur = $('#v-' + tab); if (cur) { cur.style.minHeight = cur.offsetHeight + 'px'; setTimeout(() => { cur.style.minHeight = ''; }, 700); }
  const els = [document.scrollingElement, $('#app'), ...document.querySelectorAll('main, section, .view, [id^=v-]')].filter(Boolean), saved = new Map(els.map((e) => [e, e.scrollTop]));
  const sub = $('#v-' + tab); const inner = sub ? [...sub.querySelectorAll('*')].filter((e) => e.scrollTop > 0).map((e, i) => [i, e.scrollTop, e.id || e.className]) : [];
  const restore = () => { for (const [e, t] of saved) if (e.scrollTop !== t) e.scrollTop = t; };
  let r; try { r = fn(); } catch (e) { throw e; }
  Promise.resolve(r).then(() => { restore(); requestAnimationFrame(restore); setTimeout(restore, 60); }).catch(() => {});
}
