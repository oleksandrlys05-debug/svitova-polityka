// Оновлення 18: точне керування — повзунки й числа замість перемикачів, з попереднім переглядом наслідків
const CTL_CH = {
  happy: ['Щастя', 1, ''], stab: ['Стабільність', 1, ''], pres: ['Підтримка влади', 1, ''], war: ['Підтримка війни', 1, ''], growth: ['Ріст ВВП', 100, '%/рік'], research: ['Наука', 100, '%'],
  prod: ['Виробництво', 100, '%'], unemp: ['Безробіття', 100, ' п.п.', true], fert: ['Народжуваність', 1000, '‰'], crime: ['Злочинність', 1, '', true], corr: ['Корупція', 1, '', true], lit: ['Грамотність', 1, ''],
  unionSat: ['Профспілки', 1, '/добу'], manpower: ['Призовний резерв', 100, '%'], morale: ['Мораль армії', 100, '%'], protest: ['Протести', 100, '%', true], food: ['Врожай', 100, '%'], cost: ['Казна', 1, ' $/добу', true],
};
const ctlChip = ([ch, x]) => { const d = CTL_CH[ch]; if (!d || Math.abs(x) < 1e-6) return ''; const v = x * d[1], good = d[3] ? v < 0 : v > 0, txt = ch === 'cost' ? short(Math.abs(v)) : nf(Math.abs(v), Math.abs(v) < 1 ? 2 : 1);
  return `<span class="ctlchip ${good ? 'pos' : 'neg'}">${esc(d[0])} ${ch === 'cost' ? (v > 0 ? '−' : '+') : v > 0 ? '+' : '−'}${txt}${d[2]}</span>`; };
const ctlFmt = (s, v) => (s.k === 'festival' ? short(v) : nf(v, s.step < 1 ? 1 : 0));
window.CTLS = window.CTLS || null;
async function ctlMount(el, groups, title, intro) {
  const D = await api('ctl/state'); window.CTLS = D; const keys = Object.values(D.spec).filter((s) => groups.includes(s.g)).map((s) => s.k); if (!keys.length) return; const V = { ...D.values };
  const row = (k) => { const s = D.spec[k]; return `<div class="ctlrow" data-ck="${k}"><div class="ctlhead"><b>${esc(s.n)}</b><span class="grow"></span><input type="number" class="ctlnum" data-cn="${k}" min="${s.min}" max="${s.max}" step="${s.step}" value="${V[k]}"><span class="muted ctlu">${esc(s.u)}</span></div>
    <input type="range" data-cr="${k}" min="${s.min}" max="${s.max}" step="${s.step}" value="${V[k]}"><div class="muted ctld">${esc(s.d)}</div><div class="ctlfx" id="cfx-${k}">${(D.per[k] || []).map(ctlChip).join('') || '<span class="muted">за типових значень — без наслідків</span>'}</div></div>`; };
  const box = document.createElement('div'); box.className = 'card pad ctlbox';
  box.innerHTML = `<h3 style="margin-top:0">${esc(title)}</h3>${intro ? `<p class="hint" style="margin-top:0">${intro}</p>` : ''}${keys.map(row).join('')}
    <div class="row" style="gap:8px;margin-top:10px;align-items:center"><button class="ctlsave">Ухвалити</button><button class="ghost ctlreset">Скасувати зміни</button><span class="grow"></span><span class="muted ctltot">Усі налаштування коштують: <b>${short(D.costTotal)} $</b> / добу</span></div>`;
  el.appendChild(box);
  let seq = 0; const prev = async () => { const my = ++seq; const r = await api('ctl/preview', { values: V }).catch(() => null); if (!r || my !== seq) return; for (const k of keys) { const e = box.querySelector('#cfx-' + k); if (e) e.innerHTML = (r.per[k] || []).map(ctlChip).join('') || '<span class="muted">без наслідків</span>'; } const t = box.querySelector('.ctltot b'); if (t) t.textContent = short(r.costTotal) + ' $'; };
  const setV = (k, v, from) => { V[k] = +v; if (from !== 'r') box.querySelector(`[data-cr="${k}"]`).value = v; if (from !== 'n') box.querySelector(`[data-cn="${k}"]`).value = v; box.querySelector(`[data-ck="${k}"]`).classList.toggle('changed', +V[k] !== +D.values[k]); prev(); };
  box.querySelectorAll('[data-cr]').forEach((i) => i.oninput = () => setV(i.dataset.cr, i.value, 'r'));
  box.querySelectorAll('[data-cn]').forEach((i) => i.onchange = () => { const s = D.spec[i.dataset.cn]; let v = +i.value; if (!isFinite(v)) v = V[s.k]; v = Math.min(s.max, Math.max(s.min, v)); i.value = v; setV(s.k, v, 'n'); });
  box.querySelector('.ctlreset').onclick = () => { for (const k of keys) setV(k, D.values[k]); };
  box.querySelector('.ctlsave').onclick = () => { const ch = {}; for (const k of keys) if (+V[k] !== +D.values[k]) ch[k] = V[k]; if (!Object.keys(ch).length) return toast('Нічого не змінено'); if (ch.censor != null && V.censor >= 60 && D.values.censor < 60 && !confirm('Рівень цензури від 60% — це цензура: репутація −5, корупція росте, наука повільніша. Ухвалити?')) return;
    act(async () => { const r = await api('ctl/set', { values: ch }); toast(r.message); await refreshMe(); renderMe(); }); };
  return box;
}
// мито на окремі ресурси
async function ctlTariffs(el) {
  const D = window.CTLS || await api('ctl/state'), T = { ...D.tariff }; const box = document.createElement('div'); box.className = 'card pad ctlbox';
  box.innerHTML = `<h3 style="margin-top:0">Мито на імпорт окремих ресурсів</h3><p class="hint" style="margin-top:0">Додається до мита за торговими правилами з кожною державою. Захищає своїх виробників і дає дохід, але дорожчий імпорт трохи гальмує ріст ВВП.</p>
    <div class="grid g3" style="gap:6px 16px">${D.res.map((r) => `<label class="row" style="gap:6px;margin:0"><span class="grow">${esc(D.resN[r] || r)}</span><input type="number" min="0" max="100" step="1" data-tf="${r}" value="${T[r] || 0}" style="width:70px">%</label>`).join('')}</div>
    <div class="row" style="margin-top:8px"><button class="sm" id="tfsave">Зберегти мито</button></div>`;
  el.appendChild(box);
  box.querySelector('#tfsave').onclick = () => { const t = {}; box.querySelectorAll('[data-tf]').forEach((i) => { t[i.dataset.tf] = Math.max(0, Math.min(100, +i.value || 0)); }); act(async () => { const r = await api('ctl/set', { tariff: t }); toast(r.message); renderMe(); }); };
}
// ---------- підключення до вкладок ----------
const ctlWrap = (name, fn) => { const o = window[name]; if (typeof o !== 'function') return; window[name] = async function (b, ...rest) { await o.call(this, b, ...rest); try { await fn(b); } catch (e) { console.error('ctl18', name, e); } }; };
// Демографія: пенсійний вік, пенсії, виплати, громадські роботи, школа; кампанія грамотності з тривалістю й силою
ctlWrap('renderDemo', async (b) => {
  const old = b.querySelector('[data-dp="natal"]'), card = old && old.closest('.card'); const host = document.createElement('div');
  if (card) card.replaceWith(host); else b.appendChild(host);
  await ctlMount(host, ['social'], 'Соціальна політика', 'Усе задається точними числами. Під кожним повзунком видно, що зміниться: щастя, народжуваність, безробіття, призов, казна. Зміни застосовуються після «Ухвалити».');
  const lit = document.createElement('div'); lit.className = 'card pad'; lit.innerHTML = `<h3 style="margin-top:0">${ico('book', 24)} Кампанія грамотності</h3><div class="row" style="gap:8px;flex-wrap:wrap;align-items:center">Тривалість <input type="number" id="litd" min="30" max="180" step="10" value="90" style="width:80px"> діб · сила <input type="number" id="litk" min="50" max="200" step="10" value="100" style="width:80px">% <button class="sm" id="litgo">Розпочати</button></div><p class="hint" style="margin:6px 0 0">Ціль грамотності +12 за силу 100% (до +24). Ціна пропорційна тривалості й силі.</p>`;
  host.appendChild(lit); lit.querySelector('#litgo').onclick = () => act(() => reAct('society/demo', { pol: 'lit', days: +$('#litd').value, k: +$('#litk').value }));
});
// Закони й податки: праця, ціни, мито
ctlWrap('renderLaws', async (b) => { await ctlMount(b, ['labor'], 'Праця й ціни', 'Мінімальна зарплата, робочий тиждень, права профспілок і дотації цін.'); await ctlTariffs(b); });
// Порядок: поліція, бюро, суди (кнопки бюро й закону про профспілки замінено числами)
ctlWrap('renderOrder', async (b) => {
  const bu = b.querySelector('[data-o="bureau"]'); if (bu) bu.remove(); const lw = b.querySelector('[data-law]'); if (lw && lw.parentElement) lw.parentElement.innerHTML = '<span class="muted">Права профспілок задаються числом: Економіка → Закони й податки → «Права профспілок».</span>';
  const po = b.querySelector('[data-o="police"]'); if (po && !po.disabled) { const inp = document.createElement('span'); inp.innerHTML = ` на <input type="number" id="podays" min="5" max="30" value="15" style="width:60px"> діб`; po.after(inp); po.onclick = (e) => { e.stopImmediatePropagation(); act(() => reAct('order/act', { kind: 'police', days: +$('#podays').value })); }; }
  await ctlMount(b, ['order'], 'Поліція, бюро й суди', 'Скільки поліції, наскільки сильне антикорупційне бюро і наскільки суворі суди.');
});
// ЗМІ: рівень цензури замість трьох кнопок
ctlWrap('renderMedia', async (b) => { const mp = b.querySelector('[data-mp]'), card = mp && mp.closest('.card'); const host = document.createElement('div'); if (card) card.replaceWith(host); else b.prepend(host);
  await ctlMount(host, ['media'], 'Свобода слова', 'Режим ЗМІ залежить від рівня цензури: до 25% — вільні, 25–59% — державне ТБ, від 60% — цензура (потрібна згода парламенту).'); });
// Армія: термін служби, призовний вік, платня
ctlWrap('renderArmy', async (b) => { await ctlMount(b, ['army'], 'Служба й призов', 'Термін служби, призовний вік і платня солдатам. Розмір призову (% населення) — повзунок «Призов» вище.'); });
// Ресурси: дотації фермерам і запас зерна
ctlWrap('renderRes', async (b) => { const box = await ctlMount(b, ['food'], 'Їжа: дотації й резерв', ''); const D = window.CTLS; if (box && D) { const p = document.createElement('p'); p.className = 'hint'; p.innerHTML = `У резерві: <b>${nf(D.grain, 1)}</b> од. зерна (≈${D.foodCons ? nf(D.grain / D.foodCons, 0) : 0} діб споживання). Під час голоду резерв іде людям автоматично.`; box.insertBefore(p, box.querySelector('.ctlrow')); } });
// Релігія
ctlWrap('renderRel', async (b) => { await ctlMount(b, ['faith'], 'Держава й віра', ''); });
// Міста: міграційна квота замість «приймати / закрито»; міські закони — числами
ctlWrap('renderCities', async (b) => {
  const mg = b.querySelector('[data-migr]'); if (mg) { const host = document.createElement('div'); mg.parentElement.replaceWith(host); await ctlMount(host, ['migr'], 'Міграція', ''); }
  const rows = b.querySelectorAll('[data-claw]'); if (!rows.length) return; const S = await api('cities/state'); const L = S.laws || {};
  const seen = new Set(); rows.forEach((x) => { const [id] = x.dataset.claw.split(':'); if (seen.has(id)) return; seen.add(id); const wrap = x.parentElement, c = S.cities.find((cc) => String(cc.id) === id) || {}, m = (c.m && c.m.laws) || (c.mgmt && c.mgmt.laws) || {};
    const val = (k) => { const v = m[k]; return v === true ? L[k].def : +v || 0; };
    wrap.innerHTML = Object.entries(L).map(([k, l]) => `<label class="row" style="gap:6px;margin:2px 10px 2px 0" title="${esc(l.d)}">${esc(l.n)} <input type="number" data-cl="${id}:${k}" min="${l.min}" max="${l.max}" step="${l.step}" value="${val(k)}" style="width:${k === 'festival' ? 110 : 70}px"> <span class="muted">${esc(l.u)}</span></label>`).join('') + `<button class="sm" data-clsave="${id}">Застосувати</button>`;
    wrap.querySelector('[data-clsave]').onclick = () => { const laws = {}; wrap.querySelectorAll('[data-cl]').forEach((i) => { laws[i.dataset.cl.split(':')[1]] = +i.value || 0; }); act(async () => { await api('cities/mgmt', { id: +id, laws }); renderMe(); }, 'Міські закони змінено'); }; });
});
// Бізнес: пільги окремо для кожної галузі
ctlWrap('renderBiz', async (b) => { const D = await api('biz/state'); const box = document.createElement('div'); box.className = 'card pad';
  box.innerHTML = `<h3 style="margin-top:0">Пільги окремо для галузей</h3><p class="hint" style="margin-top:0">Порожнє поле — діє загальна пільга (${D.taxBreak}%). Більша пільга — компанія охочіше відкриває філію, але платить менше податку.</p>
    <div class="grid g3" style="gap:6px 16px">${Object.entries(D.ind).map(([k, d]) => `<label class="row" style="gap:6px;margin:0"><span class="grow">${esc(d.n || k)}</span><input type="number" min="0" max="60" data-bk="${k}" value="${D.breaks[k] != null ? D.breaks[k] : ''}" placeholder="${D.taxBreak}" style="width:70px">%</label>`).join('')}</div>
    <div class="row" style="margin-top:8px"><button class="sm" id="bksave">Зберегти пільги</button></div>`;
  b.appendChild(box); box.querySelector('#bksave').onclick = () => { const br = {}; box.querySelectorAll('[data-bk]').forEach((i) => { br[i.dataset.bk] = i.value === '' ? null : +i.value; }); act(async () => { await api('biz/policy', { breaks: br }); renderMe(); }, 'Пільги збережено'); }; });
// Меншини: рівень автономії й підтримки замість перемикачів
ctlWrap('renderNations', async (b) => { const D = await api('nations/state');
  for (const r of D.rows.filter((x) => !x.own)) { const t = b.querySelector(`[data-np="${r.id}"]`); if (!t) continue; const rowEl = t.closest('.row'); if (!rowEl) continue;
    rowEl.querySelectorAll('[data-np]').forEach((i) => { if (['pay', 'autonomy', 'ban'].includes(i.dataset.k)) { const l = i.closest('label') || i.parentElement; if (l && l !== rowEl) l.remove(); else i.remove(); } });
    const box = document.createElement('div'); box.className = 'grid g2'; box.style.gap = '6px 18px'; box.style.margin = '8px 0';
    box.innerHTML = `<label style="margin:0">Автономія: <b data-av="${r.id}">${r.aut}%</b><input type="range" min="0" max="100" step="5" value="${r.aut}" data-na="${r.id}"><span class="muted" style="font-size:12.5px">0 — заборона мови й культури, 50 — звичайні права, 75+ — автономія (менше податків, без призову). Лояльність ${r.aut >= 50 ? '+' : '−'}${Math.abs(Math.round((r.aut - 50) * 0.5))}.</span></label>
      <label style="margin:0">Підтримка меншини: <b data-pv="${r.id}">${r.payLv}%</b><input type="range" min="0" max="200" step="10" value="${r.payLv}" data-npay="${r.id}"><span class="muted" style="font-size:12.5px">100% = ${short(r.costs.pay)} $/добу, +15 лояльності.</span></label>`;
    rowEl.before(box);
    box.querySelector('[data-na]').oninput = (e) => { box.querySelector('[data-av]').textContent = e.target.value + '%'; }; box.querySelector('[data-npay]').oninput = (e) => { box.querySelector('[data-pv]').textContent = e.target.value + '%'; };
    box.querySelector('[data-na]').onchange = (e) => act(async () => { if (+e.target.value <= 15 && !confirm('Рівень до 15% — це заборона мови й культури: лояльність різко впаде, батьківщина обуриться. Продовжити?')) return renderMe(); await api('nations/policy', { nation: r.id, key: 'aut', value: +e.target.value }); renderMe(); });
    box.querySelector('[data-npay]').onchange = (e) => act(async () => { await api('nations/policy', { nation: r.id, key: 'payLv', value: +e.target.value }); renderMe(); }); } });
