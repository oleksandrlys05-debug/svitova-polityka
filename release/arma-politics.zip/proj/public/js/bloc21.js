// Оновлення 21 (клієнт): живий альянс — емблема, рівень і бонуси, оголошення, чат, казна, програми, голосування
const embUrl = (id, v) => `/api/bloc/emblem?id=${id}&v=${v || 0}`;
ctlWrap('renderBloc', async (b) => {
  if (!b) return; let D; try { D = (await api('bloc21')).bloc; } catch { return; } if (!D) return;
  const el = document.createElement('div'); el.id = 'bloc21';
  const L = D.isLeader, pct = D.next ? Math.round(100 * D.xp / D.next) : 100;
  el.innerHTML = `<div class="card pad b21head"><div class="row" style="gap:14px;align-items:center">
      <div class="b21emb">${D.emb ? `<img src="${embUrl(D.id, D.emb)}" alt="">` : `<span style="background:${esc(D.color)}"></span>`}</div>
      <div class="grow"><h3 style="margin:0">${esc(D.name)} <span class="badge">рівень ${D.level}</span></h3>
        <div class="muted" style="font-size:12.5px">Лідер: ${esc(D.leaderName)} · учасників: ${D.members.length} · досвід ${D.xp}${D.next ? ` / ${D.next}` : ' (максимум)'}</div>
        <div class="fmgbar" style="max-width:320px"><i style="width:${pct}%"></i></div>
        <div style="font-size:12.5px">Бонуси кожному учаснику: ріст ВВП +${D.bonus.growth.toFixed(1)} п.п., мораль +${D.bonus.morale}, наука +${D.bonus.research}%, сила армії +${D.bonus.army}%${D.bonus.stab ? `, стабільність +${D.bonus.stab}` : ''}</div></div>
      ${L ? `<div style="display:grid;gap:4px"><label class="ghost sm btn-like" style="cursor:pointer">🖼 Емблема<input type="file" id="b21f" accept="image/png,image/jpeg,image/webp" style="display:none"></label>${D.emb ? '<button class="ghost sm" id="b21fd">Прибрати</button>' : ''}</div>` : ''}</div>
    ${D.motd ? `<div class="b21motd">📌 ${esc(D.motd)}</div>` : ''}${L ? `<div class="row" style="gap:6px;margin-top:6px"><input id="b21m" maxlength="400" placeholder="Оголошення для всіх учасників" value="${esc(D.motd)}"><button class="sm" id="b21ms">Оголосити</button></div>` : ''}</div>
  <div class="grid g2" style="gap:12px"><div class="card pad"><h3 style="margin-top:0">💬 Чат альянсу</h3><div class="b21chat" id="b21c">${chatHtml21(D)}</div>
      <div class="row" style="gap:6px;margin-top:6px"><input id="b21t" maxlength="500" placeholder="Повідомлення союзникам…"><button class="sm" id="b21s">Надіслати</button></div></div>
    <div class="card pad"><h3 style="margin-top:0">🏦 Спільна казна: ${short(D.fund)} $</h3>
      <div class="row" style="gap:6px"><input id="b21d" type="number" min="0" step="1000000" placeholder="Сума внеску, $"><button class="sm" id="b21ds">Внести</button></div>
      <p class="muted" style="font-size:12px;margin:4px 0">Щомісячний внесок: <b>${D.dues}% ВВП</b> кожного учасника. Внески дають досвід альянсу.</p>
      ${L ? `<div class="row" style="gap:6px"><label style="font-size:12.5px">Внесок, % ВВП/міс.</label><input id="b21du" type="number" min="0" max="3" step="0.1" value="${D.dues}" style="width:80px"><button class="ghost sm" id="b21dus">Встановити</button></div>
        <div class="row" style="gap:6px;margin-top:6px"><select id="b21gt" style="width:auto">${D.members.map((m) => `<option value="${m.id}">${esc(m.name)}</option>`).join('')}</select><input id="b21ga" type="number" min="0" placeholder="Сума, $" style="width:140px"><button class="ghost sm" id="b21gs">Виділити з казни</button></div>
        <h4 style="margin:10px 0 4px">Програми (з казни)</h4><div class="row" style="gap:6px;flex-wrap:wrap"><button class="sm" id="b21pd" ${D.drill ? 'disabled' : ''}>🎯 Спільні навчання — ${short(D.costs.drill)} $${D.drill ? ` (ще ${Math.ceil(D.drill)} д.)` : ''}</button><button class="sm" id="b21ps" ${D.sci ? 'disabled' : ''}>🔬 Наукова програма — ${short(D.costs.sci)} $${D.sci ? ` (ще ${Math.ceil(D.sci)} д.)` : ''}</button></div>
        <p class="hint" style="margin:4px 0">Навчання: досвід усіх підрозділів +6, організація +10, сила армії +4% на 30 діб. Наука: +6% до досліджень на 60 діб. Обидві дають багато досвіду альянсу.</p>` : `<p class="hint">Витрачає казну лідер: допомога учасникам, спільні навчання, наукові програми.${D.drill ? ` Зараз тривають навчання (${Math.ceil(D.drill)} д.).` : ''}${D.sci ? ` Наукова програма: ${Math.ceil(D.sci)} д.` : ''}</p>`}</div></div>
  <div class="card pad"><h3 style="margin-top:0">🗳 Голосування</h3><div class="row" style="gap:6px;flex-wrap:wrap"><select id="b21vk" style="width:auto"><option value="war">Спільна війна проти…</option><option value="peace">Спільно запропонувати мир…</option><option value="invite">Прийняти до альянсу…</option><option value="kick">Виключити з альянсу…</option><option value="leader">Новий лідер…</option></select><select id="b21vt" style="width:auto"></select><button class="sm" id="b21vn">Винести на голосування</button></div>
    ${D.votes.length ? D.votes.map((v) => `<div class="b21vote"><b>${esc(v.kindN)} ${esc(v.targetName)}</b> <span class="muted">— запропонувала ${esc(v.by)} · за ${v.yes} / проти ${v.no}${v.status === 'open' ? ` · ще ${nf(v.left, 1)} доби` : v.status === 'passed' ? ' · <b class="pos">ухвалено</b>' : ' · <b class="neg">відхилено</b>'}</span>${v.status === 'open' ? `<span class="grow"></span>${v.my ? `<span class="badge">ви: ${v.my === 'yes' ? 'за' : 'проти'}</span>` : ''}<button class="sm" data-vy="${v.id}">За</button><button class="ghost sm" data-vn="${v.id}">Проти</button>` : ''}</div>`).join('') : '<p class="muted">Голосувань немає. Рішення ухвалюється більшістю учасників (боти голосують самі).</p>'}
    <p class="hint">«Спільна війна» — коли ухвалено, усі учасники оголошують війну разом. Члени альянсу бачать підрозділи одне одного.</p></div>
  <div class="card pad"><h3 style="margin-top:0">Учасники</h3><table><tr><th>Держава</th><th class="r">ВВП</th><th class="r">Армія</th><th>Війни</th></tr>${D.members.map((m) => `<tr><td><span class="sw" style="background:${esc(m.color)}"></span>${esc(m.name)}${m.id === D.leader ? ' <span class="badge">лідер</span>' : ''}${m.bot ? ' <span class="muted">ШІ</span>' : ''}</td><td class="r">${short(m.gdp)}</td><td class="r">${short(m.army)}</td><td class="muted">${esc(m.war.join(', ') || '—')}</td></tr>`).join('')}</table>
    ${D.log.length ? `<details style="margin-top:8px"><summary>Журнал альянсу</summary>${D.log.map((l) => `<div class="news"><small>${gdate(l.day)}</small> ${esc(l.text)}</div>`).join('')}</details>` : ''}</div>`;
  b.prepend(el);
  const re = () => renderMe();
  const vt = el.querySelector('#b21vt'), vk = el.querySelector('#b21vk'), fill = () => { const k = vk.value, list = ['kick', 'leader'].includes(k) ? D.members.filter((m) => m.id !== D.leader || k === 'kick') : k === 'invite' ? D.candidates : D.targets; vt.innerHTML = list.map((x) => `<option value="${x.id}">${esc(x.name)}</option>`).join(''); }; vk.onchange = fill; fill();
  el.querySelector('#b21vn').onclick = () => act(async () => { await api('bloc21/vote/new', { kind: vk.value, target: +vt.value }); re(); }, 'Голосування почалося');
  el.querySelectorAll('[data-vy]').forEach((x) => x.onclick = () => act(async () => { await api('bloc21/vote', { id: +x.dataset.vy, yes: 1 }); re(); }, 'Ваш голос: за'));
  el.querySelectorAll('[data-vn]').forEach((x) => x.onclick = () => act(async () => { await api('bloc21/vote', { id: +x.dataset.vn, yes: 0 }); re(); }, 'Ваш голос: проти'));
  const send = () => { const t = el.querySelector('#b21t').value.trim(); if (!t) return; act(async () => { await api('bloc21/chat', { text: t }); el.querySelector('#b21t').value = ''; await refreshChat21(); }); };
  el.querySelector('#b21s').onclick = send; el.querySelector('#b21t').onkeydown = (e) => { if (e.key === 'Enter') send(); };
  el.querySelector('#b21ds').onclick = () => act(async () => { await api('bloc21/deposit', { amount: +el.querySelector('#b21d').value }); await refreshMe(); re(); }, 'Внесено до казни');
  const q0 = (s) => el.querySelector(s);
  if (L) { q0('#b21dus').onclick = () => act(async () => { await api('bloc21/dues', { dues: +q0('#b21du').value }); re(); }, 'Збережено');
    q0('#b21gs').onclick = () => act(async () => { await api('bloc21/grant', { to: +q0('#b21gt').value, amount: +q0('#b21ga').value }); re(); }, 'Виділено');
    q0('#b21pd').onclick = () => act(async () => { await api('bloc21/program', { kind: 'drill' }); re(); }, 'Навчання почалися');
    q0('#b21ps').onclick = () => act(async () => { await api('bloc21/program', { kind: 'sci' }); re(); }, 'Наукова програма почалася');
    q0('#b21ms').onclick = () => act(async () => { await api('bloc21/motd', { text: q0('#b21m').value }); re(); }, 'Оголошено');
    const f = q0('#b21f'); if (f) f.onchange = () => { const file = f.files[0]; if (!file) return; const img = new Image(), rd = new FileReader(); rd.onload = () => { img.onload = () => { const k = Math.min(1, 256 / Math.max(img.width, img.height)), cv2 = document.createElement('canvas'); cv2.width = Math.max(1, Math.round(img.width * k)); cv2.height = Math.max(1, Math.round(img.height * k)); cv2.getContext('2d').drawImage(img, 0, 0, cv2.width, cv2.height); act(async () => { await api('bloc/emblem', { data: cv2.toDataURL('image/png') }); re(); }, 'Емблему встановлено'); }; img.onerror = () => toast('Не вдалося прочитати картинку', true); img.src = rd.result; }; rd.readAsDataURL(file); };
    const fd = q0('#b21fd'); if (fd) fd.onclick = () => act(async () => { await api('bloc/emblem', { del: 1 }); re(); }, 'Емблему прибрано'); }
  const cbox = q0('#b21c'); if (cbox) cbox.scrollTop = cbox.scrollHeight;
});
function chatHtml21(D) { return D.chat.length ? D.chat.map((m) => `<div class="b21msg${m.mine ? ' mine' : ''}${m.cid ? '' : ' sys'}"><b>${esc(m.name)}</b> ${esc(m.text)} <small class="muted">${new Date(m.ts).toLocaleTimeString('uk-UA', { hour: '2-digit', minute: '2-digit' })}</small></div>`).join('') : '<p class="muted">Повідомлень ще немає. Напишіть першим — боти-союзники теж відповідають.</p>'; }
async function refreshChat21() { const box = document.getElementById('b21c'); if (!box) return; try { const D = (await api('bloc21')).bloc; if (!D) return; const atEnd = box.scrollTop + box.clientHeight >= box.scrollHeight - 30; box.innerHTML = chatHtml21(D); if (atEnd) box.scrollTop = box.scrollHeight; } catch { /* ні */ } }
setInterval(() => { if (document.getElementById('b21c') && !document.querySelector('#bloc21 input:focus')) refreshChat21(); }, 6000);

// ---------- емблеми на мапі (шар «Альянси») ----------
const embImgs = {};
function drawEmblems21(C) {
  if (typeof layer === 'undefined' || layer !== 'alliances' || typeof blocLabels === 'undefined') return;
  for (const L of blocLabels) { if (!L.emb) continue; const k = L.bid + ':' + L.emb; let e = embImgs[k]; if (!e) { e = embImgs[k] = new Image(); e.onload = () => drawMap(); e.src = embUrl(L.bid, L.emb); } if (!e.complete || !e.naturalWidth) continue;
    const h = Math.max(22 / view.s, L.fs * 1.5), w = h * e.naturalWidth / e.naturalHeight; cx.save(); cx.globalAlpha = 0.92; cx.drawImage(e, L.x - w / 2, L.y - L.fs * 0.65 - h, w, h); cx.restore(); }
}
{ const prev = window.drawRoads; window.drawRoads = function (C) { if (typeof prev === 'function') prev(C); try { drawEmblems21(C); } catch (e) { console.error('emb21', e); } }; }
