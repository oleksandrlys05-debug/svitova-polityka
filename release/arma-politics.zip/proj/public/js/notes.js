// Сповіщення: важливість, фільтри, згортання дрібниць, перехід за посиланням
const NCAT = { '': ['Усі', '🔔'], imp: ['Важливі', '❗'], war: ['Війна', '⚔'], econ: ['Економіка', '💰'], court: ['Двір', '👑'], diplo: ['Дипломатія', '🤝'], politics: ['Політика', '🏛'], intel: ['Розвідка', '🕵'], other: ['Інше', '🔔'] };
let noteFilter = '';
// перейти туди, про що сповіщення
async function goLink(link) {
  if (!link) return; const [k, v] = [link.split(':')[0], link.slice(link.indexOf(':') + 1)];
  $('#bellPanel').classList.add('hidden');
  try {
    if (k === 'me') { window.meSub = v; showTab('me'); }
    else if (k === 'tab') showTab(v);
    else if (k === 'news') { window.newsSub = v; if (typeof newsSub !== 'undefined') newsSub = v; showTab('news'); }
    else if (k === 'layer') { showTab('map'); setLayer(v); }
    else if (k === 'war') openWarWin();
    else if (k === 'event') { evOpen = false; pollEvents(); }
    else if (k === 'battles') { battleMin = false; await pollBattles(); if (!battleList.length) showTab('war'); }
    else if (k === 'confs') { const l = (await api('conf/list')).confs.filter((x) => x.status === 'open'); if (l.length) openConfWin(l[0].id); else showTab('diplo'); }
    else if (k === 'conf') openConfWin(+v);
    else if (k === 'city') { showTab('map'); openCity(+v); }
    else if (k === 'country') openCountry(+v);
    else if (k === 'map') { showTab('map'); const [x, y] = v.split(',').map(Number); focusCell(x, y); }
    else if (k === 'news') { window.newsSub = v; showTab('news'); }
    else if (k === 'elect') { showTab('parl'); setTimeout(() => { const e = $('#electbox'); if (e) e.scrollIntoView({ behavior: 'smooth' }); }, 700); }
    else if (k === 'fcourt') { window.meSub = 'fcourt'; window.fcourtSel = +v; showTab('me'); }
  } catch (e) { console.error(e); }
}
const noteHtml = (n) => { const c = NCAT[n.cat] || NCAT.other; return `<div class="nt lv${n.lvl} ${n.read ? '' : 'un'} ${n.link ? 'go' : ''}" data-nid="${n.id}" data-link="${esc(n.link || '')}"><span class="nic">${c[1]}</span><div class="grow">${esc(n.text)}${n.cnt > 1 ? ` <span class="badge">×${n.cnt}</span>` : ''}<div class="muted" style="font-size:12px">${new Date(n.ts).toLocaleString('uk-UA')}${n.link ? ' · <span class="golink">перейти →</span>' : ''}</div></div></div>`; };
async function renderBell() {
  const p = $('#bellPanel'), q = noteFilter === 'imp' ? '?imp=1' : noteFilter ? '?cat=' + noteFilter : '', d = await api('notifications' + q);
  p.innerHTML = `<div class="nfilt">${Object.entries(NCAT).filter(([k]) => k !== 'other').map(([k, [n, ic]]) => `<button class="${noteFilter === k ? '' : 'ghost'} sm" data-nf="${k}">${ic} ${n}</button>`).join('')}</div>
    <div class="row" style="margin:4px 0"><span class="muted grow" style="font-size:13px">Непрочитаних: ${d.unread}${d.unreadImp ? ` · важливих: <b class="neg">${d.unreadImp}</b>` : ''}</span><button class="ghost sm" id="nall">Прочитати всі</button></div>
    ${d.items.map(noteHtml).join('') || '<div class="nt muted">Сповіщень немає.</div>'}`;
  p.querySelectorAll('[data-nf]').forEach((b) => b.onclick = (e) => { e.stopPropagation(); noteFilter = b.dataset.nf; renderBell(); });
  $('#nall').onclick = async (e) => { e.stopPropagation(); await api('notifications/read', {}); me.unread = 0; me.unreadImp = 0; clock(); renderBell(); };
  p.querySelectorAll('[data-nid]').forEach((el) => el.onclick = async () => { const id = +el.dataset.nid; api('notifications/read', { id }).then(() => refreshMe(true)).catch(() => {}); el.classList.remove('un'); if (el.dataset.link) goLink(el.dataset.link); });
}
async function toggleBell() { const p = $('#bellPanel'); if (!p.classList.contains('hidden')) return p.classList.add('hidden'); p.style.top = ($('#top').getBoundingClientRect().bottom + 6) + 'px'; p.classList.remove('hidden'); await renderBell(); }
// спливаюче повідомлення про нове сповіщення: дрібниці без спливання; натиснув — перейшов
let lastNoteId = 0;
async function onNotify() {
  const d = await api('notifications').catch(() => null); if (!d) return; me.unread = d.unread; me.unreadImp = d.unreadImp; clock();
  const fresh = d.items.filter((n) => n.id > lastNoteId && !n.read); if (lastNoteId === 0) { lastNoteId = d.items.length ? d.items[0].id : 1; if (!fresh.length) return; }
  for (const n of fresh.slice(0, 3).reverse()) { if (n.lvl === 0) continue; const t = document.createElement('div'); t.className = 'toast' + (n.lvl >= 2 ? ' bad imp' : '') + (n.link ? ' go' : ''); t.innerHTML = `<span class="nic">${(NCAT[n.cat] || NCAT.other)[1]}</span> ${esc(n.text)}${n.link ? ' <span class="golink">→</span>' : ''}`; if (n.link) t.onclick = () => { api('notifications/read', { id: n.id }).catch(() => {}); goLink(n.link); t.remove(); }; $('#toasts').append(t); setTimeout(() => t.remove(), n.lvl >= 2 ? 9000 : 5000); }
  lastNoteId = Math.max(lastNoteId, ...d.items.map((n) => n.id));
}
// ---------- значки-попередження під верхньою панеллю (як у HoI4) ----------
let alertsAt = 0, alertsKey = '';
async function loadAlerts(force) {
  if (!me || !me.country) { $('#alerts').innerHTML = ''; return; } if (!force && Date.now() - alertsAt < 3500) return; alertsAt = Date.now();
  let d; try { d = await api('alerts'); } catch { return; } const key = JSON.stringify(d.alerts); if (key === alertsKey) return; alertsKey = key;
  const box = $('#alerts'), hb = $('#top').getBoundingClientRect(); box.style.top = (hb.bottom + 6) + 'px'; box.innerHTML = d.alerts.map((a, i) => `<button class="al lv${a.lvl}" data-ai="${i}" style="--bg:${iconBg(a.ic)}"><span>${svgOf(ICON_OF[a.ic] || a.ic)}</span></button>`).join('');
  document.body.classList.toggle('hasAlerts', d.alerts.length > 0);
  box.querySelectorAll('[data-ai]').forEach((b) => { const a = d.alerts[+b.dataset.ai];
    b.onmouseenter = () => { const t = $('#alertTip'), r = b.getBoundingClientRect(); t.innerHTML = `<b class="${a.lvl >= 2 ? 'neg' : 'warn'}">${esc(a.t)}</b><div>${esc(a.d)}</div><div class="muted" style="font-size:12px;margin-top:4px">Натисни, щоб перейти</div>`; t.style.left = Math.max(8, Math.min(innerWidth - 300, r.left - 120)) + 'px'; t.style.top = (r.bottom + 8) + 'px'; t.classList.remove('hidden'); };
    b.onmouseleave = () => $('#alertTip').classList.add('hidden');
    b.onclick = () => { $('#alertTip').classList.add('hidden'); if (a.link === 'event') { evOpen = false; pollEvents(); } else goLink(a.link); }; });
}
// ---------- очки дипломатії у верхній панелі ----------
function syncDP() {
  const b = $('#dpb'); if (!b) return; if (!me || !me.country) { b.classList.add('hidden'); return; } const st = me.country.stats, dp = Math.floor(st.dp || 0);
  b.classList.remove('hidden'); b.innerHTML = `<span class="dpic">${svgOf('dp')}</span><b>${dp}</b><span class="muted" style="font-size:11px">+${nf(st.dpRate || 1, 1)}/д</span>`;
  b.onmouseenter = async () => { const d = await api('dp').catch(() => null); if (!d) return; const t = $('#alertTip'), r = b.getBoundingClientRect();
    t.innerHTML = `<b>Очки дипломатії: ${Math.floor(d.cur)} / ${d.cap}</b><div class="muted" style="font-size:13px;margin:4px 0">Витрачаються на делегації (${d.cost.improve}), гарантії (${d.cost.guarantee}), обґрунтування війни (${d.cost.justify}) і дії з чужими дворами (Розвідка → Чужі двори).</div>${d.parts.map(([n, v]) => `<div class="row"><span class="grow">${esc(n)}</span><b class="${v < 0 ? 'neg' : 'pos'}">${v > 0 ? '+' : ''}${nf(v, 2)}</b></div>`).join('')}<div class="row" style="border-top:1px solid var(--line);margin-top:4px;padding-top:4px"><span class="grow">Разом за добу</span><b>+${nf(d.total, 2)}</b></div>`;
    t.style.left = Math.max(8, Math.min(innerWidth - 300, r.left - 120)) + 'px'; t.style.top = (r.bottom + 8) + 'px'; t.classList.remove('hidden'); };
  b.onmouseleave = () => $('#alertTip').classList.add('hidden'); b.onclick = () => { window.meSub = 'fcourt'; showTab('me'); };
}
// ---------- погода: шар мапи й значок біля годинника ----------
let WX = null; const WXC = { clear: 'rgba(255,214,102,.10)', cloud: 'rgba(200,200,210,.18)', rain: 'rgba(66,135,245,.30)', storm: 'rgba(40,70,160,.45)', snow: 'rgba(255,255,255,.55)', blizzard: 'rgba(235,245,255,.78)', mud: 'rgba(122,94,59,.50)', heat: 'rgba(245,120,40,.40)', frost: 'rgba(170,215,255,.45)' };
const WXI = { clear: 'sun', cloud: 'rain', rain: 'rain', storm: 'rain', snow: 'snow', blizzard: 'snow', mud: 'mud', heat: 'sun', frost: 'snow' };
async function loadWeather() { try { WX = await api('weather'); } catch { WX = null; } syncWx(); }
function drawWeather(C) {
  if (!WX) return; const { cols, rows, rw, grid } = WX;
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) { const w = grid[r * cols + c]; cx.fillStyle = WXC[w] || 'transparent'; cx.fillRect(c * rw * C, r * rw * C, rw * C, rw * C); }
  if (view.s > view.fs * 0.9) for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) { const w = grid[r * cols + c]; if (w === 'clear' || w === 'cloud') continue; drawBadge(cx, WXI[w], (c + 0.5) * rw * C, (r + 0.5) * rw * C, 9 / view.s, { bg: iconBg(WXI[w]) }); }
}
function syncWx() { let el = $('#wxchip'); if (!el) { el = document.createElement('span'); el.id = 'wxchip'; $('#clock').after(el); } if (!WX || !WX.mine) { el.innerHTML = ''; return; } el.innerHTML = `<span class="ico" style="width:24px;height:24px;background:${iconBg(WXI[WX.mine.w])}">${svgOf(WXI[WX.mine.w])}</span><span><b>${esc(WX.mine.seasonName)}</b><small class="muted"> ${esc(WX.mine.name)}</small></span>`; el.title = `Погода над столицею. ${WX.monthName}. Шар мапи «Погода й сезон» показує погоду всюди.`; el.onclick = () => { showTab('map'); setLayer('weather'); }; }
// ---------- програма для Windows: кнопка «Поділитися грою» (лише у хоста) ----------
async function initShare() {
  if (!window.desktop || !window.desktop.shareInfo) return; let S = await window.desktop.shareInfo().catch(() => null); if (!S) return;
  let b = $('#shareb'); if (!b) { b = document.createElement('button'); b.id = 'shareb'; b.className = 'ghost iconbtn'; $('#bell').before(b); }
  const paint = () => { b.innerHTML = `<span class="ico" style="width:22px;height:22px;background:${S.url ? '#2f855a' : S.state === 'starting' ? '#b7791f' : '#4a5568'}">${svgOf('globe')}</span><b style="font-size:13px">Поділитися</b>`; b.title = S.url ? 'Посилання для друзів: ' + S.url : S.state === 'starting' ? 'Тунель запускається…' : 'Тунель вимкнено'; };
  paint(); window.desktop.onShare((d) => { S = d; paint(); if ($('#shmod')) window.__shareWin(); });
  const shareWin = () => openModal(`<div id="shmod">${illus('conf', 80)}<h3 style="margin-top:0">Поділитися грою з друзями</h3>
    ${S.url ? `<p>Надішліть друзям це посилання (у Discord чи месенджер). Вони відкривають його в браузері або в програмі («Підключитися до гри»).</p><div class="row"><input id="shu" value="${esc(S.url)}" readonly class="grow"><button id="shc">Скопіювати</button></div><p class="hint">Після перезапуску програми посилання буде нове — надішліть його знову.</p>` : S.state === 'starting' ? '<p>Тунель запускається… Зачекайте кілька секунд.</p>' : `<p class="neg">Тунель не працює.${S.err ? ' ' + esc(S.err) : ''}</p>`}
    ${S.lan && S.lan.length ? `<h4>У тій самій мережі (Wi-Fi, квартира)</h4>${S.lan.map((l) => `<div><code>${esc(l)}</code></div>`).join('')}` : ''}
    <div class="row" style="margin-top:12px"><button class="ghost sm" id="shr">Перезапустити тунель</button><span class="grow"></span><button class="ghost sm" id="shx">Закрити</button></div></div>`);
  b.onclick = () => { shareWin(); bindS(); };
  const bindS = () => { const c = $('#shc'); if (c) c.onclick = async () => { await window.desktop.copy(S.url); toast('Посилання скопійовано'); }; const r = $('#shr'); if (r) r.onclick = () => { window.desktop.restartTunnel(); }; const x = $('#shx'); if (x) x.onclick = closeModal; };
  const origShare = shareWin; window.__shareWin = () => { origShare(); bindS(); };
}
