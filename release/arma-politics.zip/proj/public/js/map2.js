// Мапа 2: назви держав у стилі HOI4, прапори, шар логістики, плавний рух підрозділів
let countryLabels = [], flagPix = null, logi = { depots: [], links: [] }, dispPos = {}, animOn = false, liveBusy = false, lastLive = 0, lastOccVer = -1, liveN = 0;
const flagImgs = {};
const flagUrl = (c, v) => `/api/flag?id=${c.id}&v=${v || c.flag || 0}`;
const flagTag = (c, h = 14) => (c && c.flag ? `<img class="flag" src="${flagUrl(c)}" alt="" style="height:${h}px;max-width:${Math.round(h * 1.8)}px;vertical-align:-2px;margin-right:5px;border:1px solid #8885;border-radius:2px;object-fit:cover">` : '');

// ---- назви держав: на всю територію, вздовж головної осі, без накладання ----
// оновлення 20: окремий напис для кожного великого шматка території (анклави, острови); написи не налазять один на одного
function regionMoments(keyOf, minN) { const gw = land.gw, N = owners.length, lab = new Int32Array(N).fill(-1), out = []; const st = new Int32Array(N);
  for (let s0 = 0; s0 < N; s0++) { if (lab[s0] >= 0) continue; const k = keyOf(s0); if (k == null) { lab[s0] = -2; continue; } let sp = 0; st[sp++] = s0; lab[s0] = out.length; const a = { key: k, n: 0, sx: 0, sy: 0, sxx: 0, syy: 0, sxy: 0 };
    while (sp) { const i = st[--sp], x = i % gw, y = (i / gw) | 0; a.n++; a.sx += x; a.sy += y; a.sxx += x * x; a.syy += y * y; a.sxy += x * y;
      if (x > 0 && lab[i - 1] === -1 && keyOf(i - 1) === k) { lab[i - 1] = out.length; st[sp++] = i - 1; } if (x < gw - 1 && lab[i + 1] === -1 && keyOf(i + 1) === k) { lab[i + 1] = out.length; st[sp++] = i + 1; }
      if (i >= gw && lab[i - gw] === -1 && keyOf(i - gw) === k) { lab[i - gw] = out.length; st[sp++] = i - gw; } if (i + gw < N && lab[i + gw] === -1 && keyOf(i + gw) === k) { lab[i + gw] = out.length; st[sp++] = i + gw; } }
    out.push(a); }
  return out.filter((a) => a.n >= minN); }
function shapeOf(a) { const mx = a.sx / a.n, my = a.sy / a.n, vx = a.sxx / a.n - mx * mx, vy = a.syy / a.n - my * my, cxy = a.sxy / a.n - mx * my; let ang = 0.5 * Math.atan2(2 * cxy, vx - vy); if (ang > Math.PI / 2 - 0.01) ang -= Math.PI;
  const tr = (vx + vy) / 2, df = Math.sqrt(Math.max(0, ((vx - vy) / 2) ** 2 + cxy * cxy)); return { mx, my, ang, l1: tr + df, l2: Math.max(0.01, tr - df) }; }
function placeLabels(list, minFs) { const width = (L) => L.name.length * L.fs * 0.74, pts = (L) => { const w = width(L), o = []; for (let t = -0.5; t <= 0.5001; t += 0.125) o.push([L.x + Math.cos(L.ang) * t * w, L.y + Math.sin(L.ang) * t * w]); return o; };
  const clash = (A, B) => { const pa = pts(A), pb = pts(B), lim = (A.fs + B.fs) * 0.62; for (const p of pa) for (const q of pb) if (Math.hypot(p[0] - q[0], p[1] - q[1]) < lim) return true; return false; };
  list.sort((a, b) => b.n - a.n); const placed = []; for (const L of list) { let k = 0; while (k < 16 && placed.some((P) => clash(L, P))) { L.fs *= 0.88; k++; } if (placed.some((P) => clash(L, P)) || L.fs < minFs) continue; placed.push(L); } return placed; }
function computeCountryLabels() {
  countryLabels = []; if (!land || !owners) return;
  const list = [];
  for (const a of regionMoments((i) => owners[i] || null, 25)) { const c = countries[a.key]; if (!c) continue; const S = shapeOf(a), ang = Math.max(-0.8, Math.min(0.8, S.ang)), len = 3.6 * Math.sqrt(S.l1) * land.cell, wid = 3.6 * Math.sqrt(S.l2) * land.cell;
    const name = c.name.toUpperCase(), fs = Math.max(4, Math.min(len * 0.9 / (name.length * 0.74), wid * 0.62, 64)); list.push({ id: +a.key, x: S.mx * land.cell, y: S.my * land.cell, ang, fs, name, n: a.n }); }
  countryLabels = placeLabels(list, 3);
}
function drawCountryLabels(K) {
  if (!countryLabels.length) return;
  for (const L of countryLabels) {
    if (L.fs * view.s < 6.5 || !countries[L.id]) continue; cx.save(); cx.translate(L.x, L.y); cx.rotate(L.ang); cx.font = `700 ${L.fs}px Georgia,serif`; cx.textAlign = 'center'; cx.textBaseline = 'middle';
    try { cx.letterSpacing = (L.fs * 0.1) + 'px'; } catch {} cx.lineJoin = 'round'; cx.lineWidth = Math.max(1 / view.s, L.fs * 0.12); cx.strokeStyle = 'rgba(10,8,16,.55)'; cx.strokeText(L.name, 0, 0); cx.fillStyle = 'rgba(248,245,255,.82)'; cx.fillText(L.name, 0, 0); cx.restore();
  }
}

// ---- прапори ----
const loadImg = (src) => new Promise((ok) => { const i = new Image(); i.onload = () => ok(i); i.onerror = () => ok(null); i.src = src; });
async function buildFlags() {
  flagPix = null; if (!land || !owners) return; const withFlag = Object.values(countries).filter((c) => c.flag); if (!withFlag.length) { return; }
  // (21) прапор малюється окремо на кожен шматок території (анклав, острів) — як назви, а не одним полотном на всю рамку держави
  const gw = land.gw, gh = land.gh, N = owners.length, lab = new Int32Array(N).fill(-1), comps = [], st = new Int32Array(N);
  for (let s0 = 0; s0 < N; s0++) { const id = owners[s0]; if (!id || lab[s0] >= 0) continue; let sp = 0; st[sp++] = s0; lab[s0] = comps.length; const b = { id, x1: s0 % gw, y1: (s0 / gw) | 0, x2: s0 % gw, y2: (s0 / gw) | 0, cells: [] };
    while (sp) { const i = st[--sp], x = i % gw, y = (i / gw) | 0; b.cells.push(i); if (x < b.x1) b.x1 = x; if (x > b.x2) b.x2 = x; if (y < b.y1) b.y1 = y; if (y > b.y2) b.y2 = y;
      if (x > 0 && lab[i - 1] < 0 && owners[i - 1] === id) { lab[i - 1] = comps.length; st[sp++] = i - 1; } if (x < gw - 1 && lab[i + 1] < 0 && owners[i + 1] === id) { lab[i + 1] = comps.length; st[sp++] = i + 1; }
      if (i >= gw && lab[i - gw] < 0 && owners[i - gw] === id) { lab[i - gw] = comps.length; st[sp++] = i - gw; } if (i + gw < N && lab[i + gw] < 0 && owners[i + gw] === id) { lab[i + gw] = comps.length; st[sp++] = i + gw; } }
    comps.push(b); }
  const pix = new Uint8ClampedArray(gw * gh * 4), want = new Set(withFlag.map((c) => c.id));
  for (const c of withFlag) { let e = flagImgs[c.id]; if (!e || e.v !== c.flag) { e = flagImgs[c.id] = { v: c.flag, img: await loadImg(flagUrl(c)) }; } }
  for (const b of comps) { if (!want.has(b.id)) continue; const e = flagImgs[b.id]; if (!e || !e.img) continue;
    // прапор накриває рамку шматка; розтяг не більше ×1,8, решта — обрізання країв
    const w = b.x2 - b.x1 + 1, h = b.y2 - b.y1 + 1, t = document.createElement('canvas'); t.width = w; t.height = h; const g = t.getContext('2d'), iw = e.img.width || 3, ih = e.img.height || 2, kx = w / iw, ky = h / ih, dw = iw * Math.max(kx, ky / 1.8), dh = ih * Math.max(ky, kx / 1.8);
    g.drawImage(e.img, (w - dw) / 2, (h - dh) / 2, dw, dh); const d = g.getImageData(0, 0, w, h).data;
    for (const i of b.cells) { const x = i % gw, y = (i / gw) | 0, j = ((y - b.y1) * w + (x - b.x1)) * 4; pix[i * 4] = d[j]; pix[i * 4 + 1] = d[j + 1]; pix[i * 4 + 2] = d[j + 2]; pix[i * 4 + 3] = 255; } }
  flagPix = pix; repaint(); drawMap();
}
function syncFlagBtn() { const b = $('#flagb'); if (b) { b.innerHTML = svgOf('flag'); b.title = flagMode ? 'Зараз: прапори. Натисни — кольори держав' : 'Зараз: кольори. Натисни — прапори держав'; } }
function toggleFlags() { flagMode = !flagMode; try { localStorage.flagMode = flagMode ? '1' : '0'; } catch {} syncFlagBtn(); if (flagMode && !flagPix) buildFlags(); else { repaint(); drawMap(); } }
document.addEventListener('DOMContentLoaded', () => { const b = $('#flagb'); if (b) { b.onclick = toggleFlags; syncFlagBtn(); } });
if (document.readyState !== 'loading') { const b = $('#flagb'); if (b) { b.onclick = toggleFlags; syncFlagBtn(); } }

// ---- логістика ----
async function loadLogi() { try { logi = await api('logistics'); } catch { logi = { depots: [], links: [] }; } }
function drawLogi(C) {
  cx.lineCap = 'round'; const w = 3.2 / view.s;
  for (const l of logi.links) { const x1 = (l.ax + .5) * C, y1 = (l.ay + .5) * C, x2 = (l.bx + .5) * C, y2 = (l.by + .5) * C, col = !l.ok ? '#ef4444' : l.conn ? '#e5e7eb' : '#f59e0b';
    cx.setLineDash([]); cx.strokeStyle = 'rgba(10,10,14,.85)'; cx.lineWidth = w + 2.6 / view.s; cx.beginPath(); cx.moveTo(x1, y1); cx.lineTo(x2, y2); cx.stroke();
    cx.strokeStyle = col; cx.lineWidth = w; if (!l.ok) cx.setLineDash([6 / view.s, 5 / view.s]); cx.beginPath(); cx.moveTo(x1, y1); cx.lineTo(x2, y2); cx.stroke();
    // шпали
    if (l.ok) { const L = Math.hypot(x2 - x1, y2 - y1), nx = -(y2 - y1) / (L || 1), ny = (x2 - x1) / (L || 1), st = 7 / view.s; cx.strokeStyle = 'rgba(10,10,14,.9)'; cx.lineWidth = 1.2 / view.s; cx.beginPath(); for (let t = st; t < L; t += st) { const px = x1 + (x2 - x1) * t / L, py = y1 + (y2 - y1) * t / L; cx.moveTo(px - nx * w * 0.9, py - ny * w * 0.9); cx.lineTo(px + nx * w * 0.9, py + ny * w * 0.9); } cx.stroke(); } cx.setLineDash([]); }
  if (logi.capital) drawBadge(cx, 'capital', (logi.capital.x + .5) * C, (logi.capital.y + .5) * C, 11 / view.s, { bg: '#c49a1e' });
  for (const d of logi.depots) { drawBadge(cx, 'depot', (d.x + .5) * C, (d.y + .5) * C, 10 / view.s, { square: true, bg: !d.ok ? '#7f1d1d' : d.conn ? '#8a7a4a' : '#a35a3a', stroke: d.conn ? '#e5e7eb' : '#f59e0b', lw: 2 / view.s });
    // (21) запас складу: смужка під значком
    if (d.sup != null) { const w = 22 / view.s, h = 4 / view.s, x0 = (d.x + .5) * C - w / 2, y0 = (d.y + .5) * C + 13 / view.s; cx.fillStyle = 'rgba(0,0,0,.65)'; cx.fillRect(x0, y0, w, h); cx.fillStyle = d.sup > 50 ? '#2ecc71' : d.sup > 20 ? '#f1c40f' : '#e74c3c'; cx.fillRect(x0, y0, w * Math.max(0, Math.min(1, d.sup / 100)), h); } }
}

// ---- плавний рух: клієнт інтерполює між оновленнями (кожні ~2 с) ----
function syncDisp(snap) {
  const now = performance.now(), seen = new Set();
  for (const u of myUnits) { const k = 'u' + u.id; seen.add(k); setDisp(k, u.x, u.y, now, snap); }
  for (const v of visUnits) { const k = 'v' + v.id; seen.add(k); setDisp(k, v.x, v.y, now, snap); }
  for (const k in dispPos) if (!seen.has(k)) delete dispPos[k];
  kickAnim();
}
function setDisp(k, x, y, now, snap) {
  const d = dispPos[k]; if (!d || snap && Math.hypot(d.x - x, d.y - y) > 12) { dispPos[k] = { x, y, fx: x, fy: y, tx: x, ty: y, t0: now, dur: 1 }; return; }
  if (d.tx === x && d.ty === y) return; d.fx = d.x; d.fy = d.y; d.tx = x; d.ty = y; d.t0 = now; d.dur = Math.hypot(x - d.x, y - d.y) > 40 ? 1 : 2100;
}
function kickAnim() { if (animOn) return; animOn = true; animTick(); }
function animTick() {
  const now = performance.now(); let busy = false;
  for (const k in dispPos) { const d = dispPos[k]; const t = Math.min(1, (now - d.t0) / d.dur); d.x = d.fx + (d.tx - d.fx) * t; d.y = d.fy + (d.ty - d.fy) * t; if (t < 1) busy = true; }
  if (typeof tab !== 'undefined' && tab === 'map') drawMap();
  if (busy) setTimeout(animTick, 60); else animOn = false;
}
async function loadLive() {
  if (liveBusy || !me || !me.country || (typeof tab !== 'undefined' && tab !== 'map')) return; if (Date.now() - lastLive < 1100) return; liveBusy = true; lastLive = Date.now();
  try {
    const d = await api('units/live'), ids = new Set(d.mine.map((u) => u.id));
    if (d.mine.length !== myUnits.length || myUnits.some((u) => !ids.has(u.id))) { liveBusy = false; return loadUnits(); }
    for (const m of d.mine) { const u = myUnits.find((x) => x.id === m.id); if (u) Object.assign(u, { x: m.x, y: m.y, tx: m.tx, ty: m.ty, order_kind: m.order_kind, cut: m.cut, battle_id: m.battle_id }); }
    visUnits = d.vis; if (typeof selVis !== 'undefined' && selVis) selVis = visUnits.find((v) => v.id === selVis.id) || null;
    syncDisp(false);
    if (d.occVer !== lastOccVer) { lastOccVer = d.occVer; await loadOcc(); }
    if ((layer === 'logistics' || layer === 'supply') && ++liveN % 4 === 0) { await loadLogi(); buildSupply(); }
    if (!animOn) drawMap();
  } catch { /* наступне оновлення спробує знову */ }
  liveBusy = false;
}

// ---- мирна конференція: малювання нових кордонів на мапі ----
const brushMode = () => mode.kind === 'expand' || mode.kind === 'aterr' || mode.kind === 'confdraw' || mode.kind === 'armyzone' || mode.kind === 'provdraw';
async function startConfDraw(cfId, readonly) {
  let d; try { d = await api('conf/get?id=' + cfId); } catch (e) { return toast(e.message, true); }
  const cf = d.conf, my = me.country.id, iA = cf.a === my, T = cf.terms, other = iA ? cf.b : cf.a;
  if (my !== cf.a && my !== cf.b) { // додатковий учасник: позначає лише свої вимоги до головного супротивника
    const p = (cf.parts || []).find((x) => x.cid === my); if (!p) return; closeModal(); showTab('map'); await setLayer('owners');
    return setMode({ kind: 'confdraw', cfId, cf, other: p.side === 'a' ? cf.b : cf.a, iA: true, take: true, onlyTake: true, extDraw: my, readonly: !!readonly, sets: { take: new Set(((T.ext || {})[my] || {}).list || []), give: new Set() }, limits: { take: p.limit, give: 0 } });
  }
  closeModal(); showTab('map'); await setLayer('owners');
  const takeL = (iA ? T.toA.list : T.toB.list) || [], giveL = (iA ? T.toB.list : T.toA.list) || [];
  setMode({ kind: 'confdraw', cfId, cf, other, iA, take: true, readonly: !!readonly, sets: { take: new Set(takeL), give: new Set(giveL) }, limits: iA ? { take: cf.limits.b, give: cf.limits.a } : { take: cf.limits.a, give: cf.limits.b } });
}
async function startTradeDraw(id, lists, max, onDone, take = true, onlyTake = false) {
  closeModal(); closeDrawer(); showTab('map'); await setLayer('owners');
  setMode({ kind: 'confdraw', trade: true, onlyTake, backTab: onlyTake ? 'diplo' : 'trade', onDone, cfId: 0, cf: null, other: id, iA: true, take, readonly: false, sets: { take: new Set(lists.get), give: new Set(lists.give) }, limits: { take: max, give: onlyTake ? 0 : max } });
}
function confCalc() {
  const el = $('#confcnt'); if (el) el.innerHTML = mode.onlyTake ? `Позначено: <b>${mode.sets.take.size}</b> кл.` : `Забираєш: <b>${mode.sets.take.size}</b> з ${mode.limits.take} · віддаєш: <b>${mode.sets.give.size}</b> з ${mode.limits.give}`; preview = [...brush]; drawMap();
}
function drawConfSets(C) {
  const other = mode.take ? mode.sets.give : mode.sets.take, col = other === mode.sets.give ? (countries[mode.other] || {}).color : me.country.color;
  cx.globalAlpha = .5; cx.fillStyle = col || '#888'; for (const i of other) cx.fillRect((i % land.gw) * C, ((i / land.gw) | 0) * C, C, C); cx.globalAlpha = 1;
}
function confBanner(b) {
  const m = mode, on = m.take ? m.sets.take : m.sets.give; brush = on; previewBad = [];
  const oname = (countries[m.other] || {}).name || '', ly = (k, n) => `<button class="${layer === k ? '' : 'ghost'} sm" data-cly="${k}">${n}</button>`;
  b.innerHTML = `<span>${m.readonly ? 'Запропоновані кордони (перегляд).' : m.onlyTake ? `Позначте території «${esc(oname)}», які вимагаєте.` : 'Малювання кордонів.'} ${m.readonly ? '' : `${m.onlyTake ? '' : `<select id="cfm" style="width:auto"><option value="take"${m.take ? ' selected' : ''}>Забрати в «${esc(oname)}»</option><option value="give"${m.take ? '' : ' selected'}>Віддати «${esc(oname)}»</option></select>`} Shift — стирати, Ctrl або права кнопка — рух мапи. Пензель: <input type="range" id="bsz" min="1" max="30" value="${brushR}" style="width:90px">`} <span id="confcnt"></span> Шари: ${ly('owners', 'Держави')}${ly('resources', 'Ресурси')}${ly('facilities', 'Мої об’єкти')}</span>${m.readonly ? '' : '<button id="cfdone">Готово</button><button class="ghost" id="cfclr">Очистити</button>'}<button class="ghost" id="cfx">${m.readonly ? 'Закрити' : 'Скасувати'}</button>`;
  b.classList.remove('hidden');
  b.querySelectorAll('[data-cly]').forEach((x) => x.onclick = async () => { await setLayer(x.dataset.cly); confBanner(b); });
  const sz = $('#bsz'); if (sz) sz.oninput = (e) => { brushR = +e.target.value; drawMap(); };
  const sel = $('#cfm'); if (sel) sel.onchange = () => { m.take = sel.value === 'take'; confBanner(b); };
  const clr = $('#cfclr'); if (clr) clr.onclick = () => { brush.clear(); confCalc(); };
  const back = () => { const id = m.cfId; setMode({ kind: 'idle' }); if (m.trade) openCountry(m.other, m.backTab || 'trade'); else openConfWin(id); };
  $('#cfx').onclick = back;
  const dn = $('#cfdone'); if (dn && m.trade) dn.onclick = () => { m.onDone([...m.sets.take], [...m.sets.give]); toast('Території позначено в угоді'); back(); };
  else if (dn) dn.onclick = () => act(async () => {
    const d = await api('conf/get?id=' + m.cfId), T = JSON.parse(JSON.stringify(d.conf.terms)), toMine = [...m.sets.take], toTheirs = [...m.sets.give], iA = m.iA;
    if (m.extDraw) { T.ext = T.ext || {}; const s0 = T.ext[m.extDraw] || { cells: 0, money: 0, res: {} }; s0.list = toMine; s0.cells = toMine.length; T.ext[m.extDraw] = s0; await api('conf/terms', { id: m.cfId, terms: T }); toast('Вимоги передано в конференцію'); return back(); }
    (iA ? T.toA : T.toB).list = toMine; (iA ? T.toA : T.toB).cells = toMine.length; (iA ? T.toB : T.toA).list = toTheirs; (iA ? T.toB : T.toA).cells = toTheirs.length;
    await api('conf/terms', { id: m.cfId, terms: T }); toast('Кордони передано в конференцію'); back();
  });
  confCalc();
}
