// Оновлення 8: операції (обґрунтування війни, шпигунство, їжа), журнал історії, спостерігач
async function renderOps(v) {
  if (!me.country) return;
  const sp = await api('spy/ops'), others = Object.entries(countries).map(([id, c]) => ({ id: +id, name: c.name })).filter((c) => c.id !== me.country.id);
  const opt = others.map((c) => `<option value="${c.id}">${esc(c.name)}</option>`).join('');
  const box = document.createElement('div'); box.className = 'card pad'; box.innerHTML = `<h3>Операції</h3>
  <h4>Обґрунтування цілей війни</h4><p class="hint">100–150 діб підготовки. Після цього війна вважається виправданою (без штрафів репутації), а на 90 діб зростають мораль і підтримка війни. Війну можна почати й без обґрунтування.</p>
  <div class="row"><select id="jt">${opt}</select><button id="jgo">Почати обґрунтування (35 ОД)</button></div>
  <h4>Розвідувальні операції</h4><div class="row"><select id="st">${opt}</select><select id="sk">${sp.ops.map((o) => `<option value="${o.k}">${o.n} — ${short(o.cost)} $ · ${o.d}</option>`).join('')}</select><button id="sgo">Виконати</button></div>
  <h4>Їжа</h4><p class="hint">Їжа тепер — звичайний ресурс: ферми, запас, голод окремо в кожній державі. Усе це — у вкладці <b>Моя держава → Економіка</b>.</p>`;

  v.appendChild(box);
  $('#jgo').onclick = () => act(async () => { const r = await api('war/justify', { target: +$('#jt').value }); toast(`Обґрунтування триватиме ${r.days} діб`); }); 
  $('#sgo').onclick = () => act(async () => { const r = await api('spy/op', { target: +$('#st').value, kind: $('#sk').value }); toast(r.success ? 'Успіх: ' + (r.msg || '') : r.caught ? 'Провал: агентів спіймано!' : 'Провал: операція не вдалась', !r.success); });


  const hb = document.createElement('div'); hb.className = 'card pad'; hb.innerHTML = '<h3>Журнал історії</h3><div id="hist" class="muted">Завантаження…</div>'; v.appendChild(hb);
  const h = await api('history'); $('#hist').innerHTML = h.items.map((n) => `<div class="news"><small>${gdate(n.day)}</small> ${esc(n.text)}</div>`).join('') || 'Подій ще немає';
  if (me.user.role === 'admin') { const o = await api('admin/observe'); const ob = document.createElement('div'); ob.className = 'card pad'; ob.innerHTML = `<h3>Спостерігач (адмін)</h3><div style="overflow:auto"><table><tr><th>Держава</th><th>ВВП</th><th>Казна</th><th>Стаб.</th><th>Армія</th><th>Їжа</th><th>Виснаж.</th><th>Війна</th><th>Обґрунтування</th></tr>${o.countries.map((c) => `<tr><td>${esc(c.name)}${c.bot ? ' 🤖' : ''}</td><td>${short(c.gdp)}</td><td>${short(c.treasury)}</td><td>${c.stab}</td><td>${c.units}</td><td>${c.food}</td><td>${c.xwar}</td><td>${c.war ? '⚔' : ''}</td><td>${c.goals.map((g) => esc(g.to)).join(', ')}</td></tr>`).join('')}</table></div>`; v.appendChild(ob); }
}
