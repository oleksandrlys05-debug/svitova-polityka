// Оновлення 16: дерево технологій як у HoI4 — 7 гілок, національні нахили, епохи, силуети техніки, фото з Вікіпедії
const TB = [['infantry', 'Піхота'], ['armor', 'Бронетехніка'], ['artillery', 'Артилерія'], ['air', 'Авіація'], ['navy', 'Флот'], ['airwar', 'ППО, ракети й дрони'], ['industry', 'Промисловість і наука']];
const AIRWAR = ['drones', 'missiles', 'airdef', 'radar'];
let techTab = 'infantry', techSel = null, techData = null, techView = '';
try { techTab = localStorage.techTab || 'infantry'; } catch { /* ні */ }
const ERA_N = ['I', 'II', 'III', 'IV', 'V'], ERA_Y = ['1939–49', '1950–60-ті', '1970–80-ті', '1990–2000-ні', 'сучасність'];
// ---- силуети: тип + невеликі відмінності за нахилом і назвою, щоб техніка була схожа й різна ----
const hashS = (s) => { let h = 0; for (const ch of String(s)) h = (h * 31 + ch.charCodeAt(0)) | 0; return Math.abs(h); };
function techSvg(icon, name, slant) {
  const h = hashS(name), sov = ['ru', 'ua', 'cn'].includes(slant), P = (d) => `<path d="${d}" fill="currentColor"/>`, C = (x, y, r) => `<circle cx="${x}" cy="${y}" r="${r}" fill="currentColor"/>`;
  const L = 26 + (h % 9), mag = 4 + (h % 4);
  const G = {
    rifle: () => P(`M2 10h${L}v3H2z`) + P(`M${L + 2} 9h7l8 2v4l-9 1-6-3z`) + P(`M17 13h3l-1 6h-3z`),
    assault: () => P(`M2 10h${L - 2}v3H2z`) + P(`M${L} 9h7l9 3v3l-8 1-8-3z`) + (sov ? P(`M${L - 9} 13h5l3 ${mag + 3}-4 1z`) : P(`M${L - 8} 13h4v${mag + 3}h-4z`)) + (h % 2 ? P(`M${L - 14} 7h8v3h-8z`) : ''),
    smg: () => P('M6 9h22v4H6z') + P('M28 8h7l7 3v3l-8 1-6-2z') + (h % 2 ? P('M14 13h3v8h-3z') : `<circle cx="16" cy="17" r="4.5" fill="currentColor"/>`),
    mg: () => P(`M1 10h${L + 4}v3H1z`) + P(`M${L + 5} 9h5l8 3v3l-8 1-5-3z`) + P('M20 13h7v5h-7z') + P('M8 13l-3 9h2l3-9zM10 13l3 9h-2l-3-9z'),
    sniper: () => P('M1 11h32v3H1z') + P('M33 10h6l8 2v4l-9 1-5-3z') + P(`M${12 + (h % 4)} 6h13v3H${12 + (h % 4)}z`) + P('M19 14h3l-1 6h-3z'),
    at: () => P(`M3 10h${34 + (h % 4)}v${h % 2 ? 5 : 4}H3z`) + P('M39 9l8 3.5-8 3.5z') + P('M14 15h3v6h-3z'),
    atgm: () => P('M4 9h30v6H4z') + P('M34 8h6l6 4-6 4h-6z') + P('M12 15l-5 8h2l5-8zM20 15l5 8h-2l-5-8z') + (h % 2 ? P('M16 4h8v5h-8z') : ''),
    mortar: () => P('M14 20l18-16 2 2-17 16z') + P('M8 20h16v3H8z') + P('M24 13l6 9h-2l-5-8z'),
    car: () => P(`M6 ${9 + (h % 2)}h${26 + (h % 5)}l7 5v4H5v-6z`) + C(13, 19, 3.5) + C(33, 19, 3.5) + (h % 3 ? P('M18 6h6v4h-6z') : ''),
    tank: () => { const tw = 14 + (h % 5), gx = 30 + (h % 3); const tur = sov ? `<ellipse cx="${20 + (h % 3)}" cy="11" rx="${tw / 2}" ry="4" fill="currentColor"/>` : P(`M${13 - (h % 2)} 7h${tw}l3 7H${11 - (h % 2)}z`); return P('M3 14h42l-2 5H5z') + P('M5 19h38v3H5z') + tur + P(`M${gx} 10h${16 - (h % 4)}v2H${gx}z`); },
    heavy: () => P('M2 13h44l-2 6H4z') + P('M4 19h40v3H4z') + P(`M11 6h${20 + (h % 4)}v7H11z`) + P('M31 8h16v3H31z'),
    apc: () => P(`M5 ${8 + (h % 2)}h33l6 ${5 + (h % 2)}v5H5z`) + C(12, 20, 3) + C(23, 20, 3) + C(34, 20, 3) + (h % 2 ? P('M18 5h7v3h-7z') : ''),
    ifv: () => P('M4 12h40l-2 6H6z') + P('M6 18h36v3H6z') + P(`M${15 + (h % 3)} 7h12v5H${15 + (h % 3)}z`) + P('M27 8h15v2H27z') + (h % 2 ? P('M14 5h5v3h-5z') : ''),
    gun: () => P('M6 18l30-10 1 2-30 10z') + C(14, 19, 4) + P('M2 21l12-2v2l-12 2z'),
    spg: () => P('M4 13h38l-2 6H6z') + P('M6 19h34v3H6z') + P(`M10 ${7 - (h % 2)}h20v6H10z`) + P(`M30 ${8 + (h % 2)}h17v2H30z`),
    mlrs: () => P('M4 14h30l6 4v3H4z') + C(10, 21, 2.5) + C(20, 21, 2.5) + C(32, 21, 2.5) + P('M8 6l26-4 1 7-26 4z'),
    aagun: () => P('M10 16h24v4H10z') + P('M20 16l14-12 2 2-14 12z') + P('M23 16l14-12 1 2-14 12z'),
    plane: () => P('M4 12h38l6 2-6 2H4z') + P('M18 4h6l4 10h-6zM18 24h6l4-10h-6z') + P('M4 8h4l3 6H4z'),
    jet: () => P(`M3 12h36l9 2-9 2H3z`) + P(`M${16 + (h % 4)} 3l9 11h-6zM${16 + (h % 4)} 25l9-11h-6z`) + P('M3 7h4l4 7H3z'),
    bomber: () => P('M2 11h40l6 3-6 3H2z') + P('M14 1h6l6 13h-6zM14 27h6l6-13h-6z') + P('M2 6h5l3 8H2z'),
    heli: () => P('M10 11h22l6 4-6 4H10z') + P('M2 14h10v2H2z') + P('M8 7h32v2H8z') + P('M14 19h18v2H14z'),
    ship: () => P(`M2 15h44l-5 6H6z`) + P(`M${14 + (h % 4)} 9h14v6H${14 + (h % 4)}z`) + P('M20 4h3v5h-3z') + (h % 2 ? P('M33 11h6v4h-6z') : ''),
    sub: () => `<ellipse cx="24" cy="15" rx="21" ry="4" fill="currentColor"/>` + P(`M${18 + (h % 4)} 8h7v6h-7z`),
    radio: () => P('M14 8h20v14H14z') + P('M30 2h2v6h-2z'), radar: () => P('M10 6a14 14 0 0 1 28 0z') + P('M23 6h2v14h-2z') + P('M16 20h16v3H16z'),
    nv: () => C(17, 13, 6) + C(31, 13, 6) + P('M17 11h14v4H17z'), vest: () => P('M16 3h4l4 4 4-4h4l3 6-3 3v10H16V12l-3-3z'),
    armor: () => P('M24 2l14 5v7c0 5-6 8-14 10-8-2-14-5-14-10V7z'), scope: () => `<circle cx="24" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="3"/>` + P('M23 3h2v18h-2zM15 11h18v2H15z'),
    drone: () => C(10, 7, 5) + C(38, 7, 5) + C(10, 19, 4) + C(38, 19, 4) + P('M18 10h12v6H18z'),
    factory: () => P('M4 22V10l10 5V10l10 5V10l10 5V4h6v18z'), steel: () => P('M6 16h36l-4 6H10z') + P('M12 10h24l-3 6H15z'), oil: () => P('M20 2h8l2 6h-12z') + P('M22 8h4v14h-4z') + P('M12 22h24v2H12z'),
    book: () => P('M8 4h14v18H8z') + P('M26 4h14v18H26z'), truck: () => P('M4 8h24v10H4z') + P('M28 11h10l5 5v2H28z') + C(11, 20, 3) + C(34, 20, 3), med: () => P('M20 4h8v8h8v8h-8v8h-8v-8h-8v-8h8z'),
  };
  return `<svg viewBox="0 0 48 26" aria-hidden="true">${(G[icon] || G.radio)()}</svg>`;
}
// ---- фото з Вікіпедії під час наведення ----
const WIKI_HINT = { rifle: ['гвинтівка', 'rifle'], smg: ['пістолет-кулемет', 'submachine gun'], mg: ['кулемет', 'machine gun'], at: ['гранатомет', 'anti-tank weapon'], atgm: ['протитанковий ракетний комплекс', 'anti-tank missile'], sniper: ['снайперська гвинтівка', 'sniper rifle'], mortar: ['міномет', 'mortar'], recon: ['бронеавтомобіль', 'armored car'], light: ['танк', 'tank'], tank: ['танк', 'tank'], td: ['танк', 'tank'], apc: ['бронетранспортер', 'armored personnel carrier'], ifv: ['бойова машина піхоти', 'infantry fighting vehicle'], spart: ['самохідна артилерійська установка', 'self-propelled howitzer'], towed: ['гаубиця', 'howitzer'], mlrs: ['реактивна система залпового вогню', 'multiple rocket launcher'], fighter: ['винищувач', 'fighter aircraft'], attack: ['літак', 'attack aircraft'], bomber: ['бомбардувальник', 'bomber'], heli: ['гелікоптер', 'helicopter'], destroyer: ['корабель', 'destroyer'], sub: ['підводний човен', 'submarine'], frigate: ['корабель', 'frigate'] };
const wikiCache = {};
async function wikiLookup(name, hint) {
  const key = name + '|' + hint; if (wikiCache[key] !== undefined) return wikiCache[key];
  const clean = name.replace(/\((ROK|кит\.|ЗСУ|яп\.|британ\.|модерн\.|ленд-ліз|Bundeswehr)[^)]*\)/g, '').replace(/^(ПЧ|Есмінець|Фрегат|Корвет|Крейсер|СКР|Сторожовик|Ракетний катер|Броньований катер|Міні-ПЧ)\s+/, '').trim(), H = WIKI_HINT[hint] || ['', ''];
  // оновлення 20: беремо не перший-ліпший результат, а статтю саме про цю модель (назва збігається, текст — про техніку)
  const norm = (x) => String(x).toLowerCase().replace(/[‐-―]/g, '-').replace(/[«»"'’]/g, ''), toks = norm(clean).split(/[\s/,]+/).filter((w) => w.length >= 2), keyT = toks.filter((w) => /\d/.test(w)), must = keyT.length ? keyT : toks.slice(0, 1);
  const MIL = /зброя|гвинтів|автомат|кулемет|пістолет|міномет|гармат|гаубиц|танк|бронетран|бронемаш|бмп|бтр|сау|рсзв|ракет|літак|винищувач|бомбардув|штурмовик|гелікоптер|вертоліт|корабел|есмін|фрегат|корвет|крейсер|підводн|авіанос|зеніт|weapon|rifle|carbine|machine gun|submachine|pistol|mortar|howitzer|artillery|gun|tank|armou?red|vehicle|missile|rocket|aircraft|fighter|bomber|attack|helicopter|ship|destroyer|frigate|corvette|cruiser|submarine|carrier|launcher/i;
  const ok = (p) => { const t = norm(p.title); return must.every((w) => t.includes(w)) && MIL.test((p.extract || '') + ' ' + p.title) && p.thumbnail; };
  const wrap = (lang, p) => ({ img: p.thumbnail.source, title: p.title, text: p.extract || '', url: `https://${lang}.wikipedia.org/wiki/${encodeURIComponent(p.title.replace(/ /g, '_'))}` });
  const base = (lang) => `https://${lang}.wikipedia.org/w/api.php?action=query&format=json&origin=*&prop=pageimages|extracts&piprop=thumbnail&pithumbsize=420&exintro=1&explaintext=1&exsentences=2&redirects=1`;
  const exact = async (lang) => { const r = await fetch(base(lang) + '&titles=' + encodeURIComponent(clean)); const d = await r.json(); const p = d.query && Object.values(d.query.pages || {})[0]; return p && !p.missing && ok(p) ? wrap(lang, p) : null; };
  const tryWiki = async (lang, q) => { const r = await fetch(base(lang) + '&generator=search&gsrlimit=6&gsrsearch=' + encodeURIComponent(q)); const d = await r.json(); const ps = d.query ? Object.values(d.query.pages || {}).sort((a, b) => (a.index || 0) - (b.index || 0)) : []; const p = ps.find(ok); return p ? wrap(lang, p) : null; };
  let res = null; try { res = await exact('en') || await exact('uk') || await tryWiki('en', `${clean} ${H[1]}`) || await tryWiki('uk', `${clean} ${H[0]}`); } catch { res = null; }
  wikiCache[key] = res; return res;
}
let photoT = 0;
function techPhotoHover(el, t) {
  clearTimeout(photoT); const box = $('#techphoto'); if (!box) return; if (!t || !t.hint) { box.classList.add('hidden'); return; }
  photoT = setTimeout(async () => { box.innerHTML = `<div class="muted">Шукаю фото «${esc(t.name)}»…</div>`; place(); box.classList.remove('hidden'); const w = await wikiLookup(t.name, t.hint); if (!el.matches(':hover')) return;
    box.innerHTML = w ? `<img src="${esc(w.img)}" alt="${esc(t.name)}"><b>${esc(t.name)}</b><div class="muted" style="font-size:12px">${esc(w.text).slice(0, 220)}</div><div class="muted" style="font-size:11px">Фото: Вікіпедія («${esc(w.title)}»)</div>` : `<b>${esc(t.name)}</b><div class="muted">Фото не знайдено (або немає інтернету).</div>`; place(); }, 350);
  function place() { const r = el.getBoundingClientRect(); box.style.left = Math.min(innerWidth - 300, r.right + 10) + 'px'; box.style.top = Math.max(70, Math.min(innerHeight - 320, r.top - 20)) + 'px'; }
}
// ---- побудова дерева ----
function techLayout(list) {
  // лінійки: за полем line; вбудовані гілки (дрони тощо) — за категорією, епоха за глибиною залежностей
  const byId = Object.fromEntries(techData.techs.map((t) => [t.id, t])), depth = (t, s = new Set()) => { if (s.has(t.id)) return 0; s.add(t.id); const r = (t.requires || []).map((x) => byId[x]).filter((x) => x && x.cat === t.cat); return r.length ? 1 + Math.max(...r.map((x) => depth(x, s))) : 0; };
  const rows = []; for (const t of list) { const ln = t.line || (techData.categories.find((c) => c.id === t.cat) || {}).name || t.cat, era = t.era || Math.min(5, depth(t) + 1); let r = rows.find((x) => x.n === ln); if (!r) rows.push(r = { n: ln, nodes: [] }); r.nodes.push({ ...t, era, icon: t.icon || ({ drones: 'drone', missiles: 'atgm', airdef: 'aagun', radar: 'radar' })[t.cat] || 'radio' }); }
  for (const r of rows) r.nodes.sort((a, b) => a.era - b.era); return rows;
}
async function renderTech(b) {
  let d; try { d = await api('tech/state' + (techView ? '?slant=' + techView : '')); } catch (e) { b.innerHTML = `<div class="card pad err">${esc(e.message)}</div>`; return; }
  techData = d; const own = (t) => t.own, cur = Object.fromEntries(d.research.map((r) => [r.tech, r])), byId = Object.fromEntries(d.techs.map((t) => [t.id, t]));
  const list = d.techs.filter((t) => (techTab === 'airwar' ? AIRWAR.includes(t.cat) : t.cat === techTab)), rows = techLayout(list);
  const W = 170, U = 54, GAP = 26, PAD = 18, wid = (n) => (n.kind === 'u' ? U : W);
  const eraW = [0, 1, 2, 3, 4].map((e) => Math.max(190, ...rows.map((r) => r.nodes.filter((n) => n.era === e + 1).reduce((s, n) => s + wid(n) + GAP, PAD)))), eraX = eraW.map((_, e) => eraW.slice(0, e).reduce((s, v) => s + v, 0)), total = eraW.reduce((s, v) => s + v, 0) + 10;
  const can = (t) => !t.own && !cur[t.id] && t.requires.every((r) => byId[r] && byId[r].own), effTxt = (t) => Object.entries(t.effects || {}).map(([k, v]) => (typeof effText === 'function' ? effText(k, v) : k + ' ' + v)).join(', ');
  let board = `<div class="tgrid" style="width:${total}px"><div class="teras">${eraW.map((w, e) => `<div style="width:${w}px" class="${e + 1 === d.era ? 'now' : e + 1 > d.era ? 'future' : ''}">Епоха ${ERA_N[e]}<small>${ERA_Y[e]}${e + 1 > d.era ? ' · попереду часу' : e + 1 === d.era ? ' · зараз' : ''}</small></div>`).join('')}</div>`;
  for (const r of rows) {
    const pos = []; [0, 1, 2, 3, 4].forEach((e) => { let x = eraX[e] + PAD; r.nodes.forEach((n, i) => { if (n.era !== e + 1) return; pos[i] = x; x += wid(n) + GAP; }); });
    const hasCap = r.nodes.some((n) => n.kind === 'u'), first = pos[0], li = r.nodes.length - 1, last = pos[li] + wid(r.nodes[li]);
    board += `<div class="trow16"><span class="trn">${esc(r.n)}</span><div class="tlane ${hasCap ? 'cap' : ''}">${eraX.slice(1).map((x) => `<i class="tband" style="left:${x}px"></i>`).join('')}<i class="trail" style="left:${first + 10}px;width:${Math.max(0, last - first - 20)}px"></i>`;
    r.nodes.forEach((n, i) => {
      const st = n.own ? 'own' : cur[n.id] ? 'cur' : can(n) ? 'can' : 'lock', pr = cur[n.id] ? Math.min(100, cur[n.id].progress / n.days * 100) : 0, rn = n.kind === 'u' ? ERA_N[r.nodes.slice(0, i + 1).filter((m) => m.kind === 'u' && m.icon === n.icon).length - 1] || '' : '';
      board += n.kind === 'u'
        ? `<button type="button" class="tnd u ${st} ${techSel === n.id ? 'sel' : ''}" data-tn="${n.id}" style="left:${pos[i]}px" title="${esc(n.name)}">${techSvg(n.icon, n.name, d.view)}<span class="rn">${rn}</span><span class="cap">${esc(n.name)}</span>${pr ? `<i class="tpr" style="width:${pr}%"></i>` : ''}</button>`
        : `<button type="button" class="tnd w ${st} ${n.start ? 'start' : ''} ${techSel === n.id ? 'sel' : ''}" data-tn="${n.id}" style="left:${pos[i]}px">${techSvg(n.icon || 'radio', n.name, d.view)}<span class="t"><b>${esc(n.name)}</b><small>${n.own ? '✓ досліджено' : cur[n.id] ? Math.round(pr) + '%' : n.days + ' д.'}${n.k < 1 && !n.own ? ' · ×' + n.k : ''}</small></span>${pr ? `<i class="tpr" style="width:${pr}%"></i>` : ''}</button>`;
    });
    board += '</div></div>';
  }
  board += '</div>';
  const sel0 = byId[techSel], sel = sel0 ? { ...sel0, icon: sel0.icon || ({ drones: 'drone', missiles: 'atgm', airdef: 'aagun', radar: 'radar' })[sel0.cat] || 'radio' } : null, ars = d.arsenal || {};
  b.innerHTML = `<div class="card pad"><div class="row" style="flex-wrap:wrap;gap:10px;align-items:center"><h3 class="grow" style="margin:0">Дослідження</h3>
      <span class="badge">Нахил: <b>${esc(d.slants[d.slant])}</b></span><span class="badge">Світова епоха: <b>${ERA_N[d.era - 1]}</b></span><span class="badge">Слоти: <b>${d.research.length}/${d.slots}</b></span><span class="badge">Швидкість ×${nf(d.speed, 2)}</span>
</div>
    <p class="hint" style="margin:6px 0">Нахил держави визначено випадково: від нього залежать моделі зброї й техніки. Технології епохи, до якої світ ще не дійшов (нова епоха — кожні ${d.eraDays} діб), досліджуються повільніше. Слоти додають технології гілки «Промисловість і наука».</p>
    ${d.research.map((r) => { const t = byId[r.tech]; return t ? `<div class="row" style="margin:4px 0"><b style="min-width:200px">${esc(t.name)}</b><div class="bar grow"><i style="width:${Math.min(100, r.progress / t.days * 100)}%"></i></div><span class="muted" style="min-width:110px;text-align:right">ще ${nf(r.left, 1)} д.</span><button class="ghost sm" data-rc="${r.id}">Скасувати</button></div>` : ''; }).join('')}
    ${Object.keys(ars).length ? `<div class="muted" style="font-size:13px;margin-top:6px">Озброєння зараз: ${Object.values(ars).map((x) => esc(x.name)).join(' · ')}</div>` : ''}</div>
  <div class="tabs ttabs">${TB.map(([k, n], i) => `<button type="button" data-tt="${k}" class="${k === techTab ? 'on' : ''}">${i + 1}. ${n}</button>`).join('')}</div>
  <div class="tboard">${board}</div>
  <div class="card pad" id="tinfo">${sel ? `<div class="row" style="gap:12px;align-items:center"><div class="tbig">${techSvg(sel.icon, sel.name, d.view)}</div><div class="grow"><h3 style="margin:0">${esc(sel.name)}</h3><div class="muted">${esc(sel.line || '')} · епоха ${ERA_N[(sel.era || 1) - 1]}${sel.year ? ' · ' + sel.year : ''} · ${sel.own ? 'досліджено' : sel.days + ' діб'}${sel.k < 1 && !sel.own ? ` · попереду часу: швидкість ×${sel.k}` : ''}</div>
      ${effTxt(sel) ? `<div class="pos">${esc(effTxt(sel))}</div>` : ''}${(sel.unlocks.units || []).length || (sel.unlocks.equipment || []).length ? `<div>Відкриває: ${[...(sel.unlocks.units || []).map((k) => UTN[k] || k)].join(', ')}</div>` : ''}${sel.requires.length ? `<div class="muted">Потрібно: ${sel.requires.map((r) => esc((byId[r] || {}).name || r)).join(', ')}</div>` : ''}
      ${can(sel) && !techView ? `<button id="tgo" style="margin-top:8px">Дослідити</button>` : ''}</div></div>` : '<span class="muted">Клікни технологію, щоб побачити подробиці; наведи на модель, щоб побачити фото.</span>'}</div>
  <div id="techphoto" class="hidden"></div>`;
  b.querySelectorAll('[data-tt]').forEach((x) => x.onclick = () => { techTab = x.dataset.tt; try { localStorage.techTab = techTab; } catch { /* ні */ } techSel = null; renderTech(b); });
  b.querySelectorAll('[data-tn]').forEach((x) => { const t = byId[x.dataset.tn]; x.onclick = () => { if (techSel === t.id && can(t) && !techView) return act(async () => { await api('econ/research', { tech: t.id }); renderTech(b); }, 'Дослідження розпочато'); techSel = t.id; renderTech(b); };
    x.onmouseenter = () => techPhotoHover(x, t); x.onmouseleave = () => { clearTimeout(photoT); const p = $('#techphoto'); if (p) p.classList.add('hidden'); }; });
  const go = $('#tgo'); if (go) go.onclick = () => act(async () => { await api('econ/research', { tech: sel.id }); renderTech(b); }, 'Дослідження розпочато');
  b.querySelectorAll('[data-rc]').forEach((x) => x.onclick = () => act(async () => { await api('econ/research/cancel', { id: +x.dataset.rc }); renderTech(b); }));
  { const bd = b.querySelector('.tboard'); try { const k = 'tscroll:' + techTab; bd.scrollLeft = +sessionStorage[k] || 0; bd.onscroll = () => { sessionStorage[k] = bd.scrollLeft; }; } catch { /* ні */ } }
}
