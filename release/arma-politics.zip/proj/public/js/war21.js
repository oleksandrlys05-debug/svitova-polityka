// Оновлення 21 (клієнт): лінія фронту, стрілки наступів, прогноз бою
let front21 = { lines: [], arrows: [] }, front21At = 0;
async function loadFront21(force) { if (!force && Date.now() - front21At < 5000) return; front21At = Date.now(); try { front21 = await api('war21/front'); } catch { front21 = { lines: [], arrows: [] }; } }
setInterval(() => { if (typeof tab !== 'undefined' && tab === 'map' && typeof me !== 'undefined' && me) loadFront21().then(() => { if (front21.lines.length || front21.arrows.length) drawMap(); }); }, 6000);
function drawFront21(C) {
  if (!front21 || (!front21.lines.length && !front21.arrows.length) || !['owners', 'diplo', 'alliances', 'supply', 'logistics'].includes(layer)) return;
  const s = view.s, w = Math.max(1.6 / s, 0.9 * C); cx.save(); cx.lineJoin = 'round'; cx.lineCap = 'round';
  for (const L of front21.lines) for (const p of L.paths) { if (p.length < 2) continue;
    const pts = p.map(([x, y]) => [(x + 1) * C, (y + 0.5) * C]);
    // згладжена лінія
    const sm = pts.map((q0, k) => { let sx = 0, sy = 0, n = 0; for (let t = -2; t <= 2; t++) { const r = pts[k + t]; if (r) { sx += r[0]; sy += r[1]; n++; } } return [sx / n, sy / n]; });
    cx.beginPath(); cx.moveTo(sm[0][0], sm[0][1]); for (const q0 of sm.slice(1)) cx.lineTo(q0[0], q0[1]);
    cx.strokeStyle = 'rgba(10,8,14,.9)'; cx.lineWidth = w * 2.4; cx.stroke(); cx.strokeStyle = '#e03b3b'; cx.lineWidth = w * 1.2; cx.stroke();
    // «зубці» фронту
    if (s > 0.35) { cx.strokeStyle = 'rgba(10,8,14,.85)'; cx.lineWidth = w * 0.8; for (let k = 3; k < sm.length - 1; k += 4) { const [x0, y0] = sm[k - 1], [x1, y1] = sm[k + 1], dx = x1 - x0, dy = y1 - y0, d = Math.hypot(dx, dy) || 1, nx = -dy / d, ny = dx / d, L2 = w * 2.2; cx.beginPath(); cx.moveTo(sm[k][0] - nx * L2, sm[k][1] - ny * L2); cx.lineTo(sm[k][0] + nx * L2, sm[k][1] + ny * L2); cx.stroke(); } } }
  // стрілки наступів за останні ~пів доби
  for (const a of front21.arrows) { const col = (countries[a.cid] || {}).color || '#ddd', x1 = (a.x1 + .5) * C, y1 = (a.y1 + .5) * C, x2 = (a.x2 + .5) * C, y2 = (a.y2 + .5) * C, dx = x2 - x1, dy = y2 - y1, d = Math.hypot(dx, dy) || 1, ux = dx / d, uy = dy / d, nx = -uy, ny = ux, W = Math.max(2.5 / s, 1.6 * C), H = W * 2.4;
    const bx = x2 - ux * H, by = y2 - uy * H; cx.beginPath(); cx.moveTo(x1 + nx * W * 0.5, y1 + ny * W * 0.5); cx.lineTo(bx + nx * W * 0.5, by + ny * W * 0.5); cx.lineTo(bx + nx * W * 1.3, by + ny * W * 1.3); cx.lineTo(x2, y2); cx.lineTo(bx - nx * W * 1.3, by - ny * W * 1.3); cx.lineTo(bx - nx * W * 0.5, by - ny * W * 0.5); cx.lineTo(x1 - nx * W * 0.5, y1 - ny * W * 0.5); cx.closePath();
    cx.fillStyle = col; cx.globalAlpha = 0.85; cx.fill(); cx.globalAlpha = 1; cx.strokeStyle = 'rgba(10,8,14,.9)'; cx.lineWidth = Math.max(1 / s, 0.25 * C); cx.stroke(); }
  cx.restore();
}
{ const prev = window.drawRoads; window.drawRoads = function (C) { if (typeof prev === 'function') prev(C); try { drawFront21(C); } catch (e) { console.error('front21', e); } }; }
// SSE «occ» → оновити лінію фронту
{ const o = window.loadOcc; if (typeof o === 'function') window.loadOcc = async function (...a) { const r = await o.apply(this, a); loadFront21(true).then(() => drawMap()); return r; }; }

// ---------- прогноз бою ----------
async function showPreview21(ids, x, y) {
  let d; try { d = await api(`war21/preview?ids=${ids.join(',')}&x=${Math.round(x)}&y=${Math.round(y)}`); } catch (e) { return; } if (d.none) return;
  let box = document.getElementById('prev21'); if (!box) { box = document.createElement('div'); box.id = 'prev21'; box.className = 'card pad prev21'; document.body.appendChild(box); }
  const col = d.odds >= 65 ? 'var(--pos, #2ecc71)' : d.odds >= 40 ? '#f1c40f' : 'var(--neg, #e74c3c)';
  box.innerHTML = `<div class="row" style="align-items:center"><b class="grow">⚔ Прогноз бою: ${esc(d.foeName)}</b><button class="ghost sm" id="p21x">✕</button></div>
    ${d.defUnits ? `<div style="font-size:22px;font-weight:800;color:${col}">≈ ${d.odds}% <span style="font-size:13px;font-weight:500" class="muted">шанс перемоги · ~${d.hours} год бою</span></div>
    <div class="muted" style="font-size:12.5px">Ви: ${nf(d.attMen)} о/с, сила ${d.pa} (якість ×${d.qa}) · Ворог: ~${nf(Math.round(d.defMen / 100) * 100)} о/с у ${d.defUnits} підр., сила ${d.pd} (якість ×${d.qd}) · ${esc(d.terrain)}</div>
    ${d.mods.length ? `<div style="font-size:12.5px;margin-top:4px">${d.mods.map((m) => `<span class="badge" style="border-color:${(m.side === 'a') ? '#3b82f6' : '#ef4444'}">${esc(m.t)}${m.k ? ` ${m.k > 0 ? '+' : ''}${m.k}%` : ''}</span>`).join(' ')}</div>` : ''}
    ${d.cut ? '<div class="neg" style="font-size:12.5px">⚠ Частина ваших військ в оточенні</div>' : ''}` : `<div>${esc(d.text)}</div>`}
    <div class="row" style="margin-top:6px;gap:6px"><button class="ghost sm" id="p21s">Скасувати наказ</button><span class="grow"></span><span class="muted" style="font-size:11.5px">Чисельність важить; бонуси оборони — не більше ×2,5</span></div>`;
  box.querySelector('#p21x').onclick = () => box.remove();
  box.querySelector('#p21s').onclick = () => act(async () => { for (const id of ids) await api('units/stop', { id }).catch(() => {}); box.remove(); await loadUnits(); }, 'Наказ скасовано');
  clearTimeout(box._t); box._t = setTimeout(() => box && box.remove(), 20000);
}
{ const o = window.orderApi; if (typeof o === 'function') window.orderApi = async function (path, body) { const r = await o(path, body);
    try { if (path === 'units/order' && r && r.kind === 'attack') showPreview21([body.id], body.x, body.y); else if (path === 'units/orders' && body && body.ids && body.ids.length && body.mode === 'point') showPreview21(body.ids, body.x, body.y); } catch { /* ні */ }
    return r; }; }
