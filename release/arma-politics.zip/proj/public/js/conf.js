// Мирна конференція / капітуляція: умови, окремий чат
let confId = 0, confDraft = null, confDirty = false, confKey = '', confSeen = null;
const CF_RES = [['oil', 'Нафта'], ['aluminium', 'Алюміній'], ['chromium', 'Хром'], ['tungsten', 'Вольфрам'], ['rubber', 'Гума'], ['steel', 'Сталь'], ['fuel', 'Паливо'], ['food', 'Їжа'], ['cotton', 'Бавовна'], ['clothing', 'Одяг'], ['medicine', 'Ліки'], ['goods', 'Товари вжитку']];
function openConfWin(id) {
  confId = id; confDraft = null; confDirty = false; confKey = '';
  openModal('<div id="cfbox" class="muted">Завантаження…</div>'); const bx = $('#modal .box'); if (bx) { bx.style.width = 'min(1040px,96vw)'; bx.style.maxWidth = '96vw'; }
  confRefresh(true);
  const old = window.cwClosed; window.cwClosed = () => { confId = 0; window.cwClosed = old; if (old) old(); };
}
async function confRefresh(full) {
  if (!confId || !$('#cfbox') && !full) return; let d; try { d = await api('conf/get?id=' + confId); } catch (e) { if ($('#modal')) closeModal(); return; }
  const cf = d.conf, key = JSON.stringify([cf.terms, cf.status, cf.accA, cf.accB, cf.parts, cf.invitable && cf.invitable.length, cf.waiting]); if (!$('#cfform') || (key !== confKey && !confDirty)) { confKey = key; confDirty = false; renderConf(d); } else renderConfChat(d);
}
function renderConfChat(d) { const ch = $('#cfchat'); if (!ch) return; const atBottom = ch.scrollTop + ch.clientHeight >= ch.scrollHeight - 30, h = d.msgs.map((m) => `<div class="msg ${m.mine ? 'me' : ''}"><small>${esc(m.name)}</small>${esc(m.text)}</div>`).join(''); if (ch.dataset.h !== h) { ch.dataset.h = h; ch.innerHTML = h; if (atBottom) ch.scrollTop = ch.scrollHeight; } }
function renderConf(d) {
  const cf = d.conf, T = cf.terms, cap = cf.kind === 'capitulation', ed = cf.canEdit, open = cf.status === 'open', R = new Set(cf.rows || []), P = cf.parts || [];
  const num = (id, v, dis) => `<input type="number" min="0" id="${id}" value="${v || 0}" ${dis ? 'disabled' : ''} style="width:100%;min-width:90px">`;
  const nameOf = (id) => id === cf.a ? cf.aName : id === cf.b ? cf.bName : ((P.find((p) => p.cid === id) || {}).name || '?');
  // стовпці: головні сторони + додаткові учасники (кожен отримує від головного супротивника)
  const cols = [{ k: 'a', s: T.toA, name: cf.aName, can: R.has('a') }, { k: 'b', s: T.toB, name: cf.bName, can: R.has('b') }, ...P.map((p) => ({ k: 'x' + p.cid, cid: p.cid, s: T.ext[p.cid] || { cells: 0, money: 0, res: {} }, name: p.name, can: R.has('x' + p.cid), part: p }))];
  const subOpts = [['', 'Без підпорядкування']].concat([[cf.a, 'a'], [cf.b, 'b']].flatMap(([who, sd]) => (cf.subMasters[sd] || []).flatMap((m) => [[`${who}:vassal:${m}`, `${nameOf(who)} стає васалом (${nameOf(m)})`], [`${who}:puppet:${m}`, `${nameOf(who)} стає маріонеткою (${nameOf(m)})`]])));
  const curSub = T.sub ? `${T.sub.who}:${T.sub.kind}:${T.sub.master || (T.sub.who === cf.a ? cf.b : cf.a)}` : '';
  const loserName = cap ? (cf.loser === cf.a ? cf.aName : cf.bName) : '', mk = (b) => `<b class="${b ? 'pos' : 'neg'}">${b ? '✓' : '✗'}</b>`;
  const accTxt = cap ? (P.length ? `<div style="margin:8px 0">Вимоги союзників: ${P.map((p) => `${esc(p.name)} ${p.bot ? '<span class="muted">(бот)</span>' : mk(p.acc)}`).join(' · ')}${cf.waiting ? ' <span class="muted">— переможець зможе підписати, коли всі підтвердять або мине доба</span>' : ''}</div>` : '')
    : `<div style="margin:8px 0">Згода: ${esc(cf.aName)} ${mk(cf.accA)} · ${esc(cf.bName)} ${mk(cf.accB)}${P.map((p) => ` · ${esc(p.name)} ${mk(p.acc)}`).join('')}</div>`;
  const sideList = (sd) => [sd === 'a' ? cf.aName : cf.bName, ...P.filter((p) => p.side === sd).map((p) => p.name)].map(esc).join(', ');
  const extraCap = cap && !cf.isMain && cf.mySide === 'b', host = cap && cf.winner === me.country.id, lim = (c) => c.k === 'a' ? cf.limits.b : c.k === 'b' ? cf.limits.a : c.part.limit;
  const hdr = cols.map((c) => `<th class="r">${esc(c.name)} отримує${c.part ? ` <span class="muted" style="font-weight:400">(від ${esc(nameOf(c.part.side === 'a' ? cf.b : cf.a))})</span>` : ''}</th>`).join('');
  $('#cfbox').outerHTML = `<div id="cfbox"><h3>${cap ? 'Капітуляція' : 'Мирна конференція'}: <span class="sw" style="background:${esc(cf.aColor)}"></span>${esc(cf.aName)} ↔ <span class="sw" style="background:${esc(cf.bColor)}"></span>${esc(cf.bName)}</h3>
  ${P.length ? `<p class="hint" style="margin-top:0">Сторона 1: ${sideList('a')}. Сторона 2: ${sideList('b')}.</p>` : ''}
  ${!open ? `<div class="card pad"><b>${cf.status === 'done' ? 'Угоду підписано.' : 'Конференцію закрито, війна триває.'}</b><div>${esc(cf.result || '')}</div></div>` : ''}
  ${cap && open ? `<p class="hint" style="margin-top:0">${esc(loserName)} капітулювала. ${host ? 'Ти диктуєш умови: задай їх і підпиши. Вимоги союзників-гравців змінюють лише вони самі.' : extraCap ? 'Ти учасник війни на боці переможця: впиши свої вимоги у свій стовпчик і надішли. Підписує угоду переможець.' : 'Ти не можеш нічого змінювати чи вимагати: лише писати в чат і спостерігати, що залишить переможець.'}</p>` : ''}
  <div class="grid g2" style="align-items:start"><div id="cfform"><div style="overflow-x:auto"><table><tr><th></th>${hdr}</tr>
    <tr><td>Територія, кл.</td>${cols.map((c) => `<td>${num('cf_c_' + c.k, c.s.cells, !c.can || !!c.s.list)}<div class="muted" style="font-size:12px">макс. ${lim(c)}</div></td>`).join('')}</tr>
    <tr><td>Гроші, $</td>${cols.map((c) => `<td>${num('cf_m_' + c.k, c.s.money, !c.can)}</td>`).join('')}</tr>
    </table></div><div style="margin:4px 0">${cols.some((c) => c.s.list) ? `<span class="badge">Кордони намальовано на мапі</span> ` : ''}<button class="ghost sm" id="cfmap">${ed && open ? 'Накреслити кордони на мапі' : 'Показати кордони на мапі'}</button>${ed && open && cols.some((c) => c.can && c.s.list) ? ' <button class="ghost sm" id="cfmapclr">Прибрати намальоване</button>' : ''}</div>
    <details style="margin:6px 0" ${CF_RES.some(([k]) => cols.some((c) => c.s.res[k])) ? 'open' : ''}><summary>Ресурси</summary><div style="overflow-x:auto"><table>${CF_RES.map(([k, n]) => `<tr><td>${n}</td>${cols.map((c) => `<td>${num('cf_r_' + c.k + '_' + k, c.s.res[k], !c.can)}</td>`).join('')}</tr>`).join('')}</table></div></details>
    <label for="cf_sub">Підпорядкування</label><select id="cf_sub" ${R.has('sub') ? '' : 'disabled'}>${subOpts.map(([v, n]) => `<option value="${v}" ${v === curSub ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select>
    <div style="margin:8px 0"><b>Поточні умови:</b> ${esc(cf.summary)}</div>${accTxt}<div class="err" id="cferr"></div>
    ${open ? `<div class="row" style="flex-wrap:wrap">${ed ? `<button class="ghost" id="cfsend">${extraCap ? 'Надіслати мої вимоги' : 'Запропонувати ці умови'}</button>` : ''}${cap ? (host ? '<button id="cfsign">Підписати й завершити</button><button class="danger" id="cfleave">Відхилити капітуляцію</button>' : extraCap ? '<button id="cfacc">Мої вимоги остаточні</button><button class="danger" id="cfleave">Покинути конференцію</button>' : '<button class="danger" id="cfleave">Відкликати капітуляцію</button>') : '<button id="cfacc">Прийняти поточні умови</button><button class="danger" id="cfleave">Покинути конференцію</button>'}</div>` : ''}
    ${open && cf.invitable && cf.invitable.length ? `<div class="row" style="margin-top:8px"><select id="cfinv" class="grow">${cf.invitable.map((x) => `<option value="${x.id}">${esc(x.name)}</option>`).join('')}</select><button class="ghost" id="cfinvb">Запросити учасника війни</button></div><div class="hint">Можна запросити державу, яка воює з вашим супротивником: вона отримає свій стовпчик вимог, а її війна завершиться разом з угодою.</div>` : ''}</div>
  <div><div class="chat" id="cfchat" style="height:300px"></div><div class="row" style="margin-top:8px"><input id="cft" class="grow" maxlength="500" placeholder="Повідомлення..."><button id="cfs">Надіслати</button></div></div></div></div>`;
  renderConfChat(d); const ch = $('#cfchat'); if (ch) ch.scrollTop = ch.scrollHeight;
  const collect = () => { const g = (id) => +($('#' + id) || {}).value || 0, side = (c) => ({ cells: g('cf_c_' + c.k), list: c.s.list, money: g('cf_m_' + c.k), res: Object.fromEntries(CF_RES.map(([k]) => [k, g('cf_r_' + c.k + '_' + k)]).filter(([, v]) => v > 0)) }), sv = $('#cf_sub').value, [who, kind, master] = sv ? sv.split(':') : [];
    return { toA: side(cols[0]), toB: side(cols[1]), ext: Object.fromEntries(cols.slice(2).map((c) => [c.cid, side(c)])), sub: sv ? { who: +who, kind, master: +master } : null }; };
  document.querySelectorAll('#cfform input,#cfform select').forEach((i) => i.addEventListener('input', () => { confDirty = true; })); const $s = $('#cf_sub'); if ($s) $s.onchange = () => { confDirty = true; };
  const err = (e) => { $('#cferr').textContent = e.message; }, go = async (fn) => { try { await fn(); confDirty = false; confKey = ''; await confRefresh(true); } catch (e) { err(e); } };
  const cm = $('#cfmap'); if (cm) cm.onclick = () => startConfDraw(cf.id, !(ed && open));
  const cmc = $('#cfmapclr'); if (cmc) cmc.onclick = () => go(async () => { const t2 = collect(); for (const s of [t2.toA, t2.toB, ...Object.values(t2.ext)]) delete s.list; await api('conf/terms', { id: cf.id, terms: t2 }); });
  const bs = $('#cfsend'); if (bs) bs.onclick = () => go(async () => { await api('conf/terms', { id: cf.id, terms: collect() }); });
  const ba = $('#cfacc'); if (ba) ba.onclick = () => go(async () => { if (confDirty && ed) await api('conf/terms', { id: cf.id, terms: collect() }); const r = await api('conf/accept', { id: cf.id }); if (r.done) { toast('Мир підписано'); refreshMe(); } });
  const sg = $('#cfsign'); if (sg) sg.onclick = () => { if (!confirm('Підписати ці умови й завершити війну?')) return; go(async () => { if (confDirty) await api('conf/terms', { id: cf.id, terms: collect() }); const r = await api('conf/accept', { id: cf.id }); if (r.done) { toast('Угоду підписано'); refreshMe(); } }); };
  const lv = $('#cfleave'); if (lv) lv.onclick = () => { if (confirm('Вийти з конференції? Війна триватиме.')) go(async () => { await api('conf/leave', { id: cf.id }); refreshMe(); }); };
  const iv = $('#cfinvb'); if (iv) iv.onclick = () => go(async () => { await api('conf/invite', { id: cf.id, cid: +$('#cfinv').value }); toast('Учасника запрошено'); });
  const send = () => { const t = $('#cft').value.trim(); if (!t) return; api('conf/say', { id: cf.id, text: t }).then(() => { $('#cft').value = ''; confRefresh(); }).catch((e) => toast(e.message, true)); };
  $('#cfs').onclick = send; $('#cft').onkeydown = (e) => { if (e.key === 'Enter') send(); };
}
// нова конференція з’являється вікном
async function pollConfs() {
  if (!me || !me.country) return; let list; try { list = (await api('conf/list')).confs.filter((x) => x.status === 'open'); } catch { return; }
  const ids = new Set(list.map((x) => x.id)); if (confSeen === null) { confSeen = ids; return; }
  for (const x of list) if (!confSeen.has(x.id)) { confSeen.add(x.id); if ($('#modal').classList.contains('hidden') && !evOpen) { openConfWin(x.id); break; } }
}

// ---- панель «Ми у війні» під меню: лише коли гравець воює ----
let warBoxT = 0, warBoxBusy = false;
async function updateWarBox() {
  const box = $('#warbox'); if (!box) return; if (!me || !me.country) return box.classList.add('hidden');
  if (warBoxBusy || Date.now() - warBoxT < 6000) return; warBoxBusy = true; warBoxT = Date.now();
  try {
    const d = await api('war/overview'); if (!d.wars.length) { box.classList.add('hidden'); return; }
    const hd = document.querySelector('header'); box.style.top = (hd ? hd.offsetHeight + 6 : 60) + 'px';
    let mini = false; try { mini = localStorage.warMin === '1'; } catch {}
    box.classList.toggle('mini', mini);
    if (mini) { const w0 = d.wars[0]; box.innerHTML = `<div class="wbh"><b>⚔ Війна${d.wars.length > 1 ? ' ×' + d.wars.length : ''}</b>${w0.cap != null ? ` <span>${w0.cap}%</span>` : ''}<a href="#" id="wbmin" title="Розгорнути">▢</a></div>`; box.classList.remove('hidden'); $('#wbmin').onclick = (e) => { e.preventDefault(); try { localStorage.warMin = '0'; } catch {} warBoxT = 0; updateWarBox(); }; return; }
    box.innerHTML = `<div class="wbh"><b>Ми у війні</b><span><a href="#" id="wbmin" title="Згорнути">—</a> <a href="#" id="wbmore" title="Докладніше">⤢</a></span></div>` + d.wars.map((w) => `<div class="wbw"><b>${esc(w.enemy.name)}</b> <span class="muted">${w.days} д.</span>
      <div>Втрати: <span class="neg">${exact(w.ourLoss)}</span> / ${exact(w.enemyLoss)}</div><div>Армія ворога ≈ ${exact(w.enemyArmy)}</div>
      ${w.cap == null ? '<div class="muted">Капітуляція: ?</div>' : `<div>До капітуляції: <b>${w.cap}%</b></div><div class="bar"><i style="width:${Math.min(100, w.cap)}%"></i></div>`}</div>`).join('');
    box.classList.remove('hidden'); $('#wbmin').onclick = (e) => { e.preventDefault(); try { localStorage.warMin = '1'; } catch {} warBoxT = 0; updateWarBox(); }; $('#wbmore').onclick = (e) => { e.preventDefault(); openWarWin(); };
  } catch { /* наступного разу */ } finally { warBoxBusy = false; }
}

// ---- вікно «Ми у війні» ----
async function openWarWin() {
  const d = await api('war/overview').catch((e) => { toast(e.message); return null; }); if (!d) return;
  if (!d.wars.length) return openModal('<h3>Ми у війні</h3><p>Ваша держава зараз не воює.</p><button class="ghost" id="wx">Закрити</button>'), $('#wx').onclick = closeModal;
  const bar = (v) => `<div class="bar ${v >= 80 ? 'g' : ''}" style="margin:4px 0"><i style="width:${Math.min(100, v)}%"></i></div>`;
  openModal(`<h3>Ми у війні</h3>${d.wars.map((w) => `<div class="card pad" style="margin:8px 0"><h4 style="margin:0 0 6px">Проти: ${esc(w.enemy.name)} <span class="muted">· ${w.days} діб</span>${w.confOpen ? ' <span class="badge">триває конференція</span>' : ''}</h4>
    <table><tr><th></th><th class="r">Ми</th><th class="r">Ворог</th></tr>
    <tr><td>Втрати (о/с)</td><td class="r neg">${exact(w.ourLoss)}</td><td class="r">${exact(w.enemyLoss)}</td></tr>
    <tr><td>Армія (орієнтовно)</td><td class="r">${exact(w.ourArmy)}</td><td class="r">≈ ${exact(w.enemyArmy)}</td></tr>
    <tr><td>Окуповано клітинок</td><td class="r">${exact(w.occupiedTheirs)} <span class="muted">(ворожих)</span></td><td class="r">${exact(w.occupiedOurs)} <span class="muted">(наших)</span></td></tr></table>
    ${w.cap == null ? '<div class="muted">До капітуляції: невідомо.</div>' : `<div style="margin-top:6px">До капітуляції ворога: <b>${w.cap}%</b> ${w.cap >= 100 ? (w.capBot ? '(готовий капітулювати)' : '(гравець вирішує сам)') : ''}</div>${bar(w.cap)}<div class="muted" style="font-size:13px">Захоплено міст: ${w.citiesTaken || 0}${w.capitalTaken ? ' · <b class="pos">столицю взято (+25%)</b>' : ''}. Рахуються окупована земля, перевага в силі й захоплені міста (столиця — найбільше).</div>`}</div>`).join('')}<button class="ghost" id="wx">Закрити</button>`);
  $('#wx').onclick = closeModal;
}

// ---- вхід на чужу територію ----
let incurOpen = false;
async function pollIncur() {
  if (incurOpen && $('#modal').classList.contains('hidden')) incurOpen = false;
  if (incurOpen || evOpen || !me || !me.country) return; const d = await api('incursions').catch(() => ({ items: [] })); const it = d.items[0]; if (!it) return; incurOpen = true;
  openModal(`<h3>Ваші підрозділи зайшли на чужу територію</h3><p>Підрозділ «${esc(it.unit)}» перебуває на землі держави <b>${esc(it.ownerName)}</b> без дозволу.</p>
    <div class="row" style="gap:8px"><button class="neg" data-ic="war">Оголосити війну</button><button class="ghost" data-ic="ignore">Ігнорувати</button><button class="ghost" data-ic="retreat">Відступити на свою територію</button></div>
    <p class="hint">Ігнорування псує відносини; невиправдана війна б’є по репутації.</p>`);
  $('#modal').querySelectorAll('[data-ic]').forEach((b) => b.onclick = async () => { try { const r = await api('incursions/resolve', { id: it.id, choice: b.dataset.ic }); toast(r.message); } catch (e) { toast(e.message, true); } closeModal(); incurOpen = false; await refreshMe(); });
}
