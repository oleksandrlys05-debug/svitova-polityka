// Оновлення 19.2: інструменти адміна на мапі (родовища, столиці, нахили) і вибір нахилу при заснуванні держави
const RESN19 = { oil: 'Нафта', aluminium: 'Алюміній (боксити)', chromium: 'Хром', tungsten: 'Вольфрам', rubber: 'Каучук', steel: 'Залізна руда (сталь)', cotton: 'Бавовна' };
window.admTool = window.admTool || { res: 'oil', r: 16, k: 1.2, cid: 0 };
async function admTools(box) { const D = await api('admin/tools'); const T = admTool; if (!T.cid && D.countries[0]) T.cid = D.countries[0].id;
  const el = document.createElement('div'); el.className = 'card pad';
  el.innerHTML = `<h3 style="margin-top:0">${ico('res', 24)} Інструменти мапи</h3>
    <h4 style="margin:6px 0 4px">Родовища ресурсів</h4><div class="row" style="gap:6px;flex-wrap:wrap;align-items:center"><select id="atr" style="width:auto">${D.res.map((k) => `<option value="${k}" ${k === T.res ? 'selected' : ''}>${esc(RESN19[k] || k)}</option>`).join('')}</select>
      Радіус <input id="atrr" type="number" min="4" max="80" value="${T.r}" style="width:70px"> кл. · багатство <input id="atrk" type="number" min="0.3" max="3" step="0.1" value="${T.k}" style="width:70px"> (1 — звичайне)
      <button class="sm" id="atadd">Додати кліком на мапі</button><button class="ghost sm" id="atdel">Видалити кліком на мапі</button></div>
    <p class="hint" style="margin:4px 0 0">Після натискання відкриється мапа з шаром «Ресурси». Кожен клік додає (або видаляє) одне родовище; «Скасувати» на банері — завершити.</p>
    <h4 style="margin:12px 0 4px">Держава</h4><div class="row" style="gap:6px;flex-wrap:wrap;align-items:center"><select id="atc" style="width:auto">${D.countries.map((c) => `<option value="${c.id}" ${c.id === T.cid ? 'selected' : ''}>${esc(c.name)}${c.bot ? ' (бот)' : ''}</option>`).join('')}</select>
      Школа озброєння <select id="ats" style="width:auto">${Object.entries(D.slants).map(([k, n]) => `<option value="${k}">${esc(n)}</option>`).join('')}</select><button class="sm" id="atsgo">Змінити нахил</button>
      <button class="ghost sm" id="atcap">Перенести столицю кліком на мапі</button></div>
    <h4 style="margin:12px 0 4px">Додати підрозділ вибраній державі</h4><div class="row" style="gap:6px;flex-wrap:wrap;align-items:center"><select id="aut" style="width:auto">${Object.entries(D.types).map(([k, t]) => `<option value="${k}">${esc(t.n)}</option>`).join('')}</select>
      Людей <input id="aus" type="number" min="10" max="100000" value="2400" style="width:90px"> Назва <input id="aun" placeholder="(за замовчуванням)" style="width:180px"> Навчання <input id="aul" type="number" min="0" max="100" value="60" style="width:60px">%
      <label class="chk" style="margin:0"><input type="checkbox" id="auf" checked style="width:auto"> з повним оснащенням (зброя, техніка, спорядження, боєприпаси — безкоштовно)</label><button class="sm" id="augo">Поставити кліком на мапі</button></div>
    <h4 style="margin:12px 0 4px">Видати (або забрати) озброєння, спорядження, боєприпаси</h4><div class="row" style="gap:6px;flex-wrap:wrap;align-items:center"><select id="aei" style="width:auto;max-width:300px">${Object.entries(D.items).map(([k, e]) => `<option value="${k}">${esc(e.n)}${e.cat === 'ammo' ? ' (боєприпаси)' : e.cat === 'gear' ? ' (спорядження)' : ''}</option>`).join('')}</select>
      <select id="aem" style="width:auto;max-width:300px"></select><select id="aesl" style="width:auto">${Object.entries(D.slants).map(([k, n]) => `<option value="${k}">${esc(n)}</option>`).join('')}</select>
      Кількість <input id="aen" type="number" value="1000" style="width:100px"> <button class="sm" id="aego">Видати</button><span class="muted" style="font-size:12.5px">мінус — забрати</span></div>
    <h4 style="margin:12px 0 4px">Побудувати об’єкт вибраній державі (одразу, у вибраній точці)</h4><div class="row" style="gap:6px;flex-wrap:wrap;align-items:center"><select id="abk" style="width:auto">${Object.entries(D.fac).map(([k, n]) => `<option value="${k}">${esc(n)}</option>`).join('')}</select>
      Рівень <input id="abl" type="number" min="1" max="5" value="1" style="width:60px"> Назва міста <input id="abn" placeholder="(для міста)" style="width:150px">
      <label class="chk" style="margin:0"><input type="checkbox" id="abf" style="width:auto"> ігнорувати обмеження (родовище, узбережжя, відстань)</label><button class="sm" id="abgo">Обрати точку на мапі</button></div>`;
  box.prepend(el);
  const cs = () => D.countries.find((c) => c.id === +el.querySelector('#atc').value) || {}; const syncS = () => { el.querySelector('#ats').value = cs().slant || 'us'; }; syncS();
  el.querySelector('#atc').onchange = () => { T.cid = +el.querySelector('#atc').value; syncS(); };
  const rd = () => { T.res = el.querySelector('#atr').value; T.r = +el.querySelector('#atrr').value || 16; T.k = +el.querySelector('#atrk').value || 1.2; };
  el.querySelector('#atadd').onclick = () => { rd(); showTab('map'); setLayer('resources'); setMode({ kind: 'admdep', add: true }); };
  el.querySelector('#atdel').onclick = () => { rd(); showTab('map'); setLayer('resources'); setMode({ kind: 'admdep', add: false }); };
  el.querySelector('#atsgo').onclick = () => act(async () => { await api('admin/slant', { cid: +el.querySelector('#atc').value, slant: el.querySelector('#ats').value }); toast('Нахил змінено'); renderAdmin(); });
  const syncSl = () => { const c = cs(); el.querySelector('#aesl').value = c.slant || 'us'; }; syncSl(); el.querySelector('#atc').addEventListener('change', syncSl);
  const loadM = async () => { const it = el.querySelector('#aei').value, sel = el.querySelector('#aem'), sl = el.querySelector('#aesl').value; if (!D.items[it].models) { sel.innerHTML = '<option value="">—</option>'; sel.disabled = true; return; } sel.disabled = false; const r = await api('admin/models?item=' + it); sel.innerHTML = r.models.map((m) => `<option value="${m.id}">${esc((m.names && (m.names[sl] || Object.values(m.names)[0])) || m.id)}${m.era ? ` · епоха ${m.era}` : ''}</option>`).join('') || '<option value="">—</option>'; };
  el.querySelector('#aei').onchange = loadM; el.querySelector('#aesl').onchange = loadM; loadM();
  el.querySelector('#aego').onclick = () => act(async () => { const r = await api('admin/equip', { cid: +el.querySelector('#atc').value, item: el.querySelector('#aei').value, model: el.querySelector('#aem').value || undefined, slant: el.querySelector('#aesl').value, n: +el.querySelector('#aen').value }); toast(`Готово: ${r.name}, на складі тепер ${r.stock.toLocaleString('uk-UA')}`); });
  el.querySelector('#augo').onclick = () => { T.cid = +el.querySelector('#atc').value; T.unit = { type: el.querySelector('#aut').value, size: +el.querySelector('#aus').value, name: el.querySelector('#aun').value, train: +el.querySelector('#aul').value, full: el.querySelector('#auf').checked }; showTab('map'); setMode({ kind: 'admunit', cid: T.cid }); };
  el.querySelector('#abgo').onclick = () => { T.cid = +el.querySelector('#atc').value; T.build = { kind: el.querySelector('#abk').value, level: +el.querySelector('#abl').value, name: el.querySelector('#abn').value, force: el.querySelector('#abf').checked, n: el.querySelector('#abk').selectedOptions[0].textContent }; showTab('map'); setMode({ kind: 'admbuild', cid: T.cid }); };
  el.querySelector('#atcap').onclick = () => { T.cid = +el.querySelector('#atc').value; showTab('map'); setLayer('owners'); setMode({ kind: 'admcap', cid: T.cid }); }; }
{ const o = window.aWorld; if (typeof o === 'function') window.aWorld = async function (b) { await o(b); try { await admTools(b); } catch (e) { console.error('admin19', e); } }; }
// банер режимів
window.admBanner = (m, b) => { if (m.kind === 'admdep') { b.innerHTML = `<span>${m.add ? `Клікни на мапі, де додати родовище: <b>${esc(RESN19[admTool.res] || admTool.res)}</b>, радіус ${admTool.r}, багатство ${admTool.k}` : 'Клікни по родовищу, яке видалити'}</span><button id="bcancel">Готово</button>`; b.classList.remove('hidden'); return true; }
  if (m.kind === 'admunit') { b.innerHTML = `<span>Клікни на мапі, де поставити підрозділ для <b>${esc((countries[m.cid] || {}).name || '')}</b> (можна кілька разів)</span><button id="bcancel">Готово</button>`; b.classList.remove('hidden'); return true; }
  if (m.kind === 'admbuild') { b.innerHTML = `<span>Клікни, де збудувати <b>${esc(admTool.build.n)}</b> для <b>${esc((countries[m.cid] || {}).name || '')}</b> (можна кілька разів)</span><button id="bcancel">Готово</button>`; b.classList.remove('hidden'); return true; }
  if (m.kind === 'admcap') { b.innerHTML = `<span>Клікни по місту (або території) держави <b>${esc((countries[m.cid] || {}).name || '')}</b>, щоб зробити його столицею</span><button id="bcancel">Скасувати</button>`; b.classList.remove('hidden'); return true; } return false; };
window.mapClick19 = async (e, c) => {
  if (mode.kind === 'admdep') { await act(async () => { if (mode.add) await api('admin/deposit', { res: admTool.res, x: c.x, y: c.y, r: admTool.r, k: admTool.k }); else { const r = await api('admin/deposit/del', { x: c.x, y: c.y }); toast(`Видалено: ${RESN19[r.res] || r.res}`); } deposits = null; await setLayer('resources'); }); return true; }
  if (mode.kind === 'admunit') { const cid = mode.cid; await act(async () => { await api('admin/unit/add', { cid, x: c.x, y: c.y, ...admTool.unit }); toast('Підрозділ додано'); if (window.loadUnits) await loadUnits(); }); return true; }
  if (mode.kind === 'admbuild') { const cid = mode.cid; await act(async () => { const r = await api('admin/build', { cid, x: c.x, y: c.y, ...admTool.build }); toast(`Збудовано: ${r.n}`); if (window.loadFacs) await loadFacs(); await loadMap(); }); return true; }
  if (mode.kind === 'admcap') { const cid = mode.cid; await act(async () => { const r = await api('admin/capital', { cid, x: c.x, y: c.y }); toast(r.city ? `Столиця тепер у місті ${r.city}` : 'Столицю перенесено'); setMode({ kind: 'idle' }); await loadMap(); }); return true; }
  return false; };

// ---------- видалення гравця (Адмін → Країни та гравці) ----------
{ const o = window.aCountries; if (typeof o === 'function') window.aCountries = async function (b) { await o(b); try {
  b.querySelectorAll('[data-ban]').forEach((x) => { const id = +x.dataset.ban.split(':')[0]; if (me && me.user && id === me.user.id) return; const btn = document.createElement('button'); btn.className = 'danger sm'; btn.textContent = 'Видалити'; btn.style.marginLeft = '4px';
    btn.onclick = () => { const row = x.closest('tr'), nick = row ? row.cells[0].textContent.replace('заблоковано', '').trim() : '', hasC = row && row.cells[3] && row.cells[3].textContent.trim() !== '—';
      const pop = document.createElement('div'); pop.className = 'tpick card pad';
      pop.innerHTML = `<h3 style="margin-top:0">Видалити гравця «${esc(nick)}»?</h3><p class="hint" style="margin-top:0">Акаунт, вхід і сповіщення гравця буде видалено назавжди. Зробіть резервну копію, якщо сумніваєтеся.</p>
        ${hasC ? `<label>Що зробити з його державою «${esc(row.cells[3].textContent.trim())}»?</label><select id="udc"><option value="bot">Віддати боту (держава лишається на мапі)</option><option value="keep">Лишити без власника (призначити іншому гравцю пізніше)</option><option value="delete">Видалити державу (територія стане вільною)</option></select>` : ''}
        <div class="row" style="gap:6px;margin-top:10px"><button class="danger" id="udgo">Видалити</button><button class="ghost" id="udx">Скасувати</button></div>`;
      document.body.appendChild(pop); pop.querySelector('#udx').onclick = () => pop.remove();
      pop.querySelector('#udgo').onclick = () => act(async () => { const r = await api('admin/user/delete', { id, country: hasC ? pop.querySelector('#udc').value : 'keep' }); pop.remove(); toast(r.message); await refreshMe(); renderAdmin(); }); };
    x.after(btn); });
} catch (e) { console.error('admin19 users', e); } }; }
