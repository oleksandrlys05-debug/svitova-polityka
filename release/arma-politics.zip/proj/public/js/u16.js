// Оновлення 16: перемикачі мапи, режими підрозділів, бої на мапі, конвої
window.mapShow = (() => { try { return { units: 'all', intel: true, convoys: true, ...JSON.parse(localStorage.mapShow || '{}') }; } catch { return { units: 'all', intel: true, convoys: true }; } })();
function setMapShow(k, v) { mapShow[k] = v; try { localStorage.mapShow = JSON.stringify(mapShow); } catch { /* ні */ } drawMap(); }
function mapShowHtml() {
  return `<div class="card pad mapshow"><b>Показ на мапі</b><div class="row" style="gap:6px;flex-wrap:wrap;margin-top:6px">
    <select onchange="setMapShow('units', this.value)" title="Підрозділи на мапі"><option value="all" ${mapShow.units === 'all' ? 'selected' : ''}>Підрозділи: усі</option><option value="mine" ${mapShow.units === 'mine' ? 'selected' : ''}>Лише мої</option><option value="none" ${mapShow.units === 'none' ? 'selected' : ''}>Сховати підрозділи</option></select>
    <label class="chk"><input type="checkbox" ${mapShow.intel ? 'checked' : ''} onchange="setMapShow('intel', this.checked)"> Розвіддані (кола)</label>
    <label class="chk"><input type="checkbox" ${mapShow.convoys ? 'checked' : ''} onchange="setMapShow('convoys', this.checked)"> Конвої</label></div></div>`;
}
const STANCES = [['attack', 'Наступ'], ['hold', 'Утримувати'], ['last', 'До останнього'], ['retreat', 'Відхід з боєм']];
function stanceHtml(list) {
  const cur = list.length === 1 ? list[0].stance || 'attack' : '';
  return `<div class="row" style="margin-top:6px;gap:6px;align-items:center"><span class="muted">Режим:</span><select onchange="setStance([${list.map((u) => u.id).join(',')}], this.value)" title="Наступ — звичайний; Утримувати — −20% атаки, але не лізе далі; До останнього — не відступає, поки є люди; Відхід з боєм — відходить, щойно падає організація">${cur ? '' : '<option value="">—</option>'}${STANCES.map(([k, n]) => `<option value="${k}" ${cur === k ? 'selected' : ''}>${n}</option>`).join('')}</select></div>`;
}
async function setStance(ids, v) { if (!v) return; try { const r = await api('units/stance', { ids, stance: v }); for (const u of myUnits) if (ids.includes(u.id)) u.stance = v; toast('Режим: ' + r.stance); } catch (e) { toast(e.message, true); } }
function centerOn(x, y) { showTab('map'); const r = cv.getBoundingClientRect(); view.s = Math.max(view.s, view.fs * 3); view.x = r.width / 2 - (x + .5) * land.cell * view.s; view.y = r.height / 2 - (y + .5) * land.cell * view.s; drawMap(); }
// ---- бої на мапі ----
let battlesMap = [];
async function loadBattlesMap() { if (!me || !me.country) return; try { battlesMap = (await api('battles/map')).battles; } catch { battlesMap = []; } if (tab === 'map') drawMap(); }
setInterval(() => { if (!document.hidden && tab === 'map') loadBattlesMap(); }, 5000);
function drawBattles(C) {
  for (const b of battlesMap) { const x = (b.x + .5) * C, y = (b.y + .5) * C, s = Math.max(10, Math.min(18, 8 + view.s / view.fs * 2)) / view.s;
    cx.save(); cx.fillStyle = b.mine ? 'rgba(220,38,38,.9)' : 'rgba(80,80,90,.85)'; cx.beginPath(); cx.arc(x, y, s, 0, 7); cx.fill(); cx.strokeStyle = '#fff'; cx.lineWidth = 1.5 / view.s; cx.stroke();
    cx.fillStyle = '#fff'; cx.font = `700 ${s * 1.1}px sans-serif`; cx.textAlign = 'center'; cx.fillText('⚔', x, y + s * 0.38);
    // смужки організації: зліва атакуючий, справа оборонець
    const w = s * 3, h = s * 0.35, bx = x - w / 2, by = y + s * 1.25, ac = (countries[b.a] || {}).color || '#c33', dc = (countries[b.d] || {}).color || '#33c';
    cx.fillStyle = 'rgba(0,0,0,.6)'; cx.fillRect(bx, by, w, h * 2 + 1 / view.s); cx.fillStyle = ac; cx.fillRect(bx, by, w * (b.aOrg || 0) / 100, h); cx.fillStyle = dc; cx.fillRect(bx, by + h + 1 / view.s, w * (b.dOrg || 0) / 100, h); cx.restore(); }
}
// ---- угоди від ботів у чаті: прийняти, відхилити, торгуватися ----
const DRN = { oil: 'нафта', fuel: 'паливо', steel: 'сталь', food: 'їжа', medicine: 'ліки', goods: 'товари', clothing: 'одяг', aluminium: 'алюміній', rubber: 'гума', cotton: 'бавовна', chromium: 'хром', tungsten: 'вольфрам' };
function dealCard(d) {
  const t = d.terms, st = d.status === 'done' ? '<b class="pos">Угоду укладено</b>' : d.status === 'rejected' ? '<span class="muted">Відхилено</span>' : d.status === 'broken' ? '<b class="neg">Угоду порушено</b>' : !d.open ? '<span class="muted">Пропозиція застаріла</span>' : '';
  const f = (k, v, lbl, suf) => `<label style="display:flex;gap:6px;align-items:center;font-size:13px">${lbl}<input type="number" min="0" data-dk="${k}" value="${v}" style="width:${suf === '$' ? 130 : 64}px">${suf}</label>`;
  const form = d.kind21 ? (d.noHaggle ? '' : f('price', t.price || 0, d.priceLabel || 'Ціна', '$')) : d.kind === 'customs' ? f('transit', t.transit, 'Транзит', '%') + f('tariff', t.tariff, 'Мито', '%') + f('days', t.days, 'Діб', '') + f('pay', t.pay, 'Виплата', '$') : f('n', t.n, (DRN[t.res] || t.res) + ', од.', '') + f('price', t.price, 'Ціна', '$');
  return `<div class="dealc" data-deal="${d.id}"><b>Пропозиція:</b> ${esc(d.text)}${st ? `<div>${st}</div>` : d.mine ? `<div class="row" style="gap:6px;margin-top:6px;flex-wrap:wrap"><button class="sm" data-da="accept">Прийняти</button><button class="ghost sm" data-da="reject">Відхилити</button>${d.noHaggle ? '' : d.round < 3 ? '<button class="ghost sm" data-da="haggle">Торгуватися</button>' : '<span class="muted">остаточна пропозиція</span>'}</div><div class="dealf hidden" style="display:grid;gap:4px;margin-top:6px">${form}<button class="sm" data-da="counter">Запропонувати свої умови</button></div>` : ''}</div>`;
}
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-da]'); if (!b) return; const card = b.closest('[data-deal]'), id = +card.dataset.deal, act0 = b.dataset.da;
  if (act0 === 'haggle') { card.querySelector('.dealf').classList.toggle('hidden'); return; }
  const terms = {}; card.querySelectorAll('[data-dk]').forEach((x) => { terms[x.dataset.dk] = +x.value; });
  act(async () => { const r = await api('deal/answer', { id, act: act0, terms }); toast(r.msg); if (window.cwRender && cw && cw.tab) cwRender(); else if (window.renderDiplo) renderDiplo(); });
});
async function warDepsOk(sel) {
  try { const d = await api('war/dependents?target=' + sel.id); if (!d.list.length) return true;
    return confirm(`Від держави «${sel.name}» залежать:\n${d.list.map((x) => `• ${x.name} — ${x.share}% імпорту (${x.res.join(', ') || 'товари'})`).join('\n')}\n\nВони можуть ввести санкції, ембарго або навіть оголосити вам війну. Продовжити?`); } catch { return true; }
}
// ---- вибори: чому влада втрачає голоси, фальсифікації ----
function elect16Html(D) {
  const w = (D.why || []).length ? `<div class="card pad" style="margin-top:8px"><h4 style="margin:0 0 6px">Що забирає голоси влади</h4>${D.why.map((x) => `<div class="row"><span class="grow">${esc(x.t)}</span><b class="neg">−${nf(x.v, 1)}%</b></div>`).join('')}<p class="hint" style="margin:6px 0 0">Опитування можуть помилятися на ±5%. Якщо ніхто не набере 50%, буде другий тур: опозиція об’єднається.</p></div>` : '';
  const f = D.fraud && D.e ? `<div class="card pad" style="margin-top:8px"><h4 style="margin:0 0 6px">Фальсифікації</h4>${D.fraud.levels.map((l) => `<div class="row" style="margin:3px 0"><span class="grow">${esc(l.n)} <span class="muted">+${l.add}% · ризик викриття ≈${l.risk}% · ${short(l.cost)} $</span></span><button class="ghost sm neg" data-fraud="${l.k}" ${D.fraud.cur >= l.k ? 'disabled' : ''}>${D.fraud.cur >= l.k ? 'запущено' : 'Запустити'}</button></div>`).join('')}<p class="hint" style="margin:6px 0 0">Ризик вищий за вільних ЗМІ, сильної опозиції й чужих шпигунів. Викриття: протести й бунти в містах, санкції, а за низької стабільності — переворот.</p></div>` : '';
  return w + f;
}

// ---------- Мобілізація як у HoI4: призов 0–25% ----------
const MOBFX = (p) => ({ prod: Math.max(0, p - 2) * 1.2, build: Math.max(0, p - 2) * 1.0, grow: p * 0.08, research: p * 0.4, work: p * 1.2, unemp: p * 0.3 });
const mobName = (L, p) => { let n = L[0][1]; for (const [k, t] of L) if (p >= k) n = t; return n; };
function mobHtml16(M, mp) {
  return `<div style="margin-top:6px"><div class="row" style="gap:12px;align-items:center;flex-wrap:wrap"><label for="mpr" style="margin:0;min-width:250px">Призов: <b id="mpv">${M.pct}</b>% населення — <b id="mpn">${esc(M.name)}</b></label>
    <input id="mpr" type="range" min="0" max="25" step="1" value="${M.pct}" style="flex:1;min-width:220px;max-width:460px"><button class="sm" id="mpok">Застосувати</button></div>
    <div class="muted" style="font-size:13px">Зараз діє: <b>${M.cur}%</b> (${esc(M.curName)})${M.cur !== M.pct ? ` → змінюється на 1 пункт за добу до ${M.pct}%` : ''}. ${M.war ? `Ви у війні: суспільство терпить призов до ≈${Math.round(8 + M.warSupport / 5)}% (залежить від підтримки війни).` : 'Мирний час: призов понад 8% викликає мітинги.'}</div>
    <div id="mpfx" class="mobfx"></div>
    <p class="hint">Людські ресурси — це частка населення, яку держава може забрати в армію. 0% — нових людей немає зовсім. Кожен відсоток призову забирає людей із заводів, шахт, будов, лабораторій і міських служб.</p></div>`;
}
function bindMob16(M) {
  const r = $('#mpr'); if (!r) return; const tol = M.war ? 8 + M.warSupport / 5 : 8;
  const show = () => { const p = +r.value, f = MOBFX(p), pool = Math.round(M.pop * p / 100); $('#mpv').textContent = p; $('#mpn').textContent = mobName(M.levels, p);
    const it = (t, v, bad) => `<div class="${bad ? 'neg' : ''}">${t}: <b>${v}</b></div>`;
    $('#mpfx').innerHTML = `<div class="grid g3" style="gap:4px 18px;font-size:13.5px;margin:8px 0">${it('Людські ресурси', exact(pool))}${it('Видобуток і заводи', p > 2 ? '−' + f.prod.toFixed(1) + '%' : 'без втрат', p > 2)}${it('Виробництво зброї', p > 2 ? '−' + f.prod.toFixed(1) + '%' : 'без втрат', p > 2)}
      ${it('Будівництво', p > 2 ? '−' + f.build.toFixed(1) + '%' : 'без втрат', p > 2)}${it('Ріст ВВП', '−' + f.grow.toFixed(1) + ' п./рік', p > 0)}${it('Наука', '−' + f.research.toFixed(1) + '%', p > 0)}
      ${it('Робоча сила міст', '−' + f.work.toFixed(0) + '%', p > 4)}${it('Безробіття', '−' + f.unemp.toFixed(1) + ' п.')}${it('Стабільність', p > tol ? '−' + ((p - tol) * 1.2).toFixed(1) + ' (мітинги)' : 'спокійно', p > tol)}</div>`; };
  r.oninput = show; show();
  $('#mpok').onclick = () => { const p = +r.value; if (p > tol + 4 && !confirm(`Призов ${p}% вищий, ніж готове терпіти суспільство: будуть мітинги, стабільність і підтримка влади впадуть. Продовжити?`)) return; act(async () => { const x = await api('army/mob', { pct: p }); toast(x.message); await refreshMe(); renderMe(); }); };
}

// ---------- Конкретні моделі озброєння на заводах ----------
function lineModelHtml(E, l) {
  const ms = (E.models && E.models[l.item]) || []; if (!ms.length && !l.modelName) return '';
  const sel = ms.length > 1 || (ms.length && !ms.some((m) => m.id === l.model)) ? `<select data-lmod="${l.id}" style="width:auto;font-size:12px;padding:2px 6px;margin-left:6px">${ms.map((m) => `<option value="${m.id}" ${m.id === l.model ? 'selected' : ''}>${esc(m.name)} — епоха ${m.era}, сила ${m.q}%, ціна ×${(m.cm / 100).toFixed(2)}</option>`).join('')}${l.model ? '' : '<option selected>Старі зразки</option>'}</select>` : '';
  return `<div style="font-size:13px;margin-top:2px">Модель: <b>${esc(l.modelName || '—')}</b> <span class="muted">(сила ${l.q}%)</span>${sel}${l.retoolLeft ? ` <span class="badge neg" title="Після зміни моделі завод працює вдвічі повільніше">переналагодження ${l.retoolLeft} д.</span>` : ''}${l.better ? ` <span class="badge" style="border-color:#22c55e" title="Перемкніть лінію на новішу модель">є новіша: ${esc(l.better.name)}</span>` : ''}</div>`;
}
function stockModelsHtml(E, k) {
  const sm = (E.stockModels && E.stockModels[k]) || [], fq = E.fielded && E.fielded[k];
  if (!sm.length && !fq) return ''; return `<tr><td colspan="2" style="padding:0 0 6px 30px;font-size:12.5px" class="muted">${sm.map((m) => `${esc(m.name)}${m.foreign ? ' <span class="badge">імпорт/трофей</span>' : ''}: <b>${exact(m.n)}</b> (сила ${m.q}%)`).join(' · ')}${fq ? `${sm.length ? ' · ' : ''}у війську середня сила озброєння <b>${fq}%</b>` : ''}</td></tr>`;
}
function bindLineModels(b, E) {
  b.querySelectorAll('[data-lmod]').forEach((x) => x.onchange = () => { if (!confirm('Переналагодити завод на іншу модель? 4 доби випуск буде вдвічі меншим, прогрес поточної одиниці втрачається.')) { renderMe(); return; } act(async () => { const r = await api('econ/line/model', { id: +x.dataset.lmod, model: x.value }); toast(r.message); renderMe(); }); });
  b.querySelectorAll('[data-leq]').forEach((sel) => { const md = b.querySelector(`[data-lmd="${sel.dataset.leq}"]`); if (!md) return;
    const fill = () => { const ms = ((E.models || {})[sel.value] || []).filter((m) => !E.lines.some((l) => l.item === sel.value && l.model === m.id)); md.style.display = ms.length ? '' : 'none'; md.innerHTML = ms.map((m) => `<option value="${m.id}">${esc(m.name)} (${esc(m.kind)}) — епоха ${m.era}, сила ${m.q}%, ціна ×${(m.cm / 100).toFixed(2)}</option>`).join(''); };
    sel.addEventListener('change', fill); fill(); });
}
// озброєння підрозділу (точні моделі)
function eqListHtml(u) { if (!u.eqList || !u.eqList.length) return ''; return `<div style="font-size:12.5px;margin-top:3px"><span class="muted">Озброєння (сила ${u.eqQ || 100}%):</span> ${u.eqList.slice(0, 6).map((x) => `${exact(x.n)} × <b>${esc(x.name)}</b>`).join(' · ')}${u.eqList.length > 6 ? ' …' : ''}</div>`; }
// ---------- точні моделі в торгівлі й допомозі ----------
window.EQKN = window.EQKN || {}; window.EQKCM = window.EQKCM || {};
const eqRemember = (lists) => { for (const arr of Object.values(lists || {})) for (const x of arr) { EQKN[x.key] = x.name; EQKCM[x.key] = x.cm; } };
function eqKeyLabel(k) { if (EQKN[k]) return EQKN[k]; const it = String(k).split('|')[0]; return (typeof EQN !== 'undefined' && EQN[it]) || it; }
function eqKeyPrice(P, k) { const it = String(k).split('|')[0]; return (P.eq[it] || 0) * (EQKCM[k] || 1); }
function tradeEqRows(side, lists, P, B, mine, T) {
  eqRemember(T.myModels); eqRemember(T.theirModels); const L = lists || {}, items = Object.keys(L);
  if (!items.length) return `<p class="muted" style="margin:4px 0">${mine ? 'На вашому складі немає зброї.' : 'На їхньому складі немає зброї на продаж.'}</p>`;
  return items.map((it) => `<div class="muted" style="font-size:12px;margin-top:6px">${esc((typeof EQN !== 'undefined' && EQN[it]) || it)}</div>` + L[it].map((x) => `<div class="trow"><label>${esc(x.name)}${x.foreign ? ' <span class="badge" title="Іноземна модель">імпорт</span>' : ''} <span class="muted">· сила ${x.q}% · ${short(eqKeyPrice(P, x.key))} $ · ${mine ? 'маєш' : 'у них'} ${exact(x.n)}</span></label><input type="number" min="0" max="${x.n}" step="1" data-f="${side}.eq.${x.key}" value="${B.eq[x.key] || ''}" placeholder="0"></div>`).join('')).join('');
}
function tradeEqQuick(T) { eqRemember(T.myModels); eqRemember(T.theirModels); const seen = new Map(); for (const src of [T.theirModels || {}, T.myModels || {}]) for (const arr of Object.values(src)) for (const x of arr) if (!seen.has(x.key)) seen.set(x.key, x.name); return [...seen].map(([k, n]) => [k, n]); }
async function aidEquipPick(sel) {
  const d = await api('aid/info?to=' + sel.id); eqRemember(d.models); const L = d.models || {};
  openModal(`<h3 style="margin-top:0">Військова допомога: зброя для ${esc(sel.name)}</h3><p class="hint" style="margin-top:0">Оберіть точні моделі й кількість. Вантаж піде конвоєм.</p>
    <div style="max-height:55vh;overflow:auto">${Object.keys(L).map((it) => `<div class="muted" style="font-size:12px;margin-top:6px">${esc((d.eq[it] || {}).n || it)}</div>` + L[it].map((x) => `<div class="trow"><label>${esc(x.name)} <span class="muted">· сила ${x.q}% · є ${exact(x.n)}</span></label><input type="number" min="0" max="${x.n}" data-aq="${x.key}" placeholder="0"></div>`).join('')).join('') || '<p class="muted">На складі немає зброї.</p>'}</div>
    <div class="row" style="margin-top:8px"><button id="aqok">Надіслати</button><button class="ghost" id="aqx">Скасувати</button></div>`);
  $('#aqx').onclick = closeModal; $('#aqok').onclick = () => { const eq = {}; document.querySelectorAll('[data-aq]').forEach((i) => { const v = Math.floor(+i.value || 0); if (v > 0) eq[i.dataset.aq] = v; }); if (!Object.keys(eq).length) return toast('Вкажіть кількість хоча б однієї моделі', true);
    act(async () => { const r = await api('aid/send', { to: sel.id, kind: 'equip', eq }); closeModal(); toast(r.message); }); };
}

// ---------- «Чому?» для міста й протести ----------
async function cityWhyModal(id) {
  let d; try { d = await api('city/why?id=' + id); } catch (e) { return toast(e.message, true); }
  const neg = d.parts.filter((p) => p.v < 0), pos = d.parts.filter((p) => p.v > 0);
  const row = (p) => `<tr><td>${esc(p.t)}${p.fix ? `<div class="muted" style="font-size:12px">${esc(p.fix)}</div>` : ''}</td><td class="r"><b class="${p.v < 0 ? 'neg' : 'pos'}">${p.v > 0 ? '+' : ''}${nf(p.v, 1)}</b></td></tr>`;
  openModal(`<h3 style="margin-top:0">Чому такий настрій у місті ${esc(d.name || '')}?</h3><p class="muted" style="margin-top:0">База ${d.base} → ціль <b>${d.target}</b>. Настрій щодня рухається до цілі.</p>
    <div style="max-height:60vh;overflow:auto">${neg.length ? `<h4 style="margin:6px 0">Що псує настрій</h4><table>${neg.map(row).join('')}</table>` : ''}${pos.length ? `<h4 style="margin:10px 0 6px">Що покращує</h4><table>${pos.sort((a, b) => b.v - a.v).map(row).join('')}</table>` : ''}</div>
    <div class="row" style="margin-top:8px"><button class="ghost" id="cwx">Закрити</button></div>`);
  $('#cwx').onclick = closeModal;
}
function protestsHtml(PR) {
  if (!PR) return ''; const L = PR.list || []; if (!L.length && !(PR.recent || []).length) return '';
  const col = { rally: '#eab308', strike: '#f97316', riot: '#ef4444' };
  return `<div class="card pad" style="border-color:${L.length ? '#ef4444' : 'var(--line2)'}"><h3 style="margin-top:0">📣 Протести${L.length ? ` (${L.length})` : ''}</h3>
    ${L.map((p) => `<div class="card pad" style="margin:6px 0;border-left:4px solid ${col[p.stage]}"><div class="row" style="flex-wrap:wrap;gap:8px"><b class="grow">${esc(p.city || '')}: ${esc(p.stageN)} · ${exact(p.size)} осіб · ${p.days} д.</b>${p.esc ? `<span class="muted">${p.stage === 'riot' ? '' : `загострення через ${p.esc} д.`}</span>` : ''}</div>
      <div>Причина: <b>${esc(p.cause)}</b>${p.fix ? ` <span class="muted">— ${esc(p.fix)}</span>` : ''}</div>
      <div class="muted" style="font-size:12.5px">${p.stage === 'rally' ? 'Мітинг: −15% міських податків, стабільність падає, опозиція росте.' : p.stage === 'strike' ? 'Страйк: місто майже не платить податків, падає виробництво зброї, будівництво й ріст ВВП.' : 'Бунт: руйнування об’єктів поруч, податків немає.'} Якщо причину усунути, люди розійдуться самі.</div>
      <div class="row" style="gap:6px;margin-top:6px;flex-wrap:wrap"><button class="sm" data-pa="${p.id}:concede" title="Прибрати причину (знизити податок/призов, скасувати закон) або виплатити компенсації й дати обіцянку">Поступитися · ${short(p.concedeCost)} $</button><button class="ghost sm" data-pa="${p.id}:talk" title="60%: протест удвічі менший і загострення відкладається">Переговори · ${short(p.talkCost)} $</button><button class="danger sm" data-pa="${p.id}:disperse" title="Поліція й форма правління підвищують шанс; провал — бунт">Розігнати · шанс ${p.disperseChance}%</button></div></div>`).join('') || '<p class="muted">Зараз протестів немає.</p>'}
    ${(PR.recent || []).length ? `<details><summary class="muted">Нещодавні</summary>${PR.recent.map((r) => `<div style="font-size:13px">${esc(r.name || '')}: «${esc(r.cause)}» — ${esc(r.note || '')}</div>`).join('')}</details>` : ''}</div>`;
}
function bindProtests(b, re) {
  b.querySelectorAll('[data-pa]').forEach((x) => x.onclick = () => { const [id, a] = x.dataset.pa.split(':'); if (a === 'disperse' && !confirm('Розігнати протест силою? Місто запам’ятає це, світ засудить; якщо не вдасться — буде бунт.')) return;
    act(async () => { const r = await api('protest/act', { id: +id, act: a }); toast(r.message); await refreshMe(); re(); }); });
}
