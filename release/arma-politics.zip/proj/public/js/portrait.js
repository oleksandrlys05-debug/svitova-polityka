// Портрети правителів і придворних: малюються автоматично з імені (кожна людина — своє обличчя), без чужих картинок
function hashStr(s) { let h = 2166136261; for (const ch of String(s)) { h ^= ch.codePointAt(0); h = Math.imul(h, 16777619); } return h >>> 0; }
function portrait(name, o = {}) {
  let h = hashStr(name + (o.salt || '')); const r = () => { h ^= h << 13; h ^= h >>> 17; h ^= h << 5; return ((h >>> 0) % 10000) / 10000; };
  const first = String(name).split(' ')[0], fem = o.female != null ? o.female : /[аяАЯ]$/.test(first), age = o.age || 40, old = age > 55, size = o.size || 56;
  const skins = ['#f1c7a5', '#e8b48f', '#d79f7a', '#c68863', '#a96e4c', '#f5d3b8'], skin = skins[Math.floor(r() * skins.length)];
  const hairs = old ? ['#c9c9c9', '#a7a7a7', '#e3e3e3', '#8d8d8d'] : ['#2b1d14', '#4a2f1d', '#6b4423', '#a0703d', '#d8b46a', '#1c1c1c', '#7a2e1b'], hair = hairs[Math.floor(r() * hairs.length)];
  const coats = ['#2c3e50', '#34495e', '#4a3b2a', '#1f3a5f', '#5b2333', '#2f4f3f', '#3d3d55'], coat = o.coat || coats[Math.floor(r() * coats.length)];
  const uniform = o.uniform != null ? o.uniform : r() < 0.3, faceW = 15 + r() * 3, faceH = 18 + r() * 3, eyeY = 30 + r() * 2, eyeDx = 6 + r() * 1.5;
  let s = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="${size}" height="${size}" class="portrait"><rect width="64" height="64" rx="10" fill="${o.bg || '#2a2440'}"/>`;
  // плечі й одяг
  s += `<path d="M6 64c2-12 12-16 26-16s24 4 26 16z" fill="${coat}"/>`;
  if (uniform) s += `<path d="M24 48l8 8 8-8" fill="none" stroke="#d4af37" stroke-width="2"/><rect x="10" y="52" width="9" height="3" rx="1" fill="#d4af37"/><rect x="45" y="52" width="9" height="3" rx="1" fill="#d4af37"/>`;
  else if (fem) s += `<path d="M24 48l8 9 8-9" fill="${skin}"/><path d="M26 54c2 2 4 3 6 3s4-1 6-3" fill="none" stroke="#f3e3b3" stroke-width="1.6"/>`;
  else s += `<path d="M26 48l6 10 6-10" fill="#f2f2f2"/><path d="M31 51l1 9 1-9z" fill="${['#8b1e1e', '#1e3a8b', '#1e6b3a', '#444'][Math.floor(r() * 4)]}"/>`;
  // шия, волосся ззаду (довге), обличчя
  s += `<rect x="27" y="40" width="10" height="10" fill="${skin}"/>`;
  if (fem && r() < 0.85) s += `<path d="M${32 - faceW - 1} 28C${32 - faceW - 1} 10 ${32 + faceW + 1} 10 ${32 + faceW + 1} 28V46H${32 - faceW - 1}z" fill="${hair}"/>`;
  s += `<ellipse cx="32" cy="${28 + faceH / 6}" rx="${faceW / 1.35}" ry="${faceH / 1.3}" fill="${skin}"/>`;
  // волосся зверху
  const hs = Math.floor(r() * 4), L = 32 - faceW / 1.3, Rr = 32 + faceW / 1.3;
  if (!(old && !fem && r() < 0.35)) {
    if (fem) s += `<path d="M${L - 1} 30C${L - 2} 12 ${Rr + 2} 12 ${Rr + 1} 30C${Rr - 3} 22 ${L + 3} 22 ${L - 1} 30z" fill="${hair}"/>`;
    else if (hs === 0) s += `<path d="M${L} 26C${L} 13 ${Rr} 13 ${Rr} 26C${Rr - 3} 20 ${L + 3} 20 ${L} 26z" fill="${hair}"/>`;
    else if (hs === 1) s += `<path d="M${L} 25C${L} 14 ${Rr} 14 ${Rr} 25C${Rr - 5} 21 ${L + 2} 21 ${L} 25z" fill="${hair}"/>`;
    else if (hs === 2) s += `<path d="M${L - 1} 27C${L - 2} 13 ${Rr + 2} 12 ${Rr + 1} 27L${Rr - 2} 20L${L + 6} 19z" fill="${hair}"/>`;
    else s += `<rect x="${L}" y="13" width="${Rr - L}" height="7" rx="3.5" fill="${hair}"/>`;
  }
  // очі, брови, ніс, рот
  const brow = old ? '#9a9a9a' : hair;
  s += `<path d="M${32 - eyeDx - 3} ${eyeY - 4}h5M${32 + eyeDx - 2} ${eyeY - 4}h5" stroke="${brow}" stroke-width="${1.4 + r()}" stroke-linecap="round"/>`;
  s += `<circle cx="${32 - eyeDx}" cy="${eyeY}" r="1.6" fill="#1b1b1b"/><circle cx="${32 + eyeDx}" cy="${eyeY}" r="1.6" fill="#1b1b1b"/>`;
  s += `<path d="M32 ${eyeY + 2}l-1.8 6h3" fill="none" stroke="rgba(0,0,0,.25)" stroke-width="1.2" stroke-linecap="round"/>`;
  const mouthY = eyeY + 12, smile = r() < 0.5;
  s += `<path d="M28 ${mouthY}${smile ? 'q4 3 8 0' : 'h8'}" fill="none" stroke="${fem ? '#b0475a' : '#7a3e33'}" stroke-width="1.6" stroke-linecap="round"/>`;
  // вуса й борода
  if (!fem) { const b = r(); if (b < 0.3) s += `<path d="M26 ${mouthY - 2}q6 -3 12 0q-6 2-12 0z" fill="${old ? '#bdbdbd' : hair}"/>`; else if (b < 0.5) s += `<path d="M${32 - faceW / 1.4} ${mouthY - 6}C${32 - faceW / 1.4} ${mouthY + 8} ${32 + faceW / 1.4} ${mouthY + 8} ${32 + faceW / 1.4} ${mouthY - 6}C${32 + 4} ${mouthY} ${32 - 4} ${mouthY} ${32 - faceW / 1.4} ${mouthY - 6}z" fill="${old ? '#bdbdbd' : hair}" opacity=".92"/><path d="M28 ${mouthY}h8" stroke="#7a3e33" stroke-width="1.4"/>`; }
  if (old) s += `<path d="M24 ${eyeY + 6}q2 1 3 0M37 ${eyeY + 6}q2 1 3 0" stroke="rgba(0,0,0,.2)" stroke-width="1" fill="none"/>`;
  if (o.crown) s += `<path d="M20 12l4 5 4-7 4 7 4-7 4 7 4-5-2 8H22z" fill="#e6b422" stroke="#8a6a10" stroke-width=".8"/>`;
  if (o.dead) s += `<rect width="64" height="64" rx="10" fill="rgba(0,0,0,.55)"/><path d="M14 14l36 36M50 14L14 50" stroke="#ef4444" stroke-width="3"/>`;
  if (o.jail) s += `<path d="M14 0v64M26 0v64M38 0v64M50 0v64" stroke="#555" stroke-width="3"/>`;
  return s + '</svg>';
}
