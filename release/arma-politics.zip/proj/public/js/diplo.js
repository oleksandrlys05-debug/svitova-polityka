// Дипломатія і листування
window.diploSel = window.diploSel === undefined ? null : window.diploSel;
async function renderDiplo() {
  const v = $('#v-diplo'); hideInfo();
  if (!me.country) { v.innerHTML = '<h2>Дипломатія</h2><p class="muted">Спочатку заснуй державу на мапі.</p>'; return; }
  const O = await api('diplo/overview'); if (diploSel === null && O.countries.length) diploSel = O.countries[0].id;
  const sel = diploSel === 0 ? null : O.countries.find((c) => c.id === diploSel);
  const CF = (await api('conf/list').catch(() => ({ confs: [] }))).confs.filter((x) => x.status === 'open');
  v.innerHTML = `<h2>Дипломатія</h2><div id="worldbox"></div><div id="orgbox"></div><div id="puppetbox"></div><div id="relsum"></div>${CF.length ? `<div class="card pad"><h3>Конференції</h3>${CF.map((x) => `<div class="row" style="margin:6px 0"><div class="grow"><b>${x.kind === 'capitulation' ? 'Капітуляція' : 'Мирна конференція'}</b>: ${esc(x.aName)} ↔ ${esc(x.bName)}</div><button class="sm" data-cf="${x.id}">Відкрити</button></div>`).join('')}</div>` : ''}${O.incoming.length ? `<div class="card pad"><h3>Вхідні запити</h3>${O.incoming.map((r) => `<div class="row" style="margin:6px 0"><div class="grow"><b>${esc(r.fromName)}</b>: ${esc(r.typeName)}${r.type === 'ultimatum' ? ' — ' + (r.terms.kind === 'pay' ? 'виплатити ' + exact(r.terms.amount) + ' $' : r.terms.kind === 'cede' ? 'поступитись ' + r.terms.cells + ' кл. території' : 'вимога') : ''}${r.type === 'bloc' ? ' — альянс «' + esc((r.terms || {}).name || '') + '»' : ''}${r.type === 'deal' ? '<div>' + dealTxt(r.terms) + '</div>' : ''}${r.type === 'peace' && r.terms.demand ? ' — умова: стати ' + (r.terms.demand === 'puppet' ? 'маріонеткою' : 'васалом') : ''}${r.text ? `<div class="muted">«${esc(r.text)}»</div>` : ''}<div class="muted" style="font-size:13px">Відповісти до ${gdate(r.deadline)}</div></div><button class="sm" data-ok="${r.id}">Прийняти</button><button class="ghost sm" data-no="${r.id}">Відхилити</button></div>`).join('')}</div>` : ''}
  <div class="grid" style="grid-template-columns:300px 1fr"><div class="card clist"><div class="citem ${diploSel === 0 ? 'on' : ''}" data-s="0"><b>Світовий канал</b><div class="muted" style="font-size:13px">Публічні заяви</div></div>
  ${O.countries.map((c) => `<div class="citem ${c.id === diploSel ? 'on' : ''}" data-s="${c.id}"><span class="sw" style="background:${esc(c.color)}"></span><b>${flagTag(c, 12)}${esc(c.name)}</b>${c.unread ? ` <span class="dot" style="position:static;display:inline-block">${c.unread}</span>` : ''}<div class="muted" style="font-size:13px">${c.bot ? 'ШІ' : esc(c.owner || '—')} · відносини <b class="${c.relation < 0 ? 'neg' : c.relation > 0 ? 'pos' : ''}">${c.relation}</b></div><div>${chips(c)}</div></div>`).join('') || '<div class="citem muted">Інших держав немає.</div>'}</div>
  <div id="dpanel"></div></div>`;
  v.querySelectorAll('[data-cf]').forEach((x) => x.onclick = () => openConfWin(+x.dataset.cf));
  v.querySelectorAll('[data-s]').forEach((x) => x.onclick = () => { diploSel = +x.dataset.s; renderDiplo(); });
  v.querySelectorAll('[data-ok]').forEach((x) => x.onclick = () => act(async () => { await api('diplo/respond', { id: +x.dataset.ok, accept: true }); await refreshMe(); renderDiplo(); }));
  v.querySelectorAll('[data-no]').forEach((x) => x.onclick = () => act(async () => { await api('diplo/respond', { id: +x.dataset.no, accept: false }); renderDiplo(); }));
  const P = $('#dpanel'), chatHtml = '<div class="chat" id="chat"></div><div class="row" style="margin-top:8px"><input id="ct" class="grow" maxlength="500" placeholder="Повідомлення..."><button id="cs">Надіслати</button></div>';
  if (diploSel === 0) P.innerHTML = `<div class="card pad"><h3>Світовий канал</h3>${chatHtml}</div>`;
  else if (sel) {
    const has = (t) => sel.agreements.some((a) => a.type === t), pend = (t) => O.outgoing.some((r) => r.to_c === sel.id && r.type === t);
    const btn = (t, n) => has(t) ? '' : `<button class="ghost sm" data-rq="${t}" ${pend(t) ? 'disabled' : ''}>${pend(t) ? n + ' (очікує)' : n}</button>`;
    P.innerHTML = `<div class="card pad"><h3><span class="sw" style="background:${esc(sel.color)}"></span>${flagTag(sel, 16)}${esc(sel.name)}</h3><div>${chips(sel)}</div><div class="row" style="margin-top:10px">
      ${sel.war ? `<button class="sm" data-conf="peace">Мирна конференція</button><button class="danger sm" data-conf="capitulation">Капітулювати</button>` : `${btn('alliance', 'Союз')}${btn('nonaggression', 'Пакт про ненапад')}${btn('trade', 'Торгова угода')}<button class="ghost sm" id="ult">Ультиматум</button><button class="danger sm" id="war">Оголосити війну</button>`}
      <button class="ghost sm" id="bigw">Вікно держави (торгівля, відносини)</button>
      ${sel.agreements.map((a) => `<button class="ghost sm" data-br="${a.id}">Розірвати: ${agt(a.type)[0].toLowerCase()}</button>`).join('')}</div>
      ${O.outgoing.filter((r) => r.to_c === sel.id).map((r) => `<div class="muted" style="margin-top:6px">Очікує відповіді: ${esc(r.typeName)} <button class="ghost sm" data-cn="${r.id}">Відкликати</button></div>`).join('')}</div>
      <div class="card pad"><h3>Листування</h3>${chatHtml}</div>`;
    P.querySelectorAll('[data-rq]').forEach((x) => x.onclick = () => act(async () => { await api('diplo/request', { to: sel.id, type: x.dataset.rq }); await refreshMe(); renderDiplo(); }, 'Запит надіслано'));
    P.querySelectorAll('[data-conf]').forEach((x) => x.onclick = () => { const k = x.dataset.conf; if (k === 'capitulation' && !confirm('Капітулювати перед ' + sel.name + '? Переможець диктує умови, ви зможете лише писати в чат.')) return; act(async () => { const r = await api('conf/open', { to: sel.id, kind: k }); await refreshMe(); renderDiplo(); openConfWin(r.id); }); });
    P.querySelectorAll('[data-br]').forEach((x) => x.onclick = () => { if (confirm('Розірвати угоду? Це погіршить відносини.')) act(async () => { await api('diplo/break', { id: +x.dataset.br }); renderDiplo(); }); });
    P.querySelectorAll('[data-cn]').forEach((x) => x.onclick = () => act(async () => { await api('diplo/cancel', { id: +x.dataset.cn }); renderDiplo(); }));
    $('#bigw').onclick = () => openCountry(sel.id, 'overview');
    const w = $('#war'); if (w) w.onclick = async () => { if (window.warDepsOk && !(await warDepsOk(sel))) return; const r = await askText(`Оголосити війну: ${sel.name}? Вкажи причину (можна пусто):`); if (r !== null) act(async () => { await api('diplo/war', { target: sel.id, text: r }); await refreshMe(); renderDiplo(); }); };
    const u = $('#ult'); if (u) u.onclick = () => openModal(`<h3>Ультиматум: ${esc(sel.name)}</h3><label for="uk">Вимога</label><select id="uk"><option value="pay">Виплатити гроші</option><option value="cede">Поступитись територією</option><option value="text">Інша вимога (текстом)</option></select><div id="uv"></div><label for="ut2">Текст</label><input id="ut2" maxlength="300"><p class="hint">Якщо відхилять, відносини впадуть, а бот може оголосити війну.</p><div class="err" id="uer"></div><div class="row"><button id="usnd">Надіслати</button><button class="ghost" id="ucl">Скасувати</button></div>`) || (() => {
      const f = () => { $('#uv').innerHTML = $('#uk').value === 'pay' ? '<label>Сума, $</label><input id="ua" type="number" value="50000000">' : $('#uk').value === 'cede' ? `<label>Клітинок території (до 70% території цілі)</label><input id="ua" type="number" value="100">` : ''; }; f(); $('#uk').onchange = f; $('#ucl').onclick = closeModal;
      $('#usnd').onclick = async () => { try { const k = $('#uk').value, a = $('#ua') ? +$('#ua').value : 0; await api('diplo/request', { to: sel.id, type: 'ultimatum', text: $('#ut2').value, terms: k === 'pay' ? { kind: 'pay', amount: a } : k === 'cede' ? { kind: 'cede', cells: a } : { kind: 'text' } }); closeModal(); toast('Ультиматум надіслано'); renderDiplo(); } catch (e) { $('#uer').textContent = e.message; } }; })();
  } else P.innerHTML = '<p class="muted">Обери державу зі списку.</p>';
  renderWorld(); renderPuppets(); renderRelSum(); if (window.renderOrgs) renderOrgs();
  const chat = $('#chat'); if (chat) {
    const load = async () => { const d = await api('diplo/chat?with=' + diploSel); chat.innerHTML = d.messages.map((m) => `<div class="msg ${m.mine ? 'me' : ''}"><small>${esc(m.fromName)}</small>${esc(m.text)}${m.deal && window.dealCard ? dealCard(m.deal) : ''}</div>`).join('') || '<span class="muted">Повідомлень ще немає.</span>'; chat.scrollTop = chat.scrollHeight; };
    window.refreshChat = load; load(); const send = () => { const t = $('#ct').value.trim(); if (t) act(async () => { await api('diplo/send', { to: diploSel, text: t }); $('#ct').value = ''; await load(); }); };
    $('#cs').onclick = send; $('#ct').onkeydown = (e) => { if (e.key === 'Enter') send(); };
  }
}

// ---- Світова рада: голосування, ваги голосів, миротворець ----
window.worldOpen = window.worldOpen || false;
async function renderWorld() {
  const box = $('#worldbox'); if (!box) return; let W; try { W = await api('world/state'); } catch { return; }
  const cn = (id) => (countries[id] || {}).name || ('#' + id), wtxt = (w) => `${w} ${w === 1 ? 'голос' : 'голоси'}`;
  const vrow = (v) => { const mine = v.mine, open = v.status === 'open'; return `<div class="card pad" style="margin:6px 0"><div class="row"><b class="grow">${esc(v.kindName)}: ${esc(v.text)}</b><span class="muted">вніс: ${esc(v.proposerName)}</span></div>
    <div class="bar" style="margin:6px 0"><i style="width:${Math.min(100, v.yes / Math.max(1, v.total) * 100)}%"></i></div><div class="muted">За: ${v.yes} · Проти: ${v.no} · Усього голосів: ${v.total} (потрібно «за» > «проти» і ≥35% усіх)</div>
    ${open ? `<div class="row" style="margin-top:6px"><span>Ваш голос: <b>${mine === 'yes' ? 'За' : mine === 'no' ? 'Проти' : mine === 'abstain' ? 'Утримався' : '—'}</b></span><button class="sm" data-wv="${v.id}:yes">За</button><button class="ghost sm" data-wv="${v.id}:no">Проти</button><button class="ghost sm" data-wv="${v.id}:abstain">Утриматись</button></div>` : `<div class="${v.status === 'passed' ? 'pos' : 'neg'}">${esc(v.result)}</div>`}
    <div class="muted" style="font-size:12px">${v.voters.map((x) => `${esc(x.name)}: ${x.ch === 'yes' ? 'за' : x.ch === 'no' ? 'проти' : 'утр.'}`).join(' · ')}</div></div>`; };
  box.innerHTML = `<div class="card pad"><div class="row"><h3 class="grow" style="margin:0">Світова рада${W.open.length ? ` <span class="badge">${W.open.length}</span>` : ''}</h3><span class="muted">Ваша вага: <b>${wtxt(W.myWeight)}</b>. Миротворець: <b>${W.pk ? esc(W.pk.name) : 'не обрано'}</b></span><button class="ghost sm" id="wtog">${worldOpen ? 'Згорнути' : 'Розгорнути'}</button></div>
  ${worldOpen ? `<p class="hint">Маленька слабка держава має 1 голос, середня — 2, велика сильна — 3 (максимум). Боти можуть голосувати або ігнорувати. Обирати миротворця необов’язково.</p>
    ${W.limits.length ? `<div class="warn">Діють обмеження видобутку: ${W.limits.map((l) => `${esc(RESN[l.res] || l.res)} −${l.pct}% (ще ${l.left} діб)`).join('; ')}</div>` : ''}
    <div class="row" style="gap:8px;margin:8px 0"><select id="wk" style="width:auto">${Object.entries(W.kinds).map(([k, n]) => `<option value="${k}">${esc(n)}</option>`).join('')}</select>
      <select id="wt" style="width:auto">${W.countries.map((o) => `<option value="${o.id}">${esc(o.name)} (${o.w})</option>`).join('')}</select>
      <select id="wr" style="width:auto" class="hidden">${W.res.map((r) => `<option value="${r}">${esc(RESN[r] || r)}</option>`).join('')}</select><input id="wp" type="number" min="10" max="50" value="20" style="width:80px" class="hidden" title="Відсоток обмеження">
      <button id="wgo">Внести на голосування</button></div>
    ${W.open.map(vrow).join('') || '<p class="muted">Відкритих голосувань немає.</p>'}
    ${W.isPk ? `<div class="card pad"><h4 style="margin:0 0 6px">Ви — миротворець</h4>${W.wars.length ? W.wars.map((w) => `<div class="row" style="margin:4px 0"><span class="grow">${esc(w.a)} ⚔ ${esc(w.b)}</span><button class="sm" data-med="${w.id}">Закликати до миру</button></div>`).join('') : '<span class="muted">Зараз немає воєн між іншими державами.</span>'}<button class="ghost sm" id="wres" style="margin-top:6px">Скласти повноваження</button></div>` : ''}
    ${W.recent.length ? `<h4>Останні рішення</h4>${W.recent.map(vrow).join('')}` : ''}` : ''}</div>`;
  $('#wtog').onclick = () => { worldOpen = !worldOpen; renderWorld(); };
  if (!worldOpen) return;
  const sync = () => { const k = $('#wk').value; $('#wr').classList.toggle('hidden', k !== 'limit'); $('#wp').classList.toggle('hidden', k !== 'limit'); $('#wt').classList.toggle('hidden', k === 'limit'); }; $('#wk').onchange = sync; sync();
  $('#wgo').onclick = () => act(async () => { const k = $('#wk').value; await api('world/propose', { kind: k, target: +$('#wt').value, res: $('#wr').value, pct: +$('#wp').value }); await renderWorld(); }, 'Голосування розпочато');
  box.querySelectorAll('[data-wv]').forEach((x) => x.onclick = () => { const [id, ch] = x.dataset.wv.split(':'); act(async () => { await api('world/vote', { id: +id, choice: ch }); await renderWorld(); }, 'Голос враховано'); });
  box.querySelectorAll('[data-med]').forEach((x) => x.onclick = async () => { try { const r = await api('world/mediate', { war: +x.dataset.med }); toast(r.message); await renderWorld(); } catch (e) { toast(e.message, true); } });
  const rs = $('#wres'); if (rs) rs.onclick = () => act(async () => { await api('world/pk/resign', {}); await renderWorld(); }, 'Повноваження складено');
}

// ---- Керування маріонетками і васалами ----
async function renderPuppets() {
  const box = $('#puppetbox'); if (!box) return; if (ACT_AS) return renderActAs(box); let P; try { P = await api('puppet/info'); } catch { return; }
  if (!P.mine.length && !P.master) { box.innerHTML = ''; return; }
  const LN = { 0: 'Без податку', 0.5: 'Знижений (50%)', 1: 'Стандартний', 1.5: 'Підвищений (150%)', 2: 'Подвійний (200%)' }, attc = (a) => (a >= 30 ? 'pos' : a <= -30 ? 'neg' : '');
  const bar = (a) => `<div class="bar" style="margin:4px 0"><i style="width:${(a + 100) / 2}%"></i></div>`;
  box.innerHTML = `<div class="card pad"><h3 style="margin:0 0 6px">${P.mine.length ? 'Керування маріонетками' : 'Мій сюзерен'}</h3>
  ${P.master ? `<div>Ваш сюзерен: <b>${esc(P.master.name)}</b> (${P.master.kind === 'puppet' ? 'маріонетка' : 'васал'}). Ставлення до нього: <b class="${attc(P.master.att)}">${P.master.att}</b> ${bar(P.master.att)}<div class="muted">Податок: ${LN[P.master.taxmul]}. Якщо ставлення тримається на −100 протягом ${P.revoltDays} діб, ви проголосите незалежність і почнете війну.${P.master.negd ? ` <b class="neg">Дні на мінімумі: ${P.master.negd}</b>` : ''}</div></div>` : ''}
  ${P.mine.map((v) => `<div class="card pad" style="margin:6px 0"><div class="row"><b class="grow">${esc(v.name)} <span class="muted">· ${v.kind === 'puppet' ? 'маріонетка' : 'васал'}</span></b><span>Ставлення: <b class="${attc(v.att)}">${v.att}</b> <span class="muted">(тяжіє до ${v.target})</span></span></div>${bar(v.att)}
    <div class="muted">Казна: ${short(v.treasury)} $ · ВВП: ${short(v.gdp)} $ · армія: ${exact(v.army)}${v.negd ? ` · <span class="neg">на мінімумі ${v.negd} діб із ${P.revoltDays} — повстання!</span>` : ''}</div>
    <div class="row" style="gap:8px;margin-top:6px"><label style="margin:0">Податок:</label><select data-ptx="${v.id}" style="width:auto">${P.levels.map((l) => `<option value="${l}" ${l === v.taxmul ? 'selected' : ''}>${LN[l]}</option>`).join('')}</select>
      <button class="sm" data-pgift="${v.id}">Допомога 20 млн $</button><button class="ghost sm" data-pdem="${v.id}" ${v.cdLeft ? 'disabled' : ''} title="Забрати 10% казни, ставлення −15">Вимагати внесок${v.cdLeft ? ` (${v.cdLeft} д.)` : ''}</button>
      <button class="ghost sm" data-prel="${v.id}">Відпустити</button>${v.kind === 'puppet' ? `<button class="sm" data-pact="${v.id}" data-pn="${esc(v.name)}" title="Вести її зовнішню політику: альянси, угоди, торгівля, санкції, війна й мир">Діяти від її імені</button>` : ''}</div></div>`).join('')}</div>`;
  box.querySelectorAll('[data-pact]').forEach((b) => b.onclick = () => setActAs({ id: +b.dataset.pact, name: b.dataset.pn }));
  box.querySelectorAll('[data-ptx]').forEach((s) => s.onchange = () => act(async () => { await api('puppet/tax', { id: +s.dataset.ptx, level: +s.value }); await renderPuppets(); }, 'Податок змінено'));
  box.querySelectorAll('[data-pgift]').forEach((b) => b.onclick = () => act(async () => { await api('puppet/gift', { id: +b.dataset.pgift, amount: 2e7 }); await refreshMe(); }, 'Допомогу надіслано'));
  box.querySelectorAll('[data-pdem]').forEach((b) => b.onclick = () => act(async () => { const r = await api('puppet/demand', { id: +b.dataset.pdem }); toast('Отримано ' + exact(r.amount) + ' $'); await refreshMe(); }, ''));
  box.querySelectorAll('[data-prel]').forEach((b) => b.onclick = () => { if (confirm('Відпустити на незалежність?')) act(async () => { await api('vassal/release', { target: +b.dataset.prel }); await refreshMe(); }, 'Відпущено'); });
}

// ---- режим «діяти від імені маріонетки» ----
function setActAs(v) { ACT_AS = v; diploSel = null; actChip(); if (drawerOpen()) closeDrawer(); renderDiplo(); if (v) toast(`Тепер ви дієте від імені «${v.name}». Усі дипломатичні дії йдуть від її імені.`); }
function actChip() { let ch = $('#actchip'); if (!ACT_AS) { if (ch) ch.remove(); return; } if (!ch) { ch = document.createElement('button'); ch.id = 'actchip'; ch.className = 'sm'; const hr = document.querySelector('.hright'); if (hr) hr.prepend(ch); else document.body.appendChild(ch); } ch.innerHTML = `⇄ <b>${esc(ACT_AS.name)}</b> ✕`; ch.title = `Ви дієте від імені маріонетки «${ACT_AS.name}». Клік — повернутися до своєї держави`; ch.onclick = () => setActAs(null); }
async function renderActAs(box) {
  const [B, me2] = await Promise.all([api('bloc/all').catch(() => ({ blocs: [], mine: 0 })), api('me/as').catch(() => null)]); const my = B.blocs.find((b) => b.id === B.mine);
  box.innerHTML = `<div class="card pad" style="border-color:var(--accent)"><div class="row"><h3 class="grow" style="margin:0">Ви дієте від імені маріонетки «${esc(ACT_AS.name)}»</h3><button class="ghost sm" id="actback">Повернутися до своєї держави</button></div>
    <p class="hint" style="margin:6px 0">Список держав нижче й вікна держав показують дипломатію маріонетки. Запити, союзи, торгівля, санкції, ультиматуми, оголошення війни й мирні конференції йдуть від її імені (парламент маріонетки не заважає). Казна маріонетки: <b>${me2 ? short(me2.country.stats.treasury) : '—'} $</b>.</p>
    <h4>Альянс</h4>${my ? `<div class="row"><span class="grow">У складі альянсу <b>${esc(my.name)}</b> (лідер — ${esc(my.leaderName)}): ${my.members.map((m) => esc(m.name)).join(', ')}</span><button class="ghost sm danger" id="actleave">Вийти з альянсу</button></div>` : '<div class="muted">Не входить до альянсу.</div>'}
    ${B.blocs.filter((b) => b.id !== B.mine).length ? `<table style="margin-top:6px"><tr><th>Альянс</th><th>Лідер</th><th>Учасники</th><th></th></tr>${B.blocs.filter((b) => b.id !== B.mine).map((b) => `<tr><td><span class="sw" style="background:${esc(b.color)}"></span>${esc(b.name)}</td><td>${esc(b.leaderName)}</td><td class="muted">${b.members.map((m) => esc(m.name)).join(', ')}</td><td class="r"><button class="sm" data-ask="${b.id}" ${my ? 'disabled title="Спочатку вийди з поточного альянсу"' : ''}>Попроситися</button></td></tr>`).join('')}</table>` : ''}</div>`;
  $('#actback').onclick = () => setActAs(null);
  const lv = $('#actleave'); if (lv) lv.onclick = () => { if (confirm('Вивести маріонетку з альянсу?')) act(async () => { await api('bloc/leave', {}); renderDiplo(); }, 'Маріонетка вийшла з альянсу'); };
  box.querySelectorAll('[data-ask]').forEach((b) => b.onclick = () => act(async () => { const r = await api('bloc/askjoin', { bid: +b.dataset.ask }); toast(r.status === 'accepted' ? 'Прийнято до альянсу!' : r.status === 'rejected' ? 'Лідер альянсу відмовив' : 'Прохання надіслано лідеру альянсу'); renderDiplo(); }));
}

// що вплинуло на відносини за останні 15 діб
async function renderRelSum() {
  const box = $('#relsum'); if (!box || ACT_AS) { if (box) box.innerHTML = ''; return; } const L = await api('rel/log').catch(() => null); if (!L) return; const ent = Object.entries(L.sum); if (!ent.length) { box.innerHTML = ''; return; }
  box.innerHTML = `<div class="card pad"><div class="row"><h3 class="grow" style="margin:0">Що впливає на відносини (15 діб)</h3><button class="ghost sm" id="rsx">Деталі</button></div><div class="row" style="flex-wrap:wrap;gap:6px;margin-top:8px">${ent.map(([w, v]) => `<span class="chip ${v.s < 0 ? 'neg' : 'pos'}" title="${v.n} змін">${esc(w)}: ${v.s > 0 ? '+' : ''}${nf(v.s, 1)}</span>`).join('')}</div><div id="rsd"></div></div>`;
  $('#rsx').onclick = () => { const d = $('#rsd'); d.innerHTML = d.innerHTML ? '' : `<table style="margin-top:8px">${L.rows.slice(0, 40).map((x) => `<tr><td class="muted">доба ${nf(x.day, 1)}</td><td>${esc(x.otherName)}</td><td>${esc(x.why)}</td><td class="r"><b class="${x.delta < 0 ? 'neg' : 'pos'}">${x.delta > 0 ? '+' : ''}${nf(x.delta, 1)}</b></td><td class="r muted">→ ${nf(x.after, 0)}</td></tr>`).join('')}</table>`; };
}
