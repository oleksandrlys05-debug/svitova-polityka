// Ліва висувна панель (як у HOI4): вікно держави, місто
let drawerKind = null;
function openDrawer(html, kind) {
  let d = $('#drawer'); if (!d) { d = document.createElement('aside'); d.id = 'drawer'; d.innerHTML = '<button class="ghost sm xbtn" id="drx" title="Закрити (Esc)">✕</button><div id="drawerBody"></div>'; $('#app').append(d); $('#drx').onclick = closeDrawer; }
  drawerKind = kind || null; $('#drawerBody').innerHTML = html; d.classList.add('open'); d.scrollTop = 0;
}
function drawerBody() { return $('#drawerBody'); }
function closeDrawer() { const d = $('#drawer'); if (d) d.classList.remove('open'); if (drawerKind === 'country' && window.cwClosed) window.cwClosed(); drawerKind = null; }
const drawerOpen = (kind) => { const d = $('#drawer'); return !!(d && d.classList.contains('open') && (!kind || drawerKind === kind)); };
addEventListener('keydown', (e) => { if (e.key === 'Escape' && drawerOpen() && !typing()) closeDrawer(); });
