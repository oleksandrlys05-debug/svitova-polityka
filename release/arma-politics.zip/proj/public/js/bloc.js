// Альянси (UI) і вікно бою
async function renderBloc(b) {
  const d = (await api('bloc/info')).bloc, O = await api('diplo/overview'), mineId = me.country.id;
  if (!d) {
    b.innerHTML = `<div class="card pad"><h3>Альянс</h3><p class="muted" style="margin-top:0">Ти не в альянсі. Створи свій: обери назву й колір, потім запрошуй держави. Усі учасники автоматично стають союзниками одне одного.</p>
      <div class="row"><div class="grow"><label for="bn">Назва альянсу</label><input id="bn" maxlength="30" placeholder="напр. Північний пакт"></div><div><label for="bc">Колір</label><input id="bc" type="color" value="#2e8b57"></div><button id="bcr" style="align-self:end">Створити</button></div>
      <div class="err" id="berr"></div></div><div class="hint">Колір і назву альянсу буде видно на шарі мапи «Альянси». Бот-держави теж можуть створювати альянси й приймати запрошення.</div>`;
    $('#bcr').onclick = async () => { try { await api('bloc/create', { name: $('#bn').value, color: $('#bc').value }); toast('Альянс створено'); await refreshMe(); } catch (e) { $('#berr').textContent = e.message; } };
    const BA = await api('bloc/all').catch(() => ({ blocs: [] }));
    if (BA.blocs.length) { b.insertAdjacentHTML('beforeend', `<div class="card pad"><h3>Вступити до наявного альянсу</h3><table><tr><th>Альянс</th><th>Лідер</th><th>Учасники</th><th></th></tr>${BA.blocs.map((x) => `<tr><td><span class="sw" style="background:${esc(x.color)}"></span>${esc(x.name)}</td><td>${esc(x.leaderName)}</td><td class="muted">${x.members.map((m) => esc(m.name)).join(', ')}</td><td class="r"><button class="sm" data-ask="${x.id}">Попроситися</button></td></tr>`).join('')}</table><p class="hint">Прохання отримає лідер альянсу. Бот-лідер вирішує за відносинами й силою.</p></div>`);
      b.querySelectorAll('[data-ask]').forEach((x) => x.onclick = () => act(async () => { const r = await api('bloc/askjoin', { bid: +x.dataset.ask }); toast(r.status === 'accepted' ? 'Вас прийнято до альянсу!' : r.status === 'rejected' ? 'Лідер альянсу відмовив' : 'Прохання надіслано лідеру альянсу'); await refreshMe(); renderMe(); })); }
    return;
  }
  const lead = d.leader === mineId, out = O.outgoing.filter((r) => r.type === 'bloc').map((r) => r.to_c), cand = O.countries.filter((c) => !c.bloc && !d.members.some((m) => m.id === c.id) && !c.war);
  b.innerHTML = `<div class="card pad"><h3><span class="sw" style="background:${esc(d.color)}"></span>${esc(d.name)}</h3><div class="muted">Лідер: <b>${esc(d.leaderName)}</b> · учасників: ${d.members.length}</div>
    <table style="margin-top:8px">${d.members.map((m) => `<tr><td>${esc(m.name)}${m.id === d.leader ? ' <span class="badge">лідер</span>' : ''}${m.id === mineId ? ' <span class="badge">ти</span>' : ''}</td><td class="r">${lead && m.id !== mineId ? `<button class="ghost sm" data-kick="${m.id}">Виключити</button>` : ''}</td></tr>`).join('')}</table>
    <div class="row" style="margin-top:10px"><button class="danger sm" id="bl">Вийти з альянсу</button></div></div>
  ${lead ? `<div class="card pad"><h3>Налаштування</h3><div class="row"><div class="grow"><label for="bn">Назва</label><input id="bn" maxlength="30" value="${esc(d.name)}"></div><div><label for="bc">Колір</label><input id="bc" type="color" value="${esc(d.color)}"></div><button id="bsv" style="align-self:end">Зберегти</button></div><div class="err" id="berr"></div></div>
  <div class="card pad"><h3>Запросити державу</h3>${cand.map((c) => `<div class="row" style="margin:4px 0"><span class="sw" style="background:${esc(c.color)}"></span><b class="grow">${esc(c.name)}</b><span class="muted">відносини ${c.relation}</span><button class="sm" data-inv="${c.id}" ${out.includes(c.id) ? 'disabled' : ''}>${out.includes(c.id) ? 'Запрошено' : 'Запросити'}</button></div>`).join('') || '<span class="muted">Немає держав, яких можна запросити.</span>'}</div>` : '<div class="hint">Запрошувати й виключати держави може лише лідер.</div>'}`;
  b.querySelectorAll('[data-kick]').forEach((x) => x.onclick = () => { if (confirm('Виключити державу з альянсу? Відносини погіршаться.')) act(async () => { await api('bloc/kick', { target: +x.dataset.kick }); await refreshMe(); }, 'Виключено'); });
  b.querySelectorAll('[data-inv]').forEach((x) => x.onclick = () => act(async () => { await api('bloc/invite', { to: +x.dataset.inv }); renderMe(); }, 'Запрошення надіслано'));
  $('#bl').onclick = () => { if (confirm('Вийти з альянсу? Союзні угоди з його учасниками буде розірвано.')) act(async () => { await api('bloc/leave', {}); await refreshMe(); }, 'Ви вийшли з альянсу'); };
  const sv = $('#bsv'); if (sv) sv.onclick = async () => { try { await api('bloc/update', { name: $('#bn').value, color: $('#bc').value }); toast('Збережено'); await refreshMe(); } catch (e) { $('#berr').textContent = e.message; } };
}

// ---- вікно бою: окрема панель, яку не перекривають інші вікна ----
let battleOpen = 0, battleMin = false, battleList = [], battleLast = '', battleIdx = 0, battleSeenRecent = '';
async function pollBattles() {
  if (!me || !me.country) return; let d; try { d = await api('battles/live'); } catch { return; }
  battleList = d.battles; const rc = (d.recent || [])[0]; if (rc && rc.text !== battleSeenRecent) { if (battleSeenRecent) battleLast = esc(rc.text); battleSeenRecent = rc.text; }
  renderBattleBox();
}
function renderBattleBox() {
  let box = $('#battlebox'); if (!box) { box = document.createElement('div'); box.id = 'battlebox'; document.body.appendChild(box); }
  const list = battleList; if (battleIdx >= list.length) battleIdx = 0; battleOpen = list.length ? list[battleIdx].id : 0;
  if (!list.length) { box.className = battleLast ? 'show' : ''; box.innerHTML = battleLast ? `<div class="bbhead"><b>⚔ Результат бою</b><span class="grow"></span><button class="ghost sm" id="bbx">✕</button></div><div class="bbres">${battleLast}</div>` : ''; const x = $('#bbx'); if (x) x.onclick = () => { battleLast = ''; renderBattleBox(); }; return; }
  if (battleMin) { box.className = 'show mini'; box.innerHTML = `<button id="bbopen">⚔ Тривають бої: <b>${list.length}</b></button>`; $('#bbopen').onclick = () => { battleMin = false; renderBattleBox(); }; return; }
  const bt = list[battleIdx], att = bt.side === 'attacker', bar = (v, cls) => `<div class="bar ${cls}" style="margin:3px 0"><i style="width:${Math.max(0, Math.min(100, v || 0))}%"></i></div>`;
  const mods = bt.mods.length ? bt.mods.map((m) => `<span class="badge ${m.mine === (m.k > 0) ? 'pos' : 'neg'}" title="${m.mine ? 'на вашу користь/шкоду' : 'для ворога'}">${esc(m.t)} ${m.k > 0 ? '+' : ''}${m.k}% ${m.mine ? '' : '(ворог)'}</span>`).join(' ') : '<span class="muted">без особливих умов</span>';
  const units = bt.mine.map((u) => `<label class="bbu"><input type="checkbox" data-wu="${u.id}"> ${esc(u.name)} <span class="muted">${exact(u.pers)} · орг. ${u.org}%${u.cut ? ' · <b class="neg">в оточенні</b>' : ''}</span></label>`).join('');
  box.className = 'show';
  box.innerHTML = `<div class="bbhead"><b>⚔ Бій біля (${bt.x}, ${bt.y})</b>${list.length > 1 ? `<button class="ghost sm" id="bbnext">наступний (${battleIdx + 1}/${list.length})</button>` : ''}<span class="grow"></span><button class="ghost sm" id="bbgo" title="Показати на мапі">⌖</button><button class="ghost sm" id="bbmin" title="Згорнути (бій триває)">—</button></div>
    ${battleLast ? `<div class="bbres">${battleLast}</div>` : ''}
    <p style="margin:4px 0 6px">${att ? 'Ви атакуєте' : 'Вас атакує'} <b>${esc(bt.enemyName)}</b> · ${esc(bt.terrain)}${bt.river ? ' · річка' : ''} · триває ${nf(bt.days, 2)} доби · ширина фронту ${bt.width || '?'} тис.</p>
    <div class="row" style="gap:10px;align-items:stretch"><div class="mobcard" style="flex:1"><b>Наша організація</b>${bar(bt.myOrg, bt.myOrg >= bt.enOrg ? 'g' : '')}<div class="muted">${bt.myOrg ?? '?'}% · втрати ${exact(bt.myLoss || 0)}</div></div><div class="mobcard" style="flex:1"><b>Організація ворога</b>${bar(bt.enOrg, '')}<div class="muted">${bt.enOrg ?? '?'}% · втрати ${exact(bt.enLoss || 0)}</div></div></div>
    <div style="margin:6px 0">Співвідношення сил: <b class="${bt.ratio >= 1 ? 'pos' : 'neg'}">${nf(bt.ratio, 2)} : 1</b></div>
    <div style="display:flex;flex-wrap:wrap;gap:4px;margin:4px 0">${mods}</div>
    <details style="margin:6px 0"><summary>Наші підрозділи в бою (${bt.mine.length}) · ворога: ${bt.enemy.length}</summary><div class="bbul">${units}</div></details>
    <div class="bbbtns"><button class="ghost neg" id="bbw">Відвести обрані</button><button class="ghost neg" id="bbwa">Відвести всіх</button></div>
    <p class="hint" style="margin:6px 0 0">Бій іде сам. Хто втратить організацію, той відступає. Підкиньте резерви, ударте з флангу (інший бік) або відведіть війська. Підрозділи без постачання в оточенні здаються в полон.</p>`;
  $('#bbmin').onclick = () => { battleMin = true; renderBattleBox(); };
  { const n = $('#bbnext'); if (n) n.onclick = () => { battleIdx = (battleIdx + 1) % list.length; renderBattleBox(); }; }
  $('#bbgo').onclick = () => { if (window.centerOn) centerOn(bt.x, bt.y); };
  const wd = (all) => { const ids = all ? [] : [...box.querySelectorAll('[data-wu]:checked')].map((x) => +x.dataset.wu); if (!all && !ids.length) return toast('Позначте підрозділи', true); if (!confirm(all ? 'Почати відхід усіх військ із бою? Кілька годин вони відходитимуть під вогнем: б’ються слабше, втрати більші, ворог переслідує.' : 'Почати відхід обраних підрозділів під вогнем (кілька годин, більші втрати)?')) return; act(async () => { await api('battle/withdraw', { id: bt.id, units: ids }); await pollBattles(); if (window.loadUnits) await loadUnits(); }, 'Відхід почався: ~4 год під вогнем'); };
  $('#bbw').onclick = () => wd(false); $('#bbwa').onclick = () => wd(true);
}

setInterval(() => { if (battleList.length && !document.hidden) pollBattles(); }, 4000);
