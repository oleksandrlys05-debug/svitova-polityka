// Новини (з цензурою) і журнал війни
const NK = { war: 'Війна', battle: 'Бій', treaty: 'Угода', diplomacy: 'Дипломатія', scandal: 'Скандал', economy: 'Економіка', politics: 'Політика', world: 'Світ', science: 'Наука', disaster: 'Стихія' };
const TAGS = { hidden: ['приховано владою', 'neg'], mine: ['приховано вами', 'warn'], leak: ['витік від розвідки', 'neg'] };
window.newsSub = window.newsSub || 'feed';
async function renderNews() {
  const v = $('#v-news'), S = [['feed', 'Стрічка', 'news'], ['press', 'Преса', 'paper'], ['council', 'Світова рада', 'globe'], ['gazette', 'Газета', 'paper'], ['chron', 'Літопис', 'book'], ['rank', 'Рейтинг', 'star'], ['graphs', 'Графіки', 'chart'], ['world', 'Світові події', 'globe']];
  v.innerHTML = `<h2>${ico('news', 30)} Новини й історія</h2><div class="mgroups">${S.map(([k, t, ic]) => `<button data-ns="${k}" class="${newsSub === k ? 'on' : ''}">${ico(ic, 24)}<span>${t}</span></button>`).join('')}</div><div id="newsBody"></div>`;
  v.querySelectorAll('[data-ns]').forEach((b) => b.onclick = () => { newsSub = b.dataset.ns; renderNews(); });
  const b = $('#newsBody'); try { await ({ feed: renderFeed, press: (x) => renderPress(x), council: (x) => renderCouncil(x), gazette: renderGazette, chron: renderChron, rank: renderRank, graphs: renderGraphs, world: (x) => renderWorldEv(x) }[newsSub] || renderFeed)(b); } catch (e) { b.innerHTML = `<p class="err">${esc(e.message)}</p>`; }
}
async function renderFeed(v) {
  const d = await api('news');
  v.innerHTML = `<p class="hint">Новину про свою державу можна приховати, але це знизить стабільність і підтримку влади, а розвідка інших країн може викрити цензуру.</p><div class="card">${d.news.map((n, ni) => `<div class="news${ni < 40 ? ' nthumb' : ''}">${ni < 40 ? `<div class="nth">${illus(illusFor(n.text), 52)}</div>` : ''}<div class="ntx"><small>${gdate(n.day)}</small> <span class="badge">${NK[n.kind] || n.kind}</span>${n.tag ? `<span class="badge ${TAGS[n.tag][1]}">${TAGS[n.tag][0]}</span>` : ''}<div>${esc(n.text)}</div>${n.canHide ? `<button class="ghost sm" data-h="${n.id}" style="margin-top:4px">Приховати в моїй державі</button>` : ''}</div></div>`).join('') || '<div class="news muted">Новин поки немає.</div>'}</div>`;
  v.querySelectorAll('[data-h]').forEach((x) => x.onclick = () => { if (confirm('Приховати новину? Стабільність −3, підтримка президента −2.')) act(async () => { await api('news/hide', { id: +x.dataset.h }); await refreshMe(); renderNews(); }, 'Новину приховано'); });
}
// газета «Світовий вісник» за місяць
async function renderGazette(v, ym) {
  const d = await api('history/gazette' + (ym ? '?ym=' + ym : '')), g = d.cur || d.preview;
  v.innerHTML = `<div class="row" style="gap:6px;flex-wrap:wrap;margin-bottom:8px">${d.list.map((x) => `<button class="${d.cur && d.cur.ym === x.ym ? '' : 'ghost'} sm" data-gz="${x.ym}">${esc(x.title)}</button>`).join('') || '<span class="muted">Перший номер вийде на початку наступного місяця. Нижче — що потрапить у нього.</span>'}</div>
    <div class="gazette"><div class="gzhead"><div class="gztitle">СВІТОВИЙ ВІСНИК</div><div class="muted">${esc(g.title)}${d.cur ? ` · воєн у світі: ${d.cur.wars}` : ''}</div></div>
    ${g.headline ? `${illus(illusFor(g.headline), 120)}<h2 class="gzh">${esc(g.headline)}</h2>` : ''}${g.ai && g.ai.lead ? `<p class="gzlead">${esc(g.ai.lead)}</p>` : ''}${g.ai && g.ai.articles && g.ai.articles.length ? `<div class="gzarts">${g.ai.articles.map((a) => `<div class="gzart"><h4>${esc(a.title)}</h4><p>${esc(a.text)}</p></div>`).join('')}</div>` : ''}${g.ai && g.ai.editorial ? `<p class="gzed"><b>Колонка редактора.</b> ${esc(g.ai.editorial)}</p>` : ''}${g.ai ? `<div class="muted" style="font-size:12px;text-align:right">Текст: ${g.ai.by === 'ШІ' ? 'штучний інтелект «Вісника»' : 'редакція'}</div>` : ''}
    <div class="gzcols"><div>${(g.items || []).map((i) => `<p class="gzi"><span class="gzic">${i.ic}</span> ${esc(i.text)}</p>`).join('') || '<p class="muted">Подій немає.</p>'}</div>
    <div><h4 style="margin-top:0">Найсильніші держави</h4>${(g.rank || []).map((r, i) => `<div class="row"><b style="width:22px">${i + 1}.</b><span class="sw" style="background:${esc(r.color)}"></span><span class="grow">${esc(r.name)}</span><b>${r.score}</b></div>`).join('')}
      ${g.best ? `<h4>Економіка місяця</h4><div>📈 Найшвидше зростає: <b>${esc(g.best.name)}</b> (${g.best.g >= 0 ? '+' : ''}${nf(g.best.g * 100, 1)}%)</div>` : ''}${g.worst ? `<div>📉 Найгірше: <b>${esc(g.worst.name)}</b> (${g.worst.g >= 0 ? '+' : ''}${nf(g.worst.g * 100, 1)}%)</div>` : ''}</div></div></div>`;
  v.querySelectorAll('[data-gz]').forEach((x) => x.onclick = () => renderGazette(v, +x.dataset.gz));
}
// літопис: важливі події держави чи всього світу
async function renderChron(v, who) {
  const d = await api('history/chronicle?cid=' + (who || window.chronWho || (me.country ? me.country.id : 'world'))); window.chronWho = d.cid || 'world';
  v.innerHTML = `<div class="row" style="gap:6px;flex-wrap:wrap;margin-bottom:8px"><button class="${d.cid ? 'ghost' : ''} sm" data-cw="world">${ico('globe', 16)} Увесь світ</button>${d.countries.map((o) => `<button class="${d.cid === o.id ? '' : 'ghost'} sm" data-cw="${o.id}"><span class="sw" style="background:${esc(o.color)}"></span>${esc(o.name)}</button>`).join('')}</div>
    <div class="card pad chron">${d.rows.map((r) => `<div class="chr"><span class="chic">${r.ic}</span><div><small class="muted">${gdate(r.day)}${!d.cid && r.name ? ' · ' + esc(r.name) : ''}</small><div>${esc(r.text)}</div></div></div>`).join('') || '<p class="muted">Літопис поки порожній: історію ще належить написати.</p>'}</div>`;
  v.querySelectorAll('[data-cw]').forEach((x) => x.onclick = () => { window.chronWho = x.dataset.cw; renderChron(v, x.dataset.cw); });
}
// світовий рейтинг
async function renderRank(v) {
  const d = await api('history/rank'), vis = d.rows.filter((r) => r.score != null), mx = (k) => Math.max(1, ...d.rows.map((r) => r[k] || 0)), F = d.fields || {};
  const lock = '<span class="muted" title="Держава засекретила ці дані">🔒</span>';
  const cell = (r, k, f) => (r[k] == null ? `<td class="r">${lock}</td>` : `<td class="r"><div class="rkbar"><i style="width:${Math.round(r[k] / mx(k) * 100)}%"></i></div>${f(r[k])}${r.spied && r.spied.includes(k) ? ' <span class="badge" title="Засекречено, але ваші агенти дізналися">розвідка</span>' : ''}${r.myHidden && r.myHidden.includes(k) ? ' <span class="muted" title="Інші цього не бачать">🔒</span>' : ''}</td>`);
  let n = 0;
  v.innerHTML = `${d.mine ? `<div class="card pad"><h4 style="margin:0 0 6px">Засекретити дані моєї держави</h4><div class="row" style="gap:6px;flex-wrap:wrap">${Object.entries(F).map(([k, t]) => `<label class="chk" style="margin:0 8px 0 0"><input type="checkbox" data-rh="${k}" ${d.mine[k] ? 'checked' : ''} style="width:auto"> ${esc(t)}</label>`).join('')}<button class="ghost sm" data-rha="1">Засекретити все</button><button class="ghost sm" data-rha="0">Відкрити все</button></div>
    <p class="hint" style="margin:6px 0 0">Інші держави бачитимуть «🔒» замість цих цифр, а якщо засекречено хоч щось — ваш індекс сили й місце не показуються (держава внизу списку). Ваші показники все одно бачать ті, хто має у вас діючих агентів, і адмін.</p></div>` : ''}
    <div class="card"><table><tr><th>#</th><th>Держава</th><th class="r">Індекс сили</th><th class="r">ВВП</th><th class="r">Населення</th><th class="r">Територія</th><th class="r">Армія</th><th class="r">Стабільність</th></tr>
    ${d.rows.map((r) => { const i = r.score != null ? n++ : -1; return `${r.secret && (d.rows[d.rows.indexOf(r) - 1] || {}).score != null ? '<tr><th colspan="8" style="padding-top:12px">Держави із засекреченими даними</th></tr>' : ''}<tr class="${me.country && r.id === me.country.id ? 'mine' : ''}"><td><b>${i < 0 ? '—' : i < 3 ? ['🥇', '🥈', '🥉'][i] : i + 1}</b></td><td><span class="sw" style="background:${esc(r.color)}"></span>${esc(r.name)}</td><td class="r"><b>${r.score == null ? lock : r.score}</b></td>${cell(r, 'gdp', (x) => short(x) + ' $')}${cell(r, 'pop', short)}${cell(r, 'cells', exact)}${cell(r, 'army', exact)}${r.stab == null ? `<td class="r">${lock}</td>` : `<td class="r">${nf(r.stab, 0)}%</td>`}</tr>`; }).join('')}</table></div>
    <p class="hint">Індекс сили: ВВП 30%, військова сила 25%, населення 20%, територія 15%, стабільність 10%.</p>`;
  v.querySelectorAll('[data-rh]').forEach((x) => x.onchange = () => act(async () => { await api('rank/hide', { field: x.dataset.rh, on: x.checked }); renderRank(v); }));
  v.querySelectorAll('[data-rha]').forEach((x) => x.onclick = () => act(async () => { await api('rank/hide', { all: x.dataset.rha === '1' }); renderRank(v); }));
}
// графіки за весь час (щомісячні знімки)
async function renderGraphs(v) {
  const ids = window.graphIds || (me.country ? [me.country.id] : []), d = await api('history/graphs?ids=' + ids.join(','));
  const K = [['gdp', 'ВВП', (x) => short(x) + ' $'], ['pop', 'Населення', short], ['cells', 'Територія (кл.)', exact], ['army', 'Армія (о/с)', exact], ['stab', 'Стабільність', (x) => nf(x, 0) + '%'], ['power', 'Військова сила', (x) => nf(x, 0)]];
  const chart = ([k, t, f]) => { const all = d.series.flatMap((s) => s.rows.map((r) => r[k])).filter((x) => x != null); if (!all.length) return ''; let lo = Math.min(...all), hi = Math.max(...all); const pad = (hi - lo) * 0.15 || Math.abs(hi) * 0.05 || 1; lo -= pad; hi += pad; if (Math.min(...all) >= 0) lo = Math.max(0, lo);
    const n = Math.max(2, ...d.series.map((s) => s.rows.length)), W = 500, H = 120;
    const path = (s) => s.rows[0] && s.rows[0][k] == null ? '' : s.rows.map((r, i) => `${i ? 'L' : 'M'}${(i / (n - 1) * W).toFixed(1)},${(H - (r[k] - lo) / (hi - lo || 1) * H).toFixed(1)}`).join('');
    return `<div class="card pad"><div class="row"><h4 class="grow" style="margin:0">${t}</h4>${d.series.map((s) => `<span style="font-size:13px"><span class="sw" style="background:${esc(s.color)}"></span>${s.rows.length ? (s.rows[s.rows.length - 1][k] == null ? '🔒 засекречено' : esc(f(s.rows[s.rows.length - 1][k]))) : '—'}</span>`).join(' ')}</div>
      <div class="gchart"><span class="gy top">${esc(f(hi))}</span><span class="gy bot">${esc(f(lo))}</span><svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none">${d.series.map((s) => `<path d="${path(s)}" fill="none" stroke="${esc(s.color)}" stroke-width="2.5" vector-effect="non-scaling-stroke"/>`).join('')}</svg></div>
      ${d.series[0] && d.series[0].rows.length ? `<div class="muted" style="font-size:12px">${esc(d.series[0].rows[0].label)} — ${esc(d.series[0].rows[d.series[0].rows.length - 1].label)}</div>` : ''}</div>`; };
  v.innerHTML = `<div class="row" style="gap:6px;flex-wrap:wrap;margin-bottom:8px"><span class="muted">Порівняти:</span>${d.countries.map((o) => `<label class="chk" style="margin:0 6px 0 0"><input type="checkbox" data-gid="${o.id}" ${ids.includes(o.id) ? 'checked' : ''} style="width:auto"> <span class="sw" style="background:${esc(o.color)}"></span>${esc(o.name)}</label>`).join('')}</div>
    <p class="hint" style="margin-top:0">Знімок робиться щомісяця, тож графіки охоплюють усю історію гри.</p><div class="grid g2">${K.map(chart).join('')}</div>`;
  v.querySelectorAll('[data-gid]').forEach((x) => x.onchange = () => { const s = new Set(window.graphIds || ids); if (x.checked) s.add(+x.dataset.gid); else s.delete(+x.dataset.gid); window.graphIds = [...s].slice(0, 6); renderGraphs(v); });
}
async function renderWar() {
  const v = $('#v-war'), d = await api('war/log'), act_ = d.wars.filter((w) => w.status === 'active');
  v.innerHTML = `<h2>Війна</h2><div class="card pad"><h3>Активні війни</h3>${act_.map((w) => `<div style="margin:6px 0"><b>${esc(w.aName)}</b> проти <b>${esc(w.bName)}</b> <span class="muted">· з доби ${Math.floor(w.start_day)}${w.reason ? ' · ' + esc(w.reason) : ''}</span></div>`).join('') || '<p class="muted">Активних війн немає.</p>'}</div>
  <div class="row" style="margin-bottom:8px"><label style="margin:0">Фільтр за державою</label><select id="wf" style="width:auto"><option value="">Усі</option>${[...new Set(d.log.flatMap((l) => [l.aName, l.dName]))].map((n) => `<option>${esc(n)}</option>`).join('')}</select></div>
  <div class="card" id="wl"></div>`;
  const draw = () => { const f = $('#wf').value; $('#wl').innerHTML = d.log.filter((l) => !f || l.aName === f || l.dName === f).map((l) => `<div class="news"><small>${gdate(l.day)}</small> <span class="badge">${l.mode === 'manual' ? 'Arma 3' : l.mode === 'air' ? 'удар з повітря' : 'автобій'}</span><div>${esc(l.text)}</div></div>`).join('') || '<div class="news muted">Боїв поки не було.</div>'; };
  $('#wf').onchange = draw; draw();
  try { await renderOps(v); } catch (e) { /* без операцій */ }
}

// ---------- Світові події: Олімпіада, виставка, світові кризи ----------
async function renderWorldEv(v) {
  const D = await api('world/events'), E = D.cur, PH = { bid: 'прийом заявок', prep: 'підготовка', live: 'триває', done: 'завершено' };
  const medals = (m) => m && m.length ? `<table><tr><th>#</th><th>Держава</th><th class="r">🥇</th><th class="r">🥈</th><th class="r">🥉</th></tr>${m.slice(0, 10).map((r, i) => `<tr${me.country && r.id === me.country.id ? ' style="background:rgba(168,85,247,.12)"' : ''}><td>${i + 1}</td><td>${esc(r.name)}</td><td class="r">${r.g}</td><td class="r">${r.s}</td><td class="r">${r.b}</td></tr>`).join('')}</table>` : '';
  const cr = D.crisis;
  v.innerHTML = `${cr ? `<div class="card pad" style="border-color:#ef4444"><h3>${ico(cr.ic, 28, '#b91c1c')} Світова криза: ${esc(cr.n)}${cr.regName ? ` — ${esc(cr.regName)} світу` : ''}</h3><p>${esc(cr.d)}</p><p class="muted">Ще ${cr.left} діб.${cr.hit === true ? ' <b class="neg">Ваша держава в постраждалому регіоні.</b>' : cr.hit === false ? ' Вашу державу голод оминув.' : ''}</p></div>` : `<div class="card pad"><h3>${ico('globe', 26)} Світові кризи</h3><p class="muted" style="margin:0">Зараз криз немає. ${Object.values(D.crises).map((c) => esc(c.n)).join(', ')} — можуть статися будь-коли й тривають 30–60 діб.</p></div>`}
  ${E ? `<div class="card pad"><h3>${ico(E.ic, 28)} ${esc(E.name)} №${E.no} <span class="chip">${PH[E.phase]}</span></h3><p class="hint" style="margin:4px 0">${esc(E.d)}</p>
    ${E.phase === 'bid' ? `<p>До кінця прийому заявок: <b>${nf(E.left, 1)} д.</b> Переможця визначають внесок, репутація, стабільність, найбільше місто й інфраструктура (війна — великий мінус). Переможені отримують назад половину внеску.</p>
      ${E.bids.some((b) => b.mine) ? '<p class="pos">Вашу заявку подано.</p>' : `<div class="row" style="gap:8px"><input id="wbid" type="number" min="${D.minBid}" value="${D.minBid * 2}" style="width:180px"><span>$</span><button id="wbgo">Подати заявку</button></div><div class="muted">Мінімум ${short(D.minBid)} $.</div>`}
      ${E.bids.length ? `<h4>Заявки</h4>${E.bids.map((b) => `<div>${esc(b.name)}${b.amount != null ? ` — ${short(b.amount)} $` : ''}</div>`).join('')}` : ''}`
    : `<p>Господар: <b>${esc(E.hostName)}</b>. ${E.phase === 'prep' ? `Відкриття через ${nf(E.left, 1)} д.` : `Завершення через ${nf(E.left, 1)} д.`}</p>${E.boycott.length ? `<p class="neg">Бойкотують: ${E.boycott.map((b) => esc(b.name)).join(', ')}</p>` : ''}
      ${me.country && E.host !== me.country.id ? `<button class="${E.iBoycott ? '' : 'ghost'} sm" id="wboy">${E.iBoycott ? 'Скасувати бойкот' : 'Оголосити бойкот'}</button>` : me.country && E.host === me.country.id ? '<p class="pos">Ви — господар! Під час події туристи щодня приносять гроші, а наприкінці — престиж.</p>' : ''}`}</div>`
    : `<div class="card pad"><h3>${ico('stadium', 26)} Олімпіада й виставка</h3><p class="muted" style="margin:0">Наступна світова подія — приблизно через ${nf(D.next || 0, 0)} д. Олімпійські ігри й Всесвітня виставка чергуються.</p></div>`}
  ${D.past.length ? `<div class="card pad"><h3>Минулі події</h3>${D.past.map((p) => `<div style="margin:8px 0"><b>${esc(p.name)} №${p.no}</b>${p.cancelled ? ' — скасовано' : ` — господар ${esc(p.hostName)}${p.best ? `, найкращий павільйон: ${esc(p.best.name)}` : ''}`}${p.medals ? medals(p.medals) : ''}</div>`).join('')}</div>` : ''}
  ${D.hist.length ? `<div class="card pad"><h3>Минулі кризи</h3>${D.hist.map((h) => `<div><small class="muted">${gdate(h.start)}–${gdate(h.until)}</small> ${esc(h.n)}</div>`).join('')}</div>` : ''}`;
  const bg = $('#wbgo'); if (bg) bg.onclick = () => act(async () => { const r = await api('wev/bid', { amount: +$('#wbid').value }); toast(r.message); await refreshMe(); renderWorldEv(v); });
  const bo = $('#wboy'); if (bo) bo.onclick = () => act(async () => { const r = await api('wev/boycott', {}); toast(r.message); renderWorldEv(v); });
}
