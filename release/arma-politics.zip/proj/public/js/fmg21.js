// Оновлення 21: меню мапи в стилі Fantasy Map Generator — «Шар мапи», «Швидке меню», «Армія», «Статистика».
// Замінює ліву легенду: легенда шару тепер усередині вкладки «Шар мапи».
const FMG_ICO = { owners: '🗺', density: '👥', nations: '🧑‍🤝‍🧑', diplo: '🤝', alliances: '🛡', resources: '⛏', air: '✈', drones: '🛰', facilities: '🏭', logistics: '🚂', supply: '📦', weather: '🌦', terrain: '⛰', religion: '⛪', provinces: '🧭', biomes: '🌿' };
const FMG_PRESETS = [['Політична', 'owners', { units: 'all' }], ['Війна', 'owners', { units: 'all', front: true }], ['Дипломатія', 'diplo', {}], ['Економіка', 'resources', {}], ['Логістика', 'logistics', { convoys: true }], ['Природа', 'terrain', { units: 'none' }]];
let fmgTab = 'layers', fmgOpen = true, front21Off = false, labels21Off = false;
try { fmgTab = localStorage.fmgTab || 'layers'; fmgOpen = localStorage.fmgOpen !== '0'; front21Off = localStorage.front21Off === '1'; labels21Off = localStorage.labels21Off === '1'; } catch { /* приватний режим */ }
const fmgSave = () => { try { localStorage.fmgTab = fmgTab; localStorage.fmgOpen = fmgOpen ? '1' : '0'; localStorage.front21Off = front21Off ? '1' : '0'; localStorage.labels21Off = labels21Off ? '1' : '0'; } catch { /* ні */ } };

function fmgMount() {
  const wrap = document.getElementById('mapWrap'); if (!wrap || document.getElementById('fmg')) return;
  try { if (localStorage.fmgOpen == null && (document.body.classList.contains('mob') || innerWidth < 760)) fmgOpen = false; } catch { /* ні */ }
  const el = document.createElement('div'); el.id = 'fmg'; el.className = 'fmg' + (fmgOpen ? '' : ' shut');
  el.innerHTML = `<button id="fmgTog" class="fmgtog" title="Меню мапи">☰<span> Меню мапи</span></button><div class="fmgbody"><div class="fmgtabs">${[['layers', 'Шар мапи'], ['quick', 'Швидке меню'], ['army', 'Армія'], ['stats', 'Статистика']].map(([k, n]) => `<button data-ft="${k}">${n}</button>`).join('')}</div><div id="fmgPane"></div><div id="fmgLegend" class="fmglegend"></div></div>`;
  wrap.appendChild(el);
  el.querySelector('#fmgTog').onclick = () => { fmgOpen = !fmgOpen; el.classList.toggle('shut', !fmgOpen); fmgSave(); if (fmgOpen) fmgRender(); };
  el.querySelectorAll('[data-ft]').forEach((b) => b.onclick = () => { fmgTab = b.dataset.ft; fmgSave(); fmgRender(); });
  // колесо миші в меню не масштабує мапу
  el.addEventListener('wheel', (e) => e.stopPropagation(), { passive: true });
  fmgRender();
}
function fmgRender() {
  const el = document.getElementById('fmg'); if (!el || !fmgOpen) return; el.querySelectorAll('[data-ft]').forEach((b) => b.classList.toggle('on', b.dataset.ft === fmgTab));
  const pane = document.getElementById('fmgPane'); if (!pane) return; const lg = document.getElementById('fmgLegend'); if (lg) lg.style.display = fmgTab === 'layers' && lg.childNodes.length ? '' : 'none';
  ({ layers: fmgLayers, quick: fmgQuick, army: fmgArmy, stats: fmgStats }[fmgTab] || fmgLayers)(pane);
}
// ---------- Шар мапи ----------
function fmgLayers(p) {
  const ms = typeof mapShow !== 'undefined' ? mapShow : { units: 'all', intel: true, convoys: true };
  p.innerHTML = `<div class="fmgsec">Набори</div><div class="fmgpre">${FMG_PRESETS.map(([n], k) => `<button class="ghost sm" data-fp="${k}">${n}</button>`).join('')}</div>
    <div class="fmgsec">Шари</div><div class="fmggrid">${LAYERS.map(([k, n]) => `<button class="fmgtile${layer === k ? ' on' : ''}" data-fl="${k}" title="${esc(n)}"><span>${FMG_ICO[k] || '🗂'}</span><small>${esc(n.replace(/\s*\(.*\)/, ''))}</small></button>`).join('')}</div>
    <div class="fmgsec">Показ</div><div class="fmgshow">
      <select data-fs="units"><option value="all" ${ms.units === 'all' ? 'selected' : ''}>Підрозділи: усі</option><option value="mine" ${ms.units === 'mine' ? 'selected' : ''}>Лише мої</option><option value="none" ${ms.units === 'none' ? 'selected' : ''}>Сховати</option></select>
      <label class="chk"><input type="checkbox" data-fc="intel" ${ms.intel ? 'checked' : ''}> Розвіддані</label><label class="chk"><input type="checkbox" data-fc="convoys" ${ms.convoys ? 'checked' : ''}> Конвої</label>
      <label class="chk"><input type="checkbox" data-fx="front" ${front21Off ? '' : 'checked'}> Лінія фронту</label><label class="chk"><input type="checkbox" data-fx="labels" ${labels21Off ? '' : 'checked'}> Назви держав</label>
      <label class="chk"><input type="checkbox" data-fx="flags" ${typeof flagMode !== 'undefined' && flagMode ? 'checked' : ''}> Прапори</label></div>`;
  p.querySelectorAll('[data-fl]').forEach((b) => b.onclick = () => fmgSetLayer(b.dataset.fl));
  p.querySelectorAll('[data-fp]').forEach((b) => b.onclick = async () => { const [, l, o] = FMG_PRESETS[+b.dataset.fp]; if (o.units && window.setMapShow) setMapShow('units', o.units); if (o.convoys && window.setMapShow) setMapShow('convoys', true); if (o.front) { front21Off = false; fmgSave(); } await fmgSetLayer(l); });
  const su = p.querySelector('[data-fs="units"]'); if (su) su.onchange = () => window.setMapShow && setMapShow('units', su.value);
  p.querySelectorAll('[data-fc]').forEach((x) => x.onchange = () => window.setMapShow && setMapShow(x.dataset.fc, x.checked));
  p.querySelectorAll('[data-fx]').forEach((x) => x.onchange = () => { const k = x.dataset.fx; if (k === 'front') front21Off = !x.checked; if (k === 'labels') labels21Off = !x.checked; if (k === 'flags' && window.toggleFlags && (typeof flagMode !== 'undefined') && flagMode !== x.checked) toggleFlags(); fmgSave(); drawMap(); });
}
async function fmgSetLayer(l) { try { await setLayer(l); } catch (e) { console.error(e); } if (typeof renderSide === 'function') renderSide(); drawMap(); fmgRender(); }
// легенду перенесено в меню
{ const o = window.legend; if (typeof o === 'function') window.legend = function (...a) { const r = o.apply(this, a); try { const src = document.getElementById('legend'), dst = document.getElementById('fmgLegend'); if (src && dst) { dst.innerHTML = ''; if (src.firstChild) dst.insertAdjacentHTML('beforeend', '<div class="fmgsec">Легенда шару</div>'); while (src.firstChild) dst.appendChild(src.firstChild); src.classList.add('hidden'); dst.style.display = fmgTab === 'layers' && dst.childNodes.length ? '' : 'none'; } } catch { /* ні */ } return r; }; }
// перемикачі «Лінія фронту» і «Назви держав»
{ const o = window.drawFront21; if (typeof o === 'function') window.drawFront21 = function (C) { if (front21Off) return; return o(C); }; }
{ const o = window.drawCountryLabels; if (typeof o === 'function') window.drawCountryLabels = function (K) { if (labels21Off) return; return o(K); }; }
// синхронізація: коли шар змінено в правій панелі
{ const o = window.setLayer; if (typeof o === 'function') window.setLayer = async function (l) { const r = await o(l); setTimeout(() => { if (fmgTab === 'layers') fmgRender(); }, 0); return r; }; }

// ---------- Швидке меню ----------
function fmgQuick(p) {
  const items = [['🧭', 'Вся мапа', () => { fitMap(); drawMap(); }], ['⭐', 'До столиці', fmgCapital], ['➕', 'Розширити територію', () => setMode({ kind: 'expand' })], ['🏗', 'Будувати об’єкт', async () => { await fmgSetLayer('facilities'); const b = document.getElementById('bk'); if (b) b.focus(); toast('Оберіть об’єкт у правій панелі й натисніть «Обрати місце на мапі»'); }],
    ['🚂', 'Залізниця', async () => { await fmgSetLayer('logistics'); setMode({ kind: 'rail' }); }], ['🛣', 'Автомагістраль', () => setMode({ kind: 'fortline', what: 'road' })], ['🟫', 'Ґрунтова дорога', () => setMode({ kind: 'fortline', what: 'dirt' })],
    ['🔍', 'Знайти державу', fmgFind], ['📷', 'Знімок мапи', fmgShot], ['🏳', 'Прапори / кольори', () => window.toggleFlags && toggleFlags()], ['📘', 'Туторіал', () => window.tutorial && tutorial()], ['❓', 'Довідка', () => { const h = document.querySelector('[data-help], #helpb, #help'); if (h) h.click(); else if (window.tutorial) tutorial(); }]];
  p.innerHTML = `<div class="fmgsec">Швидкі дії</div><div class="fmgquick">${items.map(([i, n], k) => `<button class="fmgtile" data-fq="${k}"><span>${i}</span><small>${n}</small></button>`).join('')}</div>
    <p class="hint" style="margin:6px 2px 0">Верхні вкладки (Держава, Дипломатія, Війна…) лишаються як були. Колесо — масштаб, перетягування — рух мапи.</p>`;
  p.querySelectorAll('[data-fq]').forEach((b) => b.onclick = () => { try { items[+b.dataset.fq][2](); } catch (e) { toast(e.message, true); } });
}
function fmgCapital() { if (!me || !me.country) return; const C = land.cell, r = cv.getBoundingClientRect(), x = me.country.capital % land.gw, y = (me.country.capital / land.gw) | 0; view.s = Math.max(view.s, view.fs * 4); view.x = r.width / 2 - (x + .5) * C * view.s; view.y = r.height / 2 - (y + .5) * C * view.s; drawMap(); }
async function fmgFind() { const n = await askText('Назва держави (частина назви)', ''); if (!n) return; const k = String(n).toLowerCase(), c = Object.values(countries).find((o) => o.name.toLowerCase().includes(k)); if (!c) return toast('Не знайдено', true); const C = land.cell, r = cv.getBoundingClientRect(), x = c.capital % land.gw, y = (c.capital / land.gw) | 0; view.s = Math.max(view.s, view.fs * 3); view.x = r.width / 2 - (x + .5) * C * view.s; view.y = r.height / 2 - (y + .5) * C * view.s; drawMap(); if (window.openCountry) openCountry(c.id); }
function fmgShot() { try { cv.toBlob((b) => { if (!b) return; const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = `mapa-${Date.now()}.png`; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000); }); } catch (e) { toast('Не вдалося зберегти знімок', true); } }

// ---------- Армія ----------
async function fmgArmy(p) {
  if (!me || !me.country) { p.innerHTML = '<p class="muted">Спочатку заснуйте державу.</p>'; return; }
  p.innerHTML = '<p class="muted">Завантаження…</p>'; let A, Bt; try { [A, Bt] = await Promise.all([api('army/state'), api('battles/live')]); if (window.loadArmyQuick) await loadArmyQuick(); } catch (e) { p.innerHTML = `<p class="err">${esc(e.message)}</p>`; return; }
  if (fmgTab !== 'army') return; const us = (A.units || []).filter((u) => u.personnel > 0), land0 = us.filter((u) => (typeof UTD === 'undefined' ? 'land' : UTD[u.type] || 'land') === 'land'), men = us.reduce((s, u) => s + u.personnel, 0);
  const inB = us.filter((u) => u.battle_id).length, cut = us.filter((u) => u.cut).length, mov = us.filter((u) => u.tx != null).length;
  p.innerHTML = `<div class="fmgstat"><div><b>${us.length}</b><small>підрозділів</small></div><div><b>${short(men)}</b><small>о/с</small></div><div><b class="${inB ? 'neg' : ''}">${inB}</b><small>у бою</small></div><div><b class="${cut ? 'neg' : ''}">${cut}</b><small>в оточенні</small></div><div><b>${mov}</b><small>у русі</small></div></div>
    <div class="fmgsec">Дії з підрозділами</div><div class="fmgpre"><button class="ghost sm" id="faAll">Вибрати всі сухопутні</button><button class="ghost sm" id="faStop">Зупинити вибрані</button><button class="ghost sm" id="faPrev">⚔ Прогноз атаки</button><button class="ghost sm" id="faNew">Армія з вибраних</button></div>
    ${Bt.battles.length ? `<div class="fmgsec">Бої (${Bt.battles.length})</div>${Bt.battles.map((b) => `<div class="fmgbattle" data-fb="${b.x},${b.y}"><b>${b.side === 'attacker' ? 'Атакуємо' : 'Обороняємось'}: ${esc(b.enemyName)}</b> <span class="muted">(${b.x}, ${b.y}) · ${nf(b.days * 24, 0)} год</span><div class="fmgbar"><i style="width:${Math.round(100 * Math.max(0, b.myOrg || 0) / 100)}%"></i></div><small>Наша організація ${b.myOrg ?? '—'} · ворожа ${b.enOrg ?? '—'} · співвідношення сил ×${b.ratio} · втрати ${nf(b.myLoss)} / ${nf(b.enLoss)}</small></div>`).join('')}` : '<p class="muted" style="margin:6px 0">Боїв зараз немає.</p>'}
    <div class="fmgsec">Армії й фронти</div><div id="faArmies">${window.armyQuickHtml ? armyQuickHtml() || '<p class="muted">Армій ще немає: виберіть підрозділи й натисніть «Армія з вибраних». Армія з задачею «Фронт» сама рівномірно тримає лінію; «Атака» — накреслити зону прориву й почати наступ.</p>' : ''}</div>
    <p class="hint" style="margin:6px 2px">Бій триває 1–3 доби. Вийти з бою можна лише «відходом під вогнем» (кілька годин, більші втрати). Окупована земля без ваших військ поруч поволі повертається власнику.</p>`;
  if (window.bindArmyQuick) bindArmyQuick();
  p.querySelector('#faAll').onclick = () => { selSet = new Set(myUnits.filter((x) => (UTD[x.type] || 'land') === 'land' && !x.battle_id).map((x) => x.id)); selUnit = selSet.size === 1 ? [...selSet][0] : null; drawMap(); renderSide(); toast(`Вибрано: ${selSet.size}`); };
  p.querySelector('#faStop').onclick = () => { if (!selSet.size) return toast('Спочатку виберіть підрозділи', true); act(async () => { for (const id of selSet) await api('units/stop', { id }).catch(() => {}); await loadUnits(); }, 'Зупинено'); };
  p.querySelector('#faPrev').onclick = () => { if (!selSet.size) return toast('Спочатку виберіть свої підрозділи', true); setMode({ kind: 'prev21' }); };
  p.querySelector('#faNew').onclick = () => { if (!selSet.size) return toast('Спочатку виберіть підрозділи', true); act(async () => { const r = await api('armies/create', {}); await api('armies/units', { id: r.id, ids: [...selSet].slice(0, 24) }); await loadArmyQuick(); fmgRender(); }, 'Армію створено'); };
  p.querySelectorAll('[data-fb]').forEach((d) => d.onclick = () => { const [x, y] = d.dataset.fb.split(',').map(Number), C = land.cell, r = cv.getBoundingClientRect(); view.s = Math.max(view.s, view.fs * 5); view.x = r.width / 2 - (x + .5) * C * view.s; view.y = r.height / 2 - (y + .5) * C * view.s; drawMap(); });
}
// режим «прогноз атаки»: клік по ворожій точці → прогноз без наказу
{ const o = window.warBanner; window.warBanner = function (m, b) { if (m.kind === 'prev21') { b.innerHTML = `<span>⚔ Прогноз атаки: клікніть ворожу точку — побачите шанси (наказу не буде). Вибрано: ${selSet.size}</span><button id="bcancel">Готово</button>`; b.classList.remove('hidden'); return true; } return o ? o(m, b) : false; }; }
{ const o = window.mapClickWar; window.mapClickWar = async function (e, c) { if (mode.kind === 'prev21') { if (window.showPreview21) { const box = document.getElementById('prev21'); if (box) box.remove(); await showPreview21([...selSet], c.x, c.y); const s = document.getElementById('p21s'); if (s) s.style.display = 'none'; } return true; } return o ? o(e, c) : false; }; }

// ---------- Статистика ----------
async function fmgStats(p) {
  if (!me || !me.country) { p.innerHTML = '<p class="muted">Спочатку заснуйте державу.</p>'; return; }
  p.innerHTML = '<p class="muted">Завантаження…</p>'; let d; try { d = await api('stats21'); } catch (e) { p.innerHTML = `<p class="err">${esc(e.message)}</p>`; return; } if (fmgTab !== 'stats') return;
  const N = d.now, rows = d.rows, pct = (a, b) => (b ? ((a - b) / Math.abs(b)) * 100 : 0), dl = (k, ago, fmt) => { if (!ago || ago[k] == null) return ''; const v = N[k] - ago[k]; if (!v) return '<span class="muted">0</span>'; return `<span class="${v > 0 ? 'pos' : 'neg'}">${v > 0 ? '+' : ''}${fmt(v)}</span>`; };
  const per = (k, n) => { const a = d[n === 7 ? 'd7' : 'd30']; return a && a[k] ? pct(N[k], a[k]) : null; };
  const tile = (k, name, val, fmt, extra = '') => `<div class="fmgtilestat"><div class="row" style="align-items:baseline"><b class="grow">${name}</b><span style="font-weight:700">${val}</span></div><canvas data-sp="${k}" width="260" height="38"></canvas><small>7 діб: ${dl(k, d.d7, fmt) || '—'} · 30 діб: ${dl(k, d.d30, fmt) || '—'}${extra}</small></div>`;
  const g7 = per('pop', 7), gt = per('cells', 30);
  p.innerHTML = `<div class="fmgstat"><div><b>${g7 == null ? '—' : (g7 >= 0 ? '+' : '') + nf(g7, 2) + '%'}</b><small>ріст населення, 7 діб</small></div><div><b>${gt == null ? '—' : (gt >= 0 ? '+' : '') + nf(gt, 1) + '%'}</b><small>ріст території, 30 діб</small></div><div><b>${nf(Math.round(N.stab))}</b><small>стабільність</small></div><div title="Росте від втрат, тривалої війни й окупованої землі; знижує стабільність і підтримку війни"><b class="${(N.weary || 0) >= 60 ? 'neg' : ''}">${N.weary || 0}%</b><small>втома від війни</small></div></div>
    ${tile('pop', 'Населення', short(N.pop), (v) => short(v), N.births != null ? ` · народж. ${nf(N.births, 1)}‰` : '')}
    ${tile('cells', 'Територія', nf(N.cells) + ' кл.', (v) => nf(v) + ' кл.', rows.length && rows[rows.length - 1].occ ? ` · окуповано ворожої: ${nf(rows[rows.length - 1].occ)}` : '')}
    ${tile('gdp', 'ВВП', short(N.gdp) + ' $', (v) => short(v))}${tile('army', 'Армія', short(N.army) + ' о/с', (v) => short(v))}${tile('treasury', 'Казна', short(N.treasury) + ' $', (v) => short(v))}${tile('stab', 'Стабільність', nf(Math.round(N.stab)), (v) => nf(v, 1))}
    <p class="hint" style="margin:6px 2px">Щоденні записи за останні 180 діб (почалися з оновлення 21). Помісячні графіки за весь час — «Моя держава → Історія».</p>`;
  for (const cvs of p.querySelectorAll('canvas[data-sp]')) fmgSpark(cvs, rows.map((r) => r[cvs.dataset.sp]).concat([N[cvs.dataset.sp]]));
}
function fmgSpark(c, vals) { const g = c.getContext('2d'), w = c.width, h = c.height, v = vals.filter((x) => x != null && isFinite(x)); g.clearRect(0, 0, w, h); if (v.length < 2) { g.fillStyle = '#8888'; g.font = '11px sans-serif'; g.fillText('даних ще замало — зберуться за кілька діб', 4, h / 2 + 4); return; }
  const mn = Math.min(...v), mx = Math.max(...v), sp = mx - mn || 1, X = (k) => 2 + k * (w - 4) / (v.length - 1), Y = (x) => h - 3 - (x - mn) / sp * (h - 6), up = v[v.length - 1] >= v[0];
  g.beginPath(); v.forEach((x, k) => (k ? g.lineTo(X(k), Y(x)) : g.moveTo(X(k), Y(x)))); g.strokeStyle = up ? '#2ecc71' : '#e74c3c'; g.lineWidth = 1.8; g.stroke(); g.lineTo(X(v.length - 1), h); g.lineTo(X(0), h); g.closePath(); g.fillStyle = up ? 'rgba(46,204,113,.12)' : 'rgba(231,76,60,.12)'; g.fill(); }

// оновлення відкритої вкладки
setInterval(() => { if (typeof tab !== 'undefined' && tab === 'map' && fmgOpen && (fmgTab === 'army' || fmgTab === 'stats') && !document.querySelector('#fmg :focus')) fmgRender(); }, 20000);
document.addEventListener('DOMContentLoaded', fmgMount); if (document.readyState !== 'loading') fmgMount();
// права панель: показуємо лише коли в ній щось є (вибраний підрозділ, місто, об’єкт, будівництво, ППО…)
{ const sync = () => { const s = document.getElementById('side'); if (!s) return; const empty = !s.textContent.trim() && !s.querySelector('input,select,button,canvas'); document.body.classList.toggle('side-empty', empty); };
  const start = () => { const s = document.getElementById('side'); if (!s) return; new MutationObserver(sync).observe(s, { childList: true, subtree: true }); sync(); };
  document.addEventListener('DOMContentLoaded', start); if (document.readyState !== 'loading') start(); }
