// Оновлення 20: версія для телефона — нижнє меню, мапа на весь екран із панеллю знизу, керування пальцями
// (перетягування, щипок для масштабу, дотик = клік, довгий дотик = додати до вибору), меню «☰» і встановлення як застосунку
const MOB = { short: { map: 'Мапа', me: 'Держава', diplo: 'Дипл.', parl: 'Парлам.', market: 'Ринок', news: 'Новини', war: 'Війна', admin: 'Адмін' } };
const ME = () => (typeof me !== 'undefined' ? me : null);
const isMob = () => innerWidth <= 760 || (matchMedia('(pointer:coarse)').matches && Math.min(innerWidth, innerHeight) <= 820);
function mobApply() { const on = isMob(); document.body.classList.toggle('mob', on); if (!on) document.body.classList.remove('sideOpen'); }
mobApply(); addEventListener('resize', mobApply); addEventListener('orientationchange', () => setTimeout(() => { mobApply(); if (window.resizeMap && !$('#mapWrap').classList.contains('hidden')) resizeMap(); }, 300));

// ---------- нижнє меню: короткі назви ----------
{ const o = window.buildNav; if (typeof o === 'function') window.buildNav = function () { o(); if (!document.body.classList.contains('mob')) return; $('#nav').querySelectorAll('button').forEach((b) => { const n = MOB.short[b.dataset.t]; if (!n) return; const svg = b.querySelector('svg'); b.textContent = ''; if (svg) b.appendChild(svg); b.appendChild(document.createTextNode(n)); }); }; }
addEventListener('resize', () => { if (ME() && me.user && window.buildNav) buildNav(); });

// ---------- кнопка «☰» у верхній панелі ----------
{ const hr = document.querySelector('#top .hright'); if (hr && !$('#mobMenuB')) { const b = document.createElement('button'); b.id = 'mobMenuB'; b.className = 'ghost'; b.title = 'Меню'; b.textContent = '☰'; hr.appendChild(b); b.onclick = mobMenu; } }
function mobMenu() {
  const item = (id, t) => ($('#' + id) ? `<button class="ghost" data-mm="${id}">${t}</button>` : '');
  openModal(`<h3 style="margin-top:0">Меню</h3><div id="mobMenu">${item('helpb', '📖 Довідка')}${item('tutb', '🎓 Туторіал')}${item('theme', '🌗 Світла / темна тема')}${item('flagb', '🚩 Прапори на мапі')}${item('shareb', '🔗 Поділитися грою')}
    <button class="ghost" id="mmInst">📲 Встановити як застосунок</button><button class="ghost" id="mmFull">⛶ На весь екран</button>${item('out', '🚪 Вийти')}</div>
    <p class="hint" style="margin:10px 0 0">${ME() && me.user ? `Ви: <b>${esc(me.user.name)}</b>${me.country ? ` · ${esc(me.country.name)}` : ''}` : ''}</p><div class="row" style="margin-top:8px"><button class="ghost" id="mmX">Закрити</button></div>`);
  document.querySelectorAll('[data-mm]').forEach((x) => x.onclick = () => { closeModal(); $('#' + x.dataset.mm).click(); });
  $('#mmX').onclick = closeModal; $('#mmInst').onclick = () => { closeModal(); pwaInstall(); };
  $('#mmFull').onclick = () => { closeModal(); const d = document.documentElement; try { if (document.fullscreenElement) document.exitFullscreen(); else (d.requestFullscreen || d.webkitRequestFullscreen).call(d); } catch { toast('Цей браузер не дозволяє повний екран', true); } };
}

// ---------- панель мапи (знизу) ----------
{ const t = document.createElement('button'); t.id = 'sideTog'; t.innerHTML = '▲ <span>Панель</span>'; document.body.appendChild(t);
  t.onclick = () => { document.body.classList.toggle('sideOpen'); mobTogLabel(); }; }
function mobTogLabel() { const t = $('#sideTog'); if (!t) return; const open = document.body.classList.contains('sideOpen'); t.innerHTML = open ? '▼ <span>Сховати</span>' : `▲ <span>${ME() && me.country ? (typeof selSet !== 'undefined' && selSet.size ? `Вибрано: ${selSet.size}` : 'Панель') : 'Створити державу'}</span>`; }
{ let lastK = ''; const o = window.renderSide; if (typeof o === 'function') window.renderSide = function (...a) { const r = o.apply(this, a); try { if (document.body.classList.contains('mob')) {
      const hasC = !!(ME() && me.country), sel = typeof selSet !== 'undefined' ? [...selSet].join(',') : '', fac = typeof selFac !== 'undefined' ? selFac || '' : '', vis = typeof selVis !== 'undefined' && selVis ? selVis.id || 1 : '', cd = typeof card !== 'undefined' && card ? JSON.stringify(card).slice(0, 60) : '';
      const k = [hasC, sel, fac, vis, cd].join('|'); if (k !== lastK) { const was = lastK.split('|')[0] === 'true'; lastK = k; if (!hasC || sel || fac || vis || cd) document.body.classList.add('sideOpen'); else if (hasC && !was) document.body.classList.remove('sideOpen'); } mobTogLabel(); } } catch { /* ні */ } return r; }; }
// легенда: дотик згортає/розгортає
{ const lg = $('#legend'); if (lg) lg.addEventListener('click', (e) => { if (!document.body.classList.contains('mob') || e.target.closest('input,label,select,button')) return; lg.classList.toggle('mini'); }); }

// ---------- керування мапою пальцями ----------
(() => {
  const cvs = $('#cv'); if (!cvs) return; let T = null;
  const ev = (t, extra = {}) => { const r = cvs.getBoundingClientRect(); return { clientX: t.clientX, clientY: t.clientY, offsetX: t.clientX - r.left, offsetY: t.clientY - r.top, button: 0, shiftKey: !!extra.shift, ctrlKey: false, movementX: extra.mx || 0, movementY: extra.my || 0, preventDefault() {}, stopPropagation() {} }; };
  const special = () => (typeof brushMode === 'function' && brushMode()) || ['line', 'fortline'].includes((typeof mode !== 'undefined' && mode ? mode : {}).kind);
  const dist = (a, b) => Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);
  cvs.addEventListener('touchstart', (e) => { if (!land) return; e.preventDefault(); const ts = e.touches;
    if (ts.length === 1) { const t = ts[0]; T = { kind: special() ? 'mouse' : 'pan', x: t.clientX, y: t.clientY, lx: t.clientX, ly: t.clientY, vx: view.x, vy: view.y, moved: 0, t0: Date.now(), long: false };
      if (T.kind === 'mouse') { cvs.onmousedown && cvs.onmousedown(ev(t)); }
      T.lt = setTimeout(() => { if (T && T.moved < 10 && T.kind === 'pan') { T.long = true; if (navigator.vibrate) navigator.vibrate(25); } }, 550); }
    else if (ts.length === 2) { if (T && T.lt) clearTimeout(T.lt); if (T && T.kind === 'mouse') dispatchEvent(new MouseEvent('mouseup')); const r = cvs.getBoundingClientRect(), cx = (ts[0].clientX + ts[1].clientX) / 2 - r.left, cy = (ts[0].clientY + ts[1].clientY) / 2 - r.top;
      T = { kind: 'pinch', d0: dist(ts[0], ts[1]), s0: view.s, cx, cy, vx: view.x, vy: view.y, moved: 99 }; } }, { passive: false });
  cvs.addEventListener('touchmove', (e) => { if (!T) return; e.preventDefault(); const ts = e.touches;
    if (T.kind === 'pinch' && ts.length >= 2) { const r = cvs.getBoundingClientRect(), d = dist(ts[0], ts[1]), cx = (ts[0].clientX + ts[1].clientX) / 2 - r.left, cy = (ts[0].clientY + ts[1].clientY) / 2 - r.top;
      const ns = Math.max(view.fs * 0.7, Math.min(view.fs * 30, T.s0 * d / Math.max(1, T.d0))); view.x = cx - (T.cx - T.vx) * ns / T.s0; view.y = cy - (T.cy - T.vy) * ns / T.s0; view.s = ns; drawMap(); return; }
    if (ts.length !== 1) return; const t = ts[0], mx = t.clientX - T.lx, my = t.clientY - T.ly; T.lx = t.clientX; T.ly = t.clientY; T.moved += Math.abs(mx) + Math.abs(my);
    if (T.kind === 'mouse') { if (typeof moved !== 'undefined') moved += Math.abs(mx) + Math.abs(my); cvs.onmousemove && cvs.onmousemove(ev(t, { mx, my })); return; }
    if (T.kind === 'pan') { view.x = T.vx + t.clientX - T.x; view.y = T.vy + t.clientY - T.y; drawMap(); } }, { passive: false });
  cvs.addEventListener('touchend', async (e) => { if (!T) return; e.preventDefault(); const st = T; if (st.lt) clearTimeout(st.lt);
    if (e.touches.length) { if (st.kind === 'pinch' && e.touches.length === 1) { const t = e.touches[0]; T = { kind: 'pan', x: t.clientX, y: t.clientY, lx: t.clientX, ly: t.clientY, vx: view.x, vy: view.y, moved: 99, t0: Date.now() }; } return; }
    T = null; const t = e.changedTouches[0];
    if (st.kind === 'mouse') { dispatchEvent(new MouseEvent('mouseup')); if (st.moved < 10 && cvs.onclick) { try { moved = 0; } catch { /* ні */ } await cvs.onclick(ev(t)); } return; }
    if (st.kind === 'pan' && st.moved < 10) { try { moved = 0; } catch { /* ні */ } const E = ev(t, { shift: st.long }); if (cvs.onmousemove) cvs.onmousemove(E); if (cvs.onclick) await cvs.onclick(E); const tip = $('#tip'); if (tip) setTimeout(() => tip.classList.add('hidden'), 3500); }
    if (st.kind === 'pan' && st.moved >= 10) { try { moved = st.moved; } catch { /* ні */ } } }, { passive: false });
  cvs.addEventListener('touchcancel', () => { if (T && T.lt) clearTimeout(T.lt); if (T && T.kind === 'mouse') dispatchEvent(new MouseEvent('mouseup')); T = null; });
})();

// ---------- встановлення як застосунку (PWA) ----------
let pwaPrompt = null;
addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); pwaPrompt = e; });
addEventListener('appinstalled', () => { pwaPrompt = null; toast('Гру встановлено як застосунок — шукайте іконку «Світова політика»'); });
async function pwaInstall() {
  if (matchMedia('(display-mode: standalone)').matches) return toast('Гра вже відкрита як застосунок');
  if (pwaPrompt) { pwaPrompt.prompt(); try { await pwaPrompt.userChoice; } catch { /* ні */ } pwaPrompt = null; return; }
  const ios = /iphone|ipad|ipod/i.test(navigator.userAgent), secure = location.protocol === 'https:' || ['localhost', '127.0.0.1'].includes(location.hostname);
  openModal(`<h3 style="margin-top:0">📲 Встановити гру на телефон</h3>${ios ? '<p>На iPhone відкрийте гру в <b>Safari</b>, натисніть <b>«Поділитися»</b> (квадрат зі стрілкою) → <b>«На екран “Додому”»</b> → «Додати».</p>' : '<p>У <b>Chrome</b>: меню <b>⋮</b> (угорі праворуч) → <b>«Додати на головний екран»</b> або <b>«Встановити застосунок»</b> → «Встановити».</p>'}
    ${secure ? '' : '<p class="warn">Зараз гра відкрита за адресою http://… (локальна мережа). Повноцінний застосунок встановлюється лише з посилання https://….trycloudflare.com, яке дає хост. З цієї адреси вийде звичайний ярлик.</p>'}
    <p class="hint">Після встановлення гра відкривається з іконки на весь екран, без рядка адреси. Потрібен інтернет і запущений сервер у хоста: гра йде на його комп’ютері чи телефоні. Якщо хост перезапустив сервер і посилання змінилося, відкрийте нове посилання й встановіть ще раз.</p><div class="row"><button id="pwx">Зрозуміло</button></div>`);
  $('#pwx').onclick = closeModal;
}
if ('serviceWorker' in navigator && (location.protocol === 'https:' || ['localhost', '127.0.0.1'].includes(location.hostname)) && !navigator.userAgent.includes('Electron')) navigator.serviceWorker.register('/sw.js').catch(() => { /* ні */ });

// ---------- мапа на телефоні: не скидати масштаб, коли браузер ховає/показує рядок адреси; спершу показати свою державу ----------
{ const o = window.resizeMap; let fitted = false; if (typeof o === 'function') window.resizeMap = function () {
    if (!document.body.classList.contains('mob') || !land) return o();
    const r = cv.getBoundingClientRect(); if (!r.width || !r.height) return;
    if (!fitted) { o(); fitted = true; mobFocusOwn(); return; }
    cv.width = r.width * devicePixelRatio; cv.height = r.height * devicePixelRatio; drawMap(); }; }
function mobFocusOwn() { try { const c = ME() && me.country, r = cv.getBoundingClientRect(); if (!c || c.capital == null || !land || !r.width) return false; const x = c.capital % land.gw, y = (c.capital / land.gw) | 0, k = view.fs * 4; view.s = k; view.x = r.width / 2 - (x + 0.5) * land.cell * k; view.y = r.height * 0.42 - (y + 0.5) * land.cell * k; drawMap(); return true; } catch { return false; } }
{ let n = 0; const iv = setInterval(() => { if (++n > 60) return clearInterval(iv); if (!document.body.classList.contains('mob')) return; if (typeof land !== 'undefined' && land && ME() && me.country && Math.abs(view.s - view.fs) < 1e-9 && mobFocusOwn()) clearInterval(iv); }, 500); }
