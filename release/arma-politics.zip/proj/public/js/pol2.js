const IDN = { communism: 'Комунізм', democracy: 'Демократія', socialism: 'Соціалізм', neutrality: 'Нейтралітет', authoritarianism: 'Авторитаризм', fascism: 'Фашизм', nationalism: 'Націоналізм' };
// Політика 2: ідеологія, прапор, репутація
async function renderIdeoFlag(b) {
  const [I, X] = await Promise.all([api('ideology/state'), api('diplo/extra').catch(() => ({ rep: 50 }))]), cur = I.list.find((x) => x.id === I.current) || I.list[0], el = document.createElement('div');
  const lists = (x) => `<ul style="margin:4px 0 4px 18px;padding:0">${x.pros.map((t) => `<li class="pos">${esc(t)}</li>`).join('')}${x.cons.map((t) => `<li class="neg">${esc(t)}</li>`).join('')}</ul>`;
  el.innerHTML = `<div class="card pad"><h3>Ідеологія держави: <span style="color:${cur.color}">${esc(cur.n)}</span></h3>
    <div class="muted" style="font-size:13px">Міжнародна репутація: <b>${nf(X.rep, 0)}</b> з 100 (напад без причини, розрив пактів знижують; допомога союзникам і гарантії підвищують)</div>
    ${lists(cur)}
    ${I.impulse != null ? `<div style="margin:6px 0">Імпульс завоювань: <b>${I.impulse}</b> / 100 <div class="bar ${I.impulse < 25 ? 'r' : 'g'}" style="max-width:300px"><i style="width:${I.impulse}%"></i></div><div class="hint">Росте від нових захоплених територій, згасає щодня. Нижче 25 — економіка й стабільність падають.</div></div>` : ''}
    ${I.coupRisk ? '<div class="warn">Підтримка президента низька: у авторитарної держави є шанс державного перевороту!</div>' : ''}
    ${I.change ? `<div class="card pad warn"><b>Триває реформа ладу → ${esc((I.list.find((x) => x.id === I.change.to) || {}).n)}</b>, завершення за ${nf(Math.max(0, I.change.until - me.world.day), 0)} діб. Поки триває, стабільність −8, підтримка президента −5. <button class="ghost sm" id="ich">Скасувати реформу</button></div>` : I.coolLeft > 0 ? `<div class="muted">Новий лад можна запровадити через ${Math.ceil(I.coolLeft)} діб.</div>` : ''}
    <h4 style="margin:12px 0 4px">Змінити лад (реформа ${I.days} діб, ${exact(I.cost)} $)</h4>
    <div class="grid g2">${I.list.filter((x) => x.id !== I.current).map((x) => `<div class="card pad"><h4 style="color:${x.color};margin:0">${esc(x.n)}</h4>${lists(x)}<button class="sm" data-ib="${x.id}"${I.change || I.coolLeft > 0 ? ' disabled' : ''}>Запровадити</button></div>`).join('')}</div></div>
  <div class="card pad"><h3>Прапор</h3>${me.country.flag ? `<div style="margin:6px 0"><img src="${flagUrl(me.country)}" alt="" style="max-height:90px;max-width:200px;border:1px solid #8886;border-radius:3px"></div>` : '<p class="muted">Прапор не завантажено: на мапі використовується колір держави.</p>'}
    <div class="row"><input type="file" id="flf" accept="image/png,image/jpeg,image/svg+xml" style="width:auto"><button class="sm" id="flu">Завантажити</button>${me.country.flag ? '<button class="ghost sm" id="fld">Прибрати</button>' : ''}</div>
    <p class="hint">PNG, JPG або SVG до 300 КБ. Прапор показується у вікні держави, дипломатії, на столиці й (кнопка «Прапори» вгорі) на всій території. Адмін може замінити або видалити прапор.</p></div>`;
  b.appendChild(el);
  el.querySelectorAll('[data-ib]').forEach((x) => x.onclick = () => { const t = I.list.find((y) => y.id === x.dataset.ib); if (confirm(`Запровадити лад «${t.n}»? Реформа триває ${I.days} діб і коштує ${exact(I.cost)} $.`)) act(async () => { await api('ideology/change', { to: t.id }); renderMe(); }, 'Реформу розпочато'); });
  const ich = el.querySelector('#ich'); if (ich) ich.onclick = () => act(async () => { await api('ideology/cancel', {}); renderMe(); });
  el.querySelector('#flu').onclick = () => { const f = el.querySelector('#flf').files[0]; if (!f) return toast('Обери файл', true); if (f.size > 300 * 1024) return toast('Файл завеликий (максимум 300 КБ)', true); const r = new FileReader(); r.onload = () => act(async () => { await api('flag/upload', { data: r.result }); await refreshMe(); }, 'Прапор завантажено'); r.readAsDataURL(f); };
  const fld = el.querySelector('#fld'); if (fld) fld.onclick = () => act(async () => { await api('flag/delete', {}); await refreshMe(); });
}
