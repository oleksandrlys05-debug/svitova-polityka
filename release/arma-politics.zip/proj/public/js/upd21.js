// Оновлення 21 (клієнт): гравці й схвалення в адмінці, самопереворот, перевірка торгових пропозицій
// ---------- адмін: гравці, пошта, схвалення ----------
{ const o = window.aCountries; if (typeof o === 'function') window.aCountries = async function (b) { await o(b); try { await adminUsers21(b); } catch (e) { console.error('users21', e); } }; }
async function adminUsers21(box) {
  const d = await api('admin/users21'), pend = d.users.filter((u) => !u.approved), el = document.createElement('div'); el.className = 'card pad';
  const row = (u) => `<tr><td><b>${esc(u.name)}</b>${u.role === 'admin' ? ' <span class="badge">адмін</span>' : ''}${u.banned ? ' <span class="badge">заблоковано</span>' : ''}<div class="muted" style="font-size:12px">${esc(u.email || 'пошти немає')}${u.discord ? ' · ' + esc(u.discord) : ''}${u.created ? ' · ' + new Date(u.created).toLocaleString('uk-UA') : ''}</div></td>
    <td>${u.country ? esc(u.country) : '<span class="muted">без держави</span>'}</td><td class="r" style="white-space:nowrap">${u.approved ? (u.role !== 'admin' ? `<button class="ghost sm" data-uno="${u.id}" title="Забрати схвалення: не зможе заснувати нову державу">Зняти схвалення</button>` : '') : `<button class="sm" data-uok="${u.id}">Схвалити</button>`}
    <button class="ghost sm" data-uem="${u.id}" data-cur="${esc(u.email || '')}">Пошта</button></td></tr>`;
  el.innerHTML = `<h3 style="margin-top:0">👤 Гравці й реєстрації${pend.length ? ` <span class="badge" style="border-color:#f59e0b">чекають: ${pend.length}</span>` : ''}</h3>
    <label class="chk"><input type="checkbox" id="u21ap" ${d.approveNew ? 'checked' : ''} style="width:auto"> Нові акаунти засновують державу лише після схвалення адміна (захист від спам-акаунтів)</label>
    <p class="hint">Реєстрація вимагає електронну пошту (одна пошта — один акаунт), з однієї інтернет-адреси — не більше 3 акаунтів на добу. Пошту бачить лише адмін. Видалити акаунт і його державу — кнопка «Видалити гравця» нижче.</p>
    ${pend.length ? `<h4>Чекають схвалення</h4><table>${pend.map(row).join('')}</table>` : ''}
    <details ${pend.length ? '' : 'open'}><summary>Усі акаунти (${d.users.length})</summary><div style="max-height:320px;overflow:auto"><table>${d.users.filter((u) => u.approved).map(row).join('')}</table></div></details>`;
  box.prepend(el);
  el.querySelector('#u21ap').onchange = (e) => act(async () => { await api('admin/settings', { approveNew: e.target.checked ? 1 : 0 }); toast(e.target.checked ? 'Нові гравці чекатимуть схвалення' : 'Нові гравці засновують державу одразу'); });
  el.querySelectorAll('[data-uok]').forEach((x) => x.onclick = () => act(async () => { await api('admin/user/approve', { id: +x.dataset.uok }); toast('Схвалено'); renderAdmin(); }));
  el.querySelectorAll('[data-uno]').forEach((x) => x.onclick = () => act(async () => { await api('admin/user/approve', { id: +x.dataset.uno, no: 1 }); toast('Схвалення знято'); renderAdmin(); }));
  el.querySelectorAll('[data-uem]').forEach((x) => x.onclick = async () => { const v = await askText('Електронна пошта гравця', x.dataset.cur); if (v != null) act(async () => { await api('admin/user/email', { id: +x.dataset.uem, email: v }); renderAdmin(); }, 'Збережено'); });
}

// ---------- парламент: розпуск назавжди (самопереворот) ----------
ctlWrap('renderParl', async () => {
  const v = $('#v-parl'); if (!v || v.querySelector('#abol21')) return; let d; try { d = await api('parl/abolish'); } catch { return; } if (!d.possible) return;
  const el = document.createElement('div'); el.className = 'card pad'; el.id = 'abol21';
  el.innerHTML = `<h3 style="margin-top:0">⚖ Розпустити парламент назавжди</h3><p class="muted" style="margin:4px 0">Кнопка «Розпустити парламент» вище лише проводить <b>дострокові вибори</b> (раз на 60 діб). Якщо хочете правити без парламенту — самопереворот: лад стає <b>авторитаризмом</b>, рішення ухвалюються указами без голосування.</p>
    <p style="margin:4px 0">Вартість: <b>${short(d.cost)} $</b>. Шанс успіху залежить від підтримки правителя (зараз ${d.support}%, бажано ≥ ${d.need}%) і стабільності. Невдача: стабільність −12, підтримка −15. Успіх: стабільність −6, репутація −10, демократії незадоволені. Повернути парламент — зміною ладу.</p>
    <button class="danger sm" id="abol21b">Розпустити парламент назавжди</button>`;
  v.appendChild(el);
  el.querySelector('#abol21b').onclick = () => { if (confirm('Розпустити парламент назавжди і перейти до авторитаризму?')) act(async () => { const r = await api('parl/abolish', {}); toast(r.message, !r.ok); await refreshMe(); renderParl(); }); };
});

// ---------- торгові пропозиції: попередження, якщо в тебе немає того, що просять ----------
async function dealWarn21(root) {
  if (!root) return; for (const x of root.querySelectorAll('[data-ok]')) { if (x.dataset.w21) continue; x.dataset.w21 = 1; const id = +x.dataset.ok; if (!id) continue;
    api('deal/check?id=' + id).then((r) => { if (!r || !r.err) return; x.disabled = true; x.title = r.err; x.insertAdjacentHTML('beforebegin', `<div class="neg" style="font-size:12px;margin:2px 0">⚠ ${esc(r.err)} — прийняти не можна</div>`); }).catch(() => {}); }
}
ctlWrap('renderDiplo', async () => dealWarn21($('#v-diplo')));
{ let t21 = 0; const mo = new MutationObserver(() => { if (t21) return; t21 = setTimeout(() => { t21 = 0; const cw = document.querySelector('#cwbody'); if (cw) dealWarn21(cw); }, 300); }); document.addEventListener('DOMContentLoaded', () => mo.observe(document.body, { childList: true, subtree: true })); if (document.readyState !== 'loading') mo.observe(document.body, { childList: true, subtree: true }); }

// ---------- (21) усі санкції в одному місці: загальні санкції й ембарго — у вкладці «Санкції» вікна держави ----------
{ const o = window.cwTab_sanc; if (typeof o === 'function') window.cwTab_sanc = async function (b) { await o(b); try { const sel = cw.sel || {}, S = sel.sanc || {}; const el = document.createElement('div'); el.className = 'card pad';
    el.innerHTML = `<h3 style="margin-top:0">Загальні заходи</h3><p class="muted" style="margin:2px 0 8px">Загальні санкції — політичний тиск: хто торгує з цією державою, псує відносини з вами. Ембарго — повна заборона торгівлі між вами. Точкові санкції (експорт, імпорт, компанії, технології) — нижче.</p>
      <div class="row" style="gap:6px;flex-wrap:wrap">${S.byMe ? '<button class="ghost sm" data-sanc="off">Зняти загальні санкції</button>' : '<button class="ghost sm" data-sanc="on">Накласти загальні санкції</button>'}${S.embByMe ? '<button class="ghost sm" data-emb="off">Зняти ембарго</button>' : '<button class="danger sm" data-emb="on">Повне ембарго</button>'}</div>`;
    b.prepend(el);
    el.querySelectorAll('[data-emb]').forEach((x) => x.onclick = () => { if (x.dataset.emb === 'on' && !confirm('Ввести повне торговельне ембарго? Відносини погіршаться на 20.')) return; cwAct(() => api('embargo/set', { target: cw.id, on: x.dataset.emb === 'on' }), x.dataset.emb === 'on' ? 'Ембарго введено' : 'Ембарго знято'); });
    el.querySelectorAll('[data-sanc]').forEach((x) => x.onclick = () => cwAct(() => api('sanction/set', { target: cw.id, on: x.dataset.sanc === 'on' }), x.dataset.sanc === 'on' ? 'Санкції накладено' : 'Санкції знято')); } catch (e) { console.error('sanc21', e); } }; }
