// «Моя держава»: підвкладки Економіка, Ресурси, Виробництво, Технології, Армія, Розвідка, Політика
window.meSub = window.meSub || 'eco';
// 6 груп зі значками, у кожній 2–3 підвкладки (id підвкладок незмінні — на них ведуть посилання зі сповіщень)
const MGROUPS = [
  { t: 'Економіка', ic: 'eco', subs: [['eco', 'Огляд'], ['laws', 'Закони й податки'], ['fin', 'Облігації й рейтинг'], ['biz', 'Бізнес і туризм'], ['mega', 'Мегапроєкти'], ['invest', 'Біржа й інвестиції']] },
  { t: 'Промисловість', ic: 'civ', subs: [['res', 'Ресурси'], ['prod', 'Виробництво'], ['tech', 'Технології']] },
  { t: 'Суспільство', ic: 'people', subs: [['nat', 'Населення й нації'], ['demo', 'Демографія'], ['sep', 'Сепаратизм'], ['cities', 'Міста'], ['rel', 'Релігія'], ['prov', 'Області'], ['env', 'Довкілля']] },
  { t: 'Влада', ic: 'crown', subs: [['court', 'Двір'], ['media', 'ЗМІ й опозиція'], ['order', 'Порядок'], ['dec', 'Рішення'], ['pol', 'Ідеологія й політика'], ['gov', 'Форма правління'], ['mafia', 'Мафія й контрабанда']] },
  { t: 'Військо', ic: 'shield', subs: [['army', 'Армія'], ['tmpl', 'Конструктор підрозділів'], ['design', 'Конструктор техніки'], ['gear', 'Спорядження й боєприпаси'], ['defco', 'Оборонні компанії'], ['doc', 'Доктрина й укріплення'], ['occ', 'Окупація й полонені'], ['merc', 'ПВК'], ['vol', 'Добровольці'], ['bloc', 'Альянс']] },
  { t: 'Розвідка', ic: 'spy', subs: [['intel', 'Агенти й досьє'], ['fcourt', 'Чужі двори'], ['cyber', 'Кібервійна']] },
];
const SUBS = MGROUPS.flatMap((g) => g.subs.map(([id, t]) => ({ id, t })));
const groupOf = (sub) => MGROUPS.find((g) => g.subs.some(([id]) => id === sub)) || MGROUPS[0];
const ECO_KEYS = ['gdp', 'budget', 'expenses', 'debt', 'treasury', 'population', 'infrastructure'];
const POL_KEYS = ['happy', 'warSupport', 'stability', 'presidentSupport'];
const INFO = {
  gdp: (s) => ({ r: [['Точне значення', exact(s.gdp) + ' $'], ['ВВП на душу населення', exact(s.gdp / s.population) + ' $'], ['Доходи бюджету', pc(s.budget / s.gdp) + ' ВВП'], ['Витрати бюджету', pc(s.expenses / s.gdp) + ' ВВП'], ['Державний борг', pc(s.debt / s.gdp) + ' ВВП']], d: 'Вартість усього, що держава виробляє за рік.' }),
  budget: (s) => ({ r: [['Точне значення', exact(s.budget) + ' $ на рік'], ['Частка ВВП', pc(s.budget / s.gdp)], ['На одного жителя', exact(s.budget / s.population) + ' $'], ['Надходить за добу', exact(s.budget / 365) + ' $']], d: 'Скільки держава збирає податками та зборами.' }),
  expenses: (s) => { const b = s.budget - s.expenses; return { r: [['Точне значення', exact(s.expenses) + ' $ на рік'], ['Частка ВВП', pc(s.expenses / s.gdp)], ['Від доходів', pc(s.expenses / s.budget)], [b >= 0 ? 'Профіцит бюджету' : 'Дефіцит бюджету', exact(Math.abs(b)) + ' $'], ['Витрачається за добу', exact(s.expenses / 365) + ' $']], d: 'Армія, соціальна сфера, освіта, інфраструктура та управління. Окремо утримуються солдати та агенти.' }; },
  debt: (s) => ({ r: [['Точне значення', exact(s.debt) + ' $'], ['Частка ВВП', pc(s.debt / s.gdp)], ['На одного жителя', exact(s.debt / s.population) + ' $'], ['Відсотки за рік (≈4%)', exact(s.debt * .04) + ' $'], ['Відсотки від доходів', pc(s.debt * .04 / s.budget)]], d: 'Скільки держава винна кредиторам. Якщо казна порожня, борг росте.' }),
  treasury: (s) => ({ r: [['Точне значення', exact(s.treasury) + ' $'], ['Баланс за рік (без армії)', exact(s.budget - s.expenses - s.debt * .04) + ' $']], d: 'Гроші, які можна витратити: розширення, розвідка, найм командирів, рішення подій.' }),
  population: (s) => { const m = me.country.manpower, cap = me.country.popCap; return { r: [['Точне значення', exact(s.population) + ' осіб'], ['Місткість (села + міста)', exact(cap)], ['Наповненість', pc(s.population / cap)], ['Людські ресурси (20%)', exact(m.total)], ['Рівні міст (сума)', (s.cityLevels || 0) + ' у ' + (s.cities || 0) + ' містах']], d: 'Населення росте до місткості: чим більші міста, тим більше людей. Покращуй міста у вкладці «Виробництво».' }; },
  manpower: () => { const m = me.country.manpower, s = me.country.stats; return { t: 'Людські ресурси', r: [[`Всього (${m.pct}% населення)`, exact(m.total)], ['У війську', exact(m.used)], ['Вільні', exact(m.free)], ['Призов', `${s.mobCur || 0}%${s.mobPct != null && s.mobPct !== s.mobCur ? ` → ${s.mobPct}%` : ''}`]], d: 'Скільки людей можна призвати: відсоток населення за законом про призов (0–25%, «Військо → Армія»). Що вищий призов, то менше людей на заводах і в містах.' }; },
  infrastructure: (s) => ({ r: [['Рівень', nf(s.infrastructure, 1) + ' з 100']], d: 'Впливає на швидкість будівництва та постачання військ.' }),
  warSupport: (s) => brkInfo('war', [['Значення', nf(s.warSupport, 1) + '%'], ['Рівень', lvl(s.warSupport)]], 'Наскільки населення готове до війни.'),
  stability: (s) => brkInfo('stability', [['Значення', nf(s.stability, 1) + '%'], ['Рівень', lvl(s.stability)]], 'Стабільність щодоби тягнеться до цілі. Низька стабільність — протести, бунти, перевороти.'),
  happy: (s) => brkInfo('happy', [['Значення', nf(s.happy == null ? 50 : s.happy, 1) + '%'], ['Рівень', lvl(s.happy == null ? 50 : s.happy)]], 'Наскільки люди задоволені життям. Складається з настрою міст, життя на селі й ваших законів. Впливає на стабільність, підтримку влади й війни, ріст ВВП, науку, виробництво, народжуваність, злочинність, протести, вибори й міграцію.'),
  presidentSupport: (s) => brkInfo('pres', [['Значення', nf(s.presidentSupport, 1) + '%'], ['Рівень', lvl(s.presidentSupport)]], 'Підтримка вашого правління серед населення. Тягнеться до стабільності плюс бонуси.'),
};
// розклад числа на складники (ВВП → ріст, казна → баланс за добу) підключається нижче
// розклад числа на складники (дані з /api/breakdown, підвантажуються при відкритті вкладки)
const sgn = (v, d = 1) => (v > 0 ? '+' : v < 0 ? '−' : '') + nf(Math.abs(v), d);
function brkInfo(key, rows, d) {
  const B = window.BRK && window.BRK[key]; if (!B) return { r: rows, d };
  const pct = key === 'growth', it = B.items.filter(([, v]) => Math.abs(v) > (pct ? 1e-5 : 0.05)).map(([n, v]) => [n, pct ? sgn(v * 100, 2) + '%' : key === 'money' ? sgn(v, 0) + ' $' : sgn(v)]);
  const head = key === 'stability' || key === 'happy' ? [['Ціль, до якої тягнеться', nf(B.target, 1) + '%']] : key === 'war' ? [['Ціль', nf(B.target, 1) + '%']] : key === 'growth' ? [['Ріст ВВП за рік', sgn(B.total * 100, 2) + '%']] : key === 'money' ? [['Разом за добу', sgn(B.total, 0) + ' $']] : [];
  return { r: [...rows, ...head, ['— з чого складається —', ''], ...it, ...(B.daily && B.daily.length ? [['— щодоби окремо —', ''], ...B.daily.map(([n, v]) => [n, sgn(v, 2)])] : [])], d };
}
{ const g0 = INFO.gdp, t0 = INFO.treasury; INFO.gdp = (s) => { const o = g0(s); return brkInfo('growth', o.r, o.d); }; INFO.treasury = (s) => { const o = t0(s); return brkInfo('money', o.r, o.d); }; }
const resInfo = (st, k) => { const r = st.resources[k], c = consume(st, k), b = r.prod - c, m = RESM[k], pen = Math.round(Math.max(0, (st.mobCur || 0) - 2) * 1.2 * 10) / 10;
  return { t: m.n, r: [['Запас', nf(r.stock)], ['Видобуток за добу', nf(r.prod)], ['Споживання за добу', nf(c)], ['Баланс за добу', (b > 0 ? '+' : '') + nf(b)], ['Джерело', SRC[k]]].concat(pen && k !== 'fuel' ? [['Штраф мобілізації', '−' + pen + '% видобутку']] : []).concat(b < 0 && r.stock > 0 ? [['Запасу вистачить на', nf(r.stock / -b, 1) + ' діб']] : []), d: m.d + (b < 0 ? ' Дефіцит сповільнить виробництво.' : '') }; };
bindInfo($('#v-me'), (el) => {
  const k = el.dataset.k, kind = el.dataset.kind, st = me.country && me.country.stats; if (!st) return null;
  if (kind === 'stat') return INFO[k] ? { t: (STAT[k] || {}).n, ...INFO[k](st) } : null;
  if (kind === 'res') return resInfo(st, k); if (kind === 'prod') return prodInfo(st, k); if (kind === 'fac') return facInfo(+k); if (kind === 'unit') return unitInfo(+k); return null;
});

async function renderMe() {
  const v = $('#v-me'); hideInfo(); if (me.country) api('breakdown').then((b) => { window.BRK = b; }).catch(() => {});
  if (!me.country) { v.innerHTML = '<h2>Моя держава</h2><p class="muted">Спочатку заснуй державу на мапі.</p>'; return; }
  const c = me.country;
  v.innerHTML = `<h2><span class="sw" style="background:${esc(c.color)}"></span>${esc(c.name)}</h2><div class="mgroups">${MGROUPS.map((g) => `<button data-g="${g.subs[0][0]}" class="${groupOf(meSub) === g ? 'on' : ''}">${ico(g.ic, 26)}<span>${g.t}</span></button>`).join('')}</div><div class="subtabs">${groupOf(meSub).subs.map(([id, t]) => `<button data-s="${id}" class="${id === meSub ? 'on' : ''}">${t}</button>`).join('')}</div><div id="subBody"></div>`;
  v.querySelectorAll('.subtabs button').forEach((b) => b.onclick = () => { meSub = b.dataset.s; renderMe(); });
  v.querySelectorAll('.mgroups button').forEach((b) => b.onclick = () => { const g = groupOf(b.dataset.g); if (groupOf(meSub) !== g) { meSub = (window.lastSub && window.lastSub[g.t]) || b.dataset.g; renderMe(); } });
  window.lastSub = window.lastSub || {}; window.lastSub[groupOf(meSub).t] = meSub;
  const fn = { fin: (b) => renderFin(b), order: (b) => renderOrder(b), demo: (b) => renderDemo(b), cyber: (b) => renderCyber(b), doc: (b) => renderDoc(b), occ: (b) => renderOcc(b), merc: (b) => renderMerc(b), vol: (b) => renderVol(b), sep: (b) => renderSep(b), media: (b) => renderMedia(b), fcourt: (b) => renderForeignCourts(b), tmpl: (b) => renderTmpl(b), mafia: (b) => renderMafia(b), design: (b) => (window.renderDesign21 ? renderDesign21(b) : null), gear: (b) => renderGear(b), defco: (b) => renderDefco(b), court: (b) => renderCourt(b), cities: (b) => renderCities(b), rel: (b) => renderRel(b), mega: (b) => renderMega(b), invest: (b) => renderInvest(b), env: (b) => renderEnv(b), prov: (b) => renderProv(b), gov: (b) => renderGov(b), biz: (b) => renderBiz(b), nat: (b) => renderNations(b), eco: renderEco, laws: renderLaws, res: renderRes, prod: renderProd, tech: renderTech, army: renderArmy, bloc: renderBloc, intel: renderIntel, dec: renderDec, pol: renderPol }[meSub] || renderEco;
  try { await fn($('#subBody')); } catch (e) { $('#subBody').innerHTML = `<p class="err">${esc(e.message)}</p>`; }
}
const statTable = (keys, st) => `<div class="card"><table>${keys.map((k) => `<tr data-k="${k}" data-kind="stat"><td>${STAT[k].n}</td><td class="r"><b>${fmt(k, st[k])}</b></td></tr>`).join('')}</table></div><div class="hint">Наведи курсор на рядок, щоб побачити точні цифри.</div>`;
const AL = { mil: 'Армія', social: 'Соціальна сфера', edu: 'Освіта та наука', infra: 'Інфраструктура', admin: 'Управління', sec: 'Безпека (поліція, спецслужби)' };
const ALD = { mil: 'Мораль і постачання військ', social: 'Стабільність і підтримка влади', edu: 'Швидкість досліджень і ріст ВВП', infra: 'Інфраструктура: швидше будівництво й рух', admin: 'Стабільність і порядок', sec: 'Висока → вища стабільність і краща контррозвідка, низька → хаос' };
function spark(rows, key) {
  if (rows.length < 2) return '<p class="muted">Графік з’явиться, коли мине кілька ігрових діб.</p>';
  const vals = rows.map((r) => r[key]), mn = Math.min(...vals), mx = Math.max(...vals), W = 560, H = 120, pts = vals.map((x, i) => `${(i / (vals.length - 1) * W).toFixed(1)},${(H - 8 - (mx === mn ? .5 : (x - mn) / (mx - mn)) * (H - 16)).toFixed(1)}`).join(' ');
  return `<svg viewBox="0 0 ${W} ${H}" style="width:100%;max-width:${W}px;height:auto"><polyline fill="none" stroke="var(--accent)" stroke-width="2" points="${pts}"/></svg><div class="muted" style="font-size:13px">доба ${rows[0].day} → ${rows[rows.length - 1].day} · від ${short(mn)} до ${short(mx)}</div>`;
}
// стовпчиковий графік населення: один стовпчик на кожне 1 число місяця
function popChart(months) {
  if (!months.length) return '<p class="muted">Дані з’являться з початком наступного місяця.</p>';
  const vals = months.map((m) => m.now || m.pop), mx = Math.max(...vals), mn = Math.min(...vals), top = mx * 1.08, lo = Math.max(0, mn - (mx - mn) * 1.5 - mx * 0.02), W = 640, H = 230, L = 58, B = 46, T = 14, cw = (W - L - 8) / Math.max(months.length, 6), bw = Math.min(46, cw * 0.62);
  const yv = (v) => T + (H - T - B) * (1 - (v - lo) / Math.max(1, top - lo)), ticks = [0, 1, 2, 3, 4].map((k) => lo + (top - lo) * k / 4);
  return `<svg viewBox="0 0 ${W} ${H}" class="popchart" style="width:100%;height:auto">${ticks.map((t) => `<line x1="${L}" x2="${W - 4}" y1="${yv(t).toFixed(1)}" y2="${yv(t).toFixed(1)}" stroke="var(--line)" stroke-width="1"/><text x="${L - 6}" y="${(yv(t) + 4).toFixed(1)}" text-anchor="end" font-size="11" fill="var(--mute)">${short(t)}</text>`).join('')}
    ${months.map((m, i) => { const v = m.now || m.pop, x = L + cw * i + (cw - bw) / 2, y = yv(v), prev = i ? (months[i - 1].now || months[i - 1].pop) : v, up = v >= prev; return `<g><rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${bw.toFixed(1)}" height="${(H - B - y).toFixed(1)}" rx="3" fill="${m.now ? 'var(--accent2, #a78bfa)' : 'var(--accent)'}" opacity="${m.now ? .65 : .95}"><title>${m.label}: ${exact(Math.round(v))}${m.now ? ' (поточний місяць)' : ''}</title></rect>${i ? `<text x="${(x + bw / 2).toFixed(1)}" y="${(y - 4).toFixed(1)}" text-anchor="middle" font-size="10" fill="${up ? 'var(--pos, #4ade80)' : 'var(--neg, #f87171)'}">${up ? '▲' : '▼'}</text>` : ''}<text transform="translate(${(x + bw / 2).toFixed(1)},${H - B + 12}) rotate(40)" font-size="10.5" fill="var(--mute)">${m.label}${m.now ? ' •' : ''}</text></g>`; }).join('')}</svg>`;
}
function foodCard(F) {
  const net = F.net, hung = F.hunger > 0.02;
  return `<div class="card pad ${hung ? 'warn' : ''}"><h3>${icon('food')} Їжа</h3>
    <div class="stat-grid four"><div><span class="muted">Запас</span><b>${nf(F.stock, 1)}</b></div><div><span class="muted">Врожай / доба</span><b>${nf(F.prod, 2)}</b></div><div><span class="muted">Споживання / доба</span><b>${nf(F.cons, 2)}</b></div><div><span class="muted">Баланс</span><b class="${net < 0 ? 'neg' : 'pos'}">${net > 0 ? '+' : ''}${nf(net, 2)}</b></div></div>
    <p style="margin:8px 0">${hung ? `<b class="neg">Голод!</b> Не вистачає ${Math.round(F.hunger * 100)}% потреби: падають стабільність, підтримка й населення.` : net < 0 ? `Їжі вистачить ще на <b>${nf(F.daysLeft, 0)}</b> діб. Будуй ферми або купуй їжу.` : 'Їжі вистачає.'}</p>
    <p class="hint" style="margin:0">Ферм: <b>${F.farms}</b> (рівнів ${F.farmLevels}) — кожен рівень дає ~1 од./добу, біля річки +25%. Земля дає ще ${nf(F.land, 2)}. Населення ${short(F.population)} їсть ${nf(F.cons, 2)} (міста — більше). Коли міста ростуть, потрібно більше ферм. Реформа сільгоспу: +${Math.round(F.mul * 100)}%.</p>
    <div class="row" style="margin-top:10px"><button class="sm" id="fbuild">Збудувати ферму</button><input id="fqty" type="number" value="10" min="1" max="200" style="width:80px"><button class="ghost sm" id="fbuyn" title="Термінова закупівля за подвійною ціною, доставка відразу">Купити терміново (${short(F.price * 2)} $/од.)</button><button class="ghost sm" id="fmarket">Купити на ринку (дешевше)</button>${F.mul < 1 ? `<button class="ghost sm" id="freform">Реформа сільгоспу +20% (${short(F.reformCost)} $)</button>` : ''}</div></div>`;
}
async function renderEco(b) {
  const st = me.country.stats, [hist, F, VI] = await Promise.all([api('econ/history').then((r) => r.rows), api('food/info'), api('vassal/info').catch(() => null)]); let al = { ...st.alloc };
  b.innerHTML = statTable(ECO_KEYS, st) + `<div class="card"><table><tr data-k="manpower" data-kind="stat"><td>Людські ресурси</td><td class="r"><b>${exact(me.country.manpower.free)} вільних з ${exact(me.country.manpower.total)}</b></td></tr></table></div>` + `<div class="card pad"><h3>Розподіл бюджету</h3><p class="hint" style="margin-top:0">Сума має дорівнювати 100%.</p>${Object.keys(AL).map((k) => `<div class="row" style="margin:8px 0"><div style="width:190px"><b>${AL[k]}</b><div class="muted" style="font-size:13px">${ALD[k]}</div></div><input type="range" min="0" max="100" value="${al[k]}" data-a="${k}" class="grow"><b style="width:44px;text-align:right" id="av-${k}">${al[k]}%</b></div>`).join('')}
    <div class="row"><b id="asum"></b><button id="asave">Зберегти розподіл</button></div></div><div class="card pad"><h3>ВВП за останній час</h3>${spark(hist, 'gdp')}</div>`;
  if (VI && (VI.dailyIn > 0 || VI.master)) b.insertAdjacentHTML('afterbegin', `<div class="card pad">${VI.dailyIn > 0 ? `<b>Податок з маріонеток і васалів:</b> ≈ <b class="pos">+${exact(VI.dailyIn)} $/добу</b> — щодня надходить прямо в казну (${VI.vassals.map((v) => esc(v.name) + ' ' + short(v.daily)).join(', ')}).` : ''}${VI.master ? `<b>Податок сюзерену ${esc(VI.master.name)}:</b> <b class="neg">−${exact(VI.master.daily)} $/добу</b> (з казни).` : ''}</div>`);
  b.insertAdjacentHTML('afterbegin', `<div class="grid2">${foodCard(F)}<div class="card pad"><h3>Населення по місяцях</h3>${popChart(F.months)}<div class="muted" style="font-size:13px">Один стовпчик — населення на 1 число місяця (останній — зараз). Межа населення зараз: ${short(F.popCap)}.</div></div></div>`);
  $('#fbuild').onclick = () => startPlace('farm'); $('#fmarket').onclick = () => { MK.res = 'food'; MK.side = 'buy'; MK.price = null; showTab('market'); };
  $('#fbuyn').onclick = () => act(async () => { const r = await api('food/buy', { amount: +$('#fqty').value }); toast(`Їжу закуплено: ${exact(r.cost)} $`); await refreshMe(); renderMe(); });
  { const fr = $('#freform'); if (fr) fr.onclick = () => act(async () => { await api('food/farm', {}); await refreshMe(); renderMe(); }, 'Реформу проведено'); }
  const upd = () => { const s = Object.values(al).reduce((a, x) => a + x, 0); $('#asum').textContent = `Разом: ${s}%`; $('#asum').className = s === 100 ? 'pos' : 'neg'; $('#asave').disabled = s !== 100; };
  b.querySelectorAll('[data-a]').forEach((i) => i.oninput = () => { al[i.dataset.a] = +i.value; $('#av-' + i.dataset.a).textContent = i.value + '%'; upd(); }); upd();
  $('#asave').onclick = () => act(async () => { await api('econ/alloc', { alloc: al }); await refreshMe(); }, 'Розподіл збережено');
  await renderCur(b);
}

const LAWN = { inc: ['Податок на доходи', 'Податок із зарплат і доходів громадян. Найсильніше б’є по стабільності.', 60], biz: ['Податок на бізнес', 'Податок на прибуток підприємств. Найсильніше гальмує ріст ВВП.', 60], land: ['Податок на землю', 'Платять власники землі. Невеликий вплив на ріст, помірний на стабільність.', 40], vat: ['ПДВ', 'Податок на споживання. Найбільше наповнює бюджет, помірно шкодить зростанню.', 40] };
async function renderLaws(b) {
  const st = me.country.stats, L = { ...st.laws }; let seq = 0;
  b.innerHTML = `<div class="card pad"><h3>Податки та закони</h3><p class="hint" style="margin-top:0">Зміни діють одразу після збереження. Надто високі ставки (понад 35%) призводять до ухилення від податків, а відсотки за боргом і далі йдуть з бюджету.</p>
    ${Object.keys(LAWN).map((k) => `<div class="row" style="margin:10px 0"><div style="width:240px"><b>${LAWN[k][0]}</b><div class="muted" style="font-size:13px">${LAWN[k][1]}</div></div><input type="range" min="0" max="${LAWN[k][2]}" step="0.5" value="${L[k]}" data-l="${k}" class="grow"><b style="width:56px;text-align:right" id="lv-${k}">${L[k]}%</b></div>`).join('')}
    <div id="lprev" class="card pad" style="margin:10px 0 0"></div><div class="row" style="margin-top:10px"><button id="lsave">Зберегти закони</button><button class="ghost" id="lreset">Типові значення</button></div></div>`;
  const prev = async () => { const my = ++seq; const m = await api('econ/laws-preview', { laws: L }).catch(() => null); if (!m || my !== seq) return; const cur = st.budget, d = m.budget - cur, sg = m.growth * 100, ss = m.stability;
    if (!$('#lprev')) return; $('#lprev').innerHTML = `<div class="row" style="gap:24px;flex-wrap:wrap"><div>Доходи бюджету<br><b>${short(m.budget)} $ / рік</b> <span class="${d >= 0 ? 'pos' : 'neg'}">(${d >= 0 ? '+' : '−'}${short(Math.abs(d))})</span></div><div>Податкове навантаження<br><b>${nf(m.rate * 100, 1)}% ВВП</b></div><div>Вплив на ріст ВВП<br><b class="${sg >= 0 ? 'pos' : 'neg'}">${sg >= 0 ? '+' : ''}${nf(sg, 1)}% / рік</b></div><div>Вплив на стабільність<br><b class="${ss >= 0 ? 'pos' : 'neg'}">${ss >= 0 ? '+' : ''}${nf(ss, 1)}</b></div></div>`; };
  b.querySelectorAll('[data-l]').forEach((i) => i.oninput = () => { L[i.dataset.l] = +i.value; $('#lv-' + i.dataset.l).textContent = i.value + '%'; prev(); });
  $('#lreset').onclick = () => { Object.assign(L, { inc: 12, biz: 18, land: 10, vat: 12 }); b.querySelectorAll('[data-l]').forEach((i) => { i.value = L[i.dataset.l]; $('#lv-' + i.dataset.l).textContent = i.value + '%'; }); prev(); };
  $('#lsave').onclick = () => act(async () => { await api('econ/laws', { laws: L }); await refreshMe(); }, 'Закони збережено'); prev();
}
async function renderRes(b) {
  const st = me.country.stats, F = await api('fac/list'), fl = st.flow || {}, cnt = (k) => F.facilities.filter((f) => f.kind === k).reduce((n, f) => n + f.level, 0), pen = Math.round(Math.max(0, (st.mobCur || 0) - 2) * 1.2 * 10) / 10;
  const node = (title, sub) => `<div class="cnode"><b>${title}</b><div class="muted">${sub}</div></div>`, arrow = '<div class="carrow">→</div>';
  const net = (k) => { const d = (fl[k] ? fl[k].prod - fl[k].cons : st.resources[k].prod - consume(st, k)); return (d > 0 ? '+' : '') + nf(d); };
  b.innerHTML = `${pen ? `<div class="card pad warn">Призов ${st.mobCur}% населення забирає людей із шахт і заводів: видобуток і виробництво менші на <b>${pen}%</b>. Змінити — «Військо → Армія».</div>` : ''}
  <div class="card"><table><tr><th></th><th class="r">Запас</th><th class="r">Видобуток</th><th class="r">Споживання</th><th class="r">Баланс</th><th>Звідки береться</th></tr>${Object.keys(RESM).map((k) => { const r = st.resources[k], cs = consume(st, k), d = r.prod - cs; return `<tr data-k="${k}" data-kind="res"><td>${icon(k)}${RESM[k].n}</td><td class="r">${nf(r.stock)}</td><td class="r">${nf(r.prod)}</td><td class="r">${nf(cs)}</td><td class="r"><b class="${d < 0 ? 'neg' : d > 0 ? 'pos' : ''}">${d > 0 ? '+' : ''}${nf(d)}</b></td><td class="muted" style="font-size:14px">${SRC[k]}</td></tr>`; }).join('')}</table></div>
  <div class="card pad"><h3>Ланцюжки виробництва</h3><p class="hint" style="margin-top:0">Кожен ресурс має свою будівлю. Лише паливо й сталь залежать від інших ресурсів, решта видобувається самостійно.</p>
    <div class="chain">${node('Нафтокачка ×' + cnt('oil_pump'), 'нафта ' + net('oil') + ' / доба')}${arrow}${node('НПЗ ×' + cnt('refinery'), 'бере 0,5 нафти, дає 0,7 палива на рівень')}${arrow}${node('Паливо', net('fuel') + ' / доба')}${arrow}${node('Сталеливарня ×' + cnt('steel_mill'), 'бере 0,2 палива, дає сталь')}${arrow}${node('Сталь', net('steel') + ' / доба')}</div>
    <div class="chain" style="margin-top:10px">${[['food', 'farm', 'Ферма'], ['aluminium', 'bauxite_mine', 'Бокситова шахта'], ['chromium', 'chrome_mine', 'Хромова шахта'], ['tungsten', 'tungsten_mine', 'Вольфрамова шахта'], ['rubber', 'rubber_plantation', 'Каучукова плантація'], ['cotton', 'cotton_plantation', 'Бавовняна плантація']].map(([r, k, n]) => node(n + ' ×' + cnt(k), RESM[r].n.toLowerCase() + ' ' + net(r) + ' / доба')).join('')}</div>
    <div class="chain" style="margin-top:10px">${node('Електростанція ×' + cnt('power_plant'), 'бере 0,25 палива, дає 1,5 енергії')}${node('ГЕС ×' + cnt('hydro_plant'), '1,2 енергії без палива')}${arrow}${node('Електроенергія', net('power') + ' / доба')}</div>
    <div class="chain" style="margin-top:10px">${node('Бавовна', net('cotton') + ' / доба')}${arrow}${node('Цивільні фабрики', 'лінії одягу, ліків, товарів')}${arrow}${node('Одяг · Ліки · Товари', `${net('clothing')} · ${net('medicine')} · ${net('goods')} / доба`)}</div>
    <div class="row" style="margin-top:12px"><button class="sm" id="toprod">Побудувати нові об’єкти</button><button class="ghost sm" id="tomap">Показати родовища на мапі</button></div></div>
  <div class="hint">Видобуток і споживання вказані за ігрову добу. Наведи курсор на рядок, щоб побачити подробиці. Якщо запас вичерпано, будівництво та виробництво сповільнюються.</div>`;
  $('#toprod').onclick = () => { meSub = 'prod'; renderMe(); }; $('#tomap').onclick = () => { showTab('map'); setLayer('resources'); };
}
async function renderPol(b) {
  const [V, S] = await Promise.all([api('vassal/info'), api('sanction/list')]), kn = (k) => (k === 'puppet' ? 'маріонетка' : 'васал');
  b.innerHTML = statTable(POL_KEYS, me.country.stats) + `<div class="card pad"><h3>Сюзерен і васали</h3>
    ${V.master ? `<div class="warn">Ти — <b>${kn(V.master.kind)}</b> держави <b>${esc(V.master.name)}</b>. Податок сюзерену щодня: ≈ ${exact(V.master.daily)} $ (з казни). ${V.master.kind === 'puppet' ? 'Маріонетка не може воювати й укладати угоди без сюзерена.' : ''}</div>${V.master.kind === 'puppet' ? '<div class="hint">Маріонетка не може проголосити незалежність: її може відпустити лише сюзерен. Вона має колір сюзерена на мапі й входить до його альянсу.</div>' : '<button class="danger sm" id="vind" style="margin-top:8px">Проголосити незалежність</button>'}` : '<div class="muted">У тебе немає сюзерена.</div>'}
    <h4 style="margin:14px 0 6px">Мої васали</h4>${V.vassals.length ? `<table><tr><th>Держава</th><th>Статус</th><th class="r">Податок у казну / доба</th><th class="r">За ${V.payDays} діб</th><th></th></tr>${V.vassals.map((v) => `<tr><td>${esc(v.name)}</td><td>${kn(v.kind)}</td><td class="r">≈ ${exact(v.daily)} $</td><td class="r">≈ ${exact(v.tribute)} $</td><td class="r"><button class="ghost sm" data-rel="${v.id}">Відпустити</button></td></tr>`).join('')}</table>` : '<div class="muted">Васалів немає. Запропонуй це іншій державі у вікні держави (вкладка «Дипломатія») або вимагай як умову миру після війни.</div>'}</div>
  <div class="card pad"><h3>Санкції</h3><div>Накладені мною: ${S.byMe.length ? S.byMe.map((id) => esc((countries[id] || {}).name || '#' + id)).join(', ') : 'немає'}</div><div>Накладені на мене: ${S.onMe.length ? S.onMe.map((id) => esc((countries[id] || {}).name || '#' + id)).join(', ') : 'немає'}</div><p class="hint">Санкції сповільнюють ріст ВВП держави-цілі. Усі, хто торгує з нею, втрачають відносини з тим, хто наклав санкції. Накласти або зняти їх можна у вікні держави.</p></div>
  <div class="hint">Політичні рішення з’являються як події: відповідай на них вчасно, інакше спрацює варіант за замовчуванням.</div>`;
  await renderIdeoFlag(b);
  const vi = $('#vind'); if (vi) vi.onclick = () => { if (confirm('Проголосити незалежність? Відносини із сюзереном впадуть, бот-сюзерен може почати війну.')) act(async () => { await api('vassal/independence', {}); await refreshMe(); }, 'Незалежність проголошено'); };
  b.querySelectorAll('[data-rel]').forEach((x) => x.onclick = () => { if (confirm('Відпустити васала на незалежність?')) act(async () => { await api('vassal/release', { target: +x.dataset.rel }); await refreshMe(); }, 'Васала відпущено'); });
}

async function renderCur(b) {
  const d = await api('cur/state'), el = document.createElement('div'), cl = d.infl > 15 ? 'neg' : d.infl > 6 ? 'warn' : 'pos';
  el.className = 'card pad'; el.innerHTML = `<h3>Валюта й інфляція</h3>
  <table><tr><td>Інфляція (за рік)</td><td class="r"><b class="${cl}">${nf(d.infl, 1)}%</b> <span class="muted">до ${nf(d.target, 1)}%</span></td></tr>
  <tr><td>Індекс цін (з початку гри)</td><td class="r"><b>×${nf(d.P, 2)}</b> <span class="muted">світ ×${nf(d.worldP, 2)}</span></td></tr>
  <tr><td>Курс національної валюти</td><td class="r"><b>${nf(d.fx, 2)}</b> <span class="muted">1,00 = парітет зі світом</span></td></tr>
  <tr><td>Грошова маса / потрібна</td><td class="r"><b>${short(d.M)}</b> / ${short(d.need)} <span class="${d.excess > 0.1 ? 'neg' : 'muted'}">(${d.excess >= 0 ? '+' : ''}${nf(d.excess * 100, 0)}%)</span></td></tr>
  <tr><td>Надруковано за весь час</td><td class="r">${short(d.printed)} $</td></tr></table>
  <div class="row" style="margin-top:10px"><div class="grow"><label for="cr">Облікова ставка: <b id="crv">${nf(d.rate, 1)}</b>%</label><input id="cr" type="range" min="0" max="40" step="0.5" value="${d.rate}"></div><button class="sm" id="crs" style="align-self:end">Встановити</button></div>
  <label style="margin-top:8px"><input type="checkbox" id="ca" style="width:auto" ${d.auto ? 'checked' : ''}> Покривати дефіцит бюджету друком грошей (інакше росте борг)</label>
  <div class="row" style="margin-top:10px"><div class="grow"><label for="cp">Надрукувати гроші, $ <span class="muted">· не більше ${short(d.maxPrint)}</span></label><input id="cp" type="number" min="0" placeholder="сума"></div><button class="sm" id="cps" style="align-self:end">Надрукувати</button></div>
  <p class="hint">Друк грошей одразу поповнює казну, але збільшує грошову масу відносно ВВП: зростає інфляція, падає курс, стабільність і ріст. Висока облікова ставка гальмує інфляцію, але сповільнює економіку й здорожчує борг. Інфляція понад 100% — гіперінфляція: можливі бунти й громадянська війна.</p>`;
  b.appendChild(el); $('#cr').oninput = () => $('#crv').textContent = nf(+$('#cr').value, 1);
  $('#crs').onclick = () => act(async () => { await api('cur/rate', { rate: +$('#cr').value }); renderMe(); }, 'Ставку встановлено');
  $('#ca').onchange = () => act(async () => { await api('cur/auto', { on: $('#ca').checked }); renderMe(); });
  $('#cps').onclick = () => { const a = +$('#cp').value; if (!(a > 0)) return toast('Вкажи суму', true); if (confirm('Надрукувати ' + exact(a) + ' $? Це підвищить інфляцію.')) act(async () => { await api('cur/print', { amount: a }); await refreshMe(); }, 'Гроші надруковано'); };
}

const DECL = { stab: ['Стабільність', 1, ''], pres: ['Підтримка президента', 1, ''], war: ['Підтримка війни', 1, ''], morale: ['Мораль армії', 1, ''], growth: ['Ріст ВВП за рік', 100, '%'], infl: ['Інфляція', 1, ' п.п.'], milprod: ['Військове виробництво', 100, '%'], research: ['Швидкість досліджень', 100, '%'], construction: ['Швидкість будівництва', 100, '%'] };
async function renderDec(b) {
  const d = await api('dec/list'), fx = (o) => Object.entries(o).map(([k, v]) => { const [n, m, u] = DECL[k] || [k, 1, '']; const x = Math.round(v * m * 10) / 10; return `<span class="${(k === 'infl' ? v < 0 : v > 0) ? 'pos' : 'neg'}">${n} ${x > 0 ? '+' : '−'}${Math.abs(x)}${u}</span>`; }).join(' · ');
  b.innerHTML = `<p class="hint" style="margin-top:0">Національні рішення діють певний час і коштують частку ВВП. Одночасно діє не більше ${d.slots} (зараз ${d.used}). Після завершення потрібна пауза.</p><div class="grid g2">${d.items.map((x) => `<div class="card pad"><h3>${esc(x.n)}</h3><div class="muted" style="margin-bottom:6px">${esc(x.d)}</div><div style="font-size:14px;margin-bottom:8px">${fx(x.fx)}</div>
    <div class="muted" style="font-size:13px">Тривалість: ${x.dur} діб · вартість: ${x.cost ? exact(x.cost) + ' $' : 'безкоштовно'}${x.needWar ? ' · лише під час війни' : ''}</div>
    <div class="row" style="margin-top:8px">${x.state === 'active' ? `<span class="badge">діє ще ${Math.ceil(x.left)} діб</span><button class="ghost sm" data-ds="${x.id}">Скасувати</button>` : x.state === 'cooldown' ? `<span class="muted">Пауза ще ${Math.ceil(x.coolLeft)} діб</span>` : x.state === 'locked' ? '<span class="muted">Недоступне в мирний час</span>' : `<button class="sm" data-dg="${x.id}">Запровадити</button>`}</div></div>`).join('')}</div>`;
  b.querySelectorAll('[data-dg]').forEach((x) => x.onclick = () => act(async () => { await api('dec/start', { id: x.dataset.dg }); await refreshMe(); }, 'Рішення запроваджено'));
  b.querySelectorAll('[data-ds]').forEach((x) => x.onclick = () => { if (confirm('Скасувати рішення? Витрачені гроші не повертаються, далі буде пауза.')) act(async () => { await api('dec/stop', { id: x.dataset.ds }); await refreshMe(); }); });
}
