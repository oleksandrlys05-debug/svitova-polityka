// наказ із підтвердженням: вхід на чужу територію без права проходу оголошує війну
async function orderApi(path, body) {
  let r; try { r = await api(path, body); } catch (e) { if (String(e.message).startsWith('CONFIRM_WAR:') && confirm(e.message.slice(12))) return api(path, { ...body, force: true }); throw e; }
  if (r && r.failed && String(r.firstError).startsWith('CONFIRM_WAR:') && confirm(r.firstError.slice(12))) return api(path, { ...body, force: true });
  return r;
}
// Мапа: шари (держави, дипломатія, альянси, ресурси, повітряний простір, мої об'єкти), підрозділи, режими (заснування, наказ, розширення, розміщення)
let land, owners = new Int32Array(0), countries = {}, off, borders = [], borderPath = null, landPath, landReady = false, foreignCv = null, regionPaths = [];
const cv = $('#cv'), cx = cv.getContext('2d');
let view = { s: 1, x: 0, y: 0, fs: 1 }, mode = { kind: 'idle' }, preview = [], pending = null, hoverT = null, seq = 0;
let founding = { name: '', color: '#c0392b' }, layer = 'owners', relColors = {}, myUnits = [], foeUnits = [], selUnit = null, card = null;
let visUnits = [], occRuns = [], occCv = null, selSet = new Set(), blocLabels = [], selVis = null, boxSel = null, lineDrag = null;
let resSel = 'all', deposits = null, blocColor = {}, blocs = [], warLines = [], airZones = [], myFacs = [], FDEFS = {}, FGROUPS = {}, selFac = null, placeHover = null, alliedLines = [];
const hexRgb = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
const mix = (h, k) => { const f = (v) => Math.round(v + (255 - v) * k); return '#' + hexRgb(h).map((v) => f(v).toString(16).padStart(2, '0')).join(''); };
const MAPC = { oil: '#101012', aluminium: '#3b82c4', chromium: '#12a39a', tungsten: '#d29a1a', rubber: '#2f9e44', cotton: '#e8dcb5' };
const BLOCS = ['#c0392b', '#2e8b57', '#3a6ea5', '#d4a017', '#8e44ad', '#16a085', '#d35400', '#7f8c8d'];
const LAYERS = [['owners', 'Держави'], ['nations', 'Нації (народи)'], ['diplo', 'Дипломатія (відносно мене)'], ['alliances', 'Альянси'], ['resources', 'Ресурси (родовища)'], ['air', 'Повітряний простір'], ['drones', 'Безпілотники та ППО'], ['facilities', 'Мої об’єкти'], ['logistics', 'Логістика'], ['supply', 'Постачання'], ['weather', 'Погода й сезон'], ['terrain', 'Ландшафт і укріплення'], ['religion', 'Релігії'], ['provinces', 'Області'], ['biomes', 'Біоми й лиха']];
const mixDark = (h, k) => '#' + hexRgb(h).map((v) => Math.round(v * (1 - k) + 24 * k).toString(16).padStart(2, '0')).join('');
const colorFor = (cid) => {
  const c = countries[cid]; if (!c) return null; const my = me && me.country ? me.country.id : 0;
  if (layer === 'owners') return c.puppetOf && countries[c.puppetOf] ? countries[c.puppetOf].color : c.color;
  if (layer === 'diplo') return cid === my ? '#2f5d8a' : relColors[cid] || '#c9ced4';
  if (layer === 'alliances') return blocColor[cid] || (cid === my ? '#bcd3ea' : '#d5d9de');
  if (layer === 'air' || layer === 'drones') return mixDark(c.color, 0.62);
  if (layer === 'supply') return cid === my ? '#3a3f4a' : mixDark(c.color, 0.75);
  if (layer === 'logistics') return cid === my ? mixDark(c.color, 0.35) : mixDark(c.color, 0.72);
  return cid === my ? '#3c4250' : '#2c303a';
};

async function loadMap() {
  if (!land) {
    land = await api('land'); landPath = new Path2D();
    land.arr = new Uint8Array(land.gw * land.gh); { let k = 0, v = 0; for (const r of land.rle) { if (v) land.arr.fill(1, k, k + r); k += r; v ^= 1; } }
    for (const p of land.polys) { landPath.moveTo(p[0], p[1]); for (let i = 2; i < p.length; i += 2) landPath.lineTo(p[i], p[i + 1]); landPath.closePath(); }
    off = document.createElement('canvas'); off.width = land.gw; off.height = land.gh; landReady = true; fitMap();
    // «закордон» (мапа СРСР): суходіл поза грою — сірим
    if (land.foreign) { land.farr = new Uint8Array(land.gw * land.gh); { let k = 0, v = 0; for (const r of land.foreign) { if (v) land.farr.fill(1, k, k + r); k += r; v ^= 1; } }
      foreignCv = document.createElement('canvas'); foreignCv.width = land.gw; foreignCv.height = land.gh; const fo = foreignCv.getContext('2d'), im = fo.createImageData(land.gw, land.gh); for (let i = 0; i < land.farr.length; i++) if (land.farr[i]) im.data.set([78, 80, 88, 255], i * 4); fo.putImageData(im, 0, 0); }
    // регіони (республіки СРСР): тонкі межі й назви
    regionPaths = (land.regions || []).map((r) => { const p = new Path2D(); for (const poly of r.p) { if (poly.length < 6) continue; p.moveTo(poly[0], poly[1]); for (let i = 2; i < poly.length; i += 2) p.lineTo(poly[i], poly[i + 1]); p.closePath(); } let x0 = 1e9, x1 = -1e9; for (const poly of r.p) for (let i = 0; i < poly.length; i += 2) { x0 = Math.min(x0, poly[i]); x1 = Math.max(x1, poly[i]); } return { path: p, n: r.n, x: r.x, y: r.y, w: x1 - x0 }; }); try { legend(); } catch { /* ще рано */ }
  }
  const d = await api('owners'); countries = {}; d.countries.forEach((c) => countries[c.id] = c);
  owners = new Int32Array(land.gw * land.gh); let k = 0; for (let i = 0; i < d.rle.length; i += 2) for (let j = 0; j < d.rle[i + 1]; j++) owners[k++] = d.rle[i];
  if (layer === 'alliances') await loadAlliances(); if (layer === 'air') await loadAir(); if (layer === 'diplo') await loadDiplo(); if (layer === 'nations') await loadNationsMap();
  await loadOcc(); mapVerSeen++; await refreshLayerData(); computeCountryLabels(); buildFlags(); repaint(); const { gw, gh, cell: C } = land, L = (i) => land.arr[i] === 1; borders = [];
  // кордони: зливаємо сусідні відрізки в довгі лінії й малюємо одним Path2D (у рази швидше)
  { const path = new Path2D(); let n = 0;
    for (let x = 1; x < gw; x++) { let y0 = -1; for (let y = 0; y <= gh; y++) { const i = y * gw + x, a = y < gh ? owners[i - 1] : 0, b = y < gh ? owners[i] : 0, edge = y < gh && a !== b && (a || b) && L(i) && L(i - 1); if (edge && y0 < 0) y0 = y; if (!edge && y0 >= 0) { path.moveTo(x * C, y0 * C); path.lineTo(x * C, y * C); n++; y0 = -1; } } }
    for (let y = 1; y < gh; y++) { let x0 = -1; for (let x = 0; x <= gw; x++) { const i = y * gw + x, a = x < gw ? owners[i - gw] : 0, b = x < gw ? owners[i] : 0, edge = x < gw && a !== b && (a || b) && L(i) && L(i - gw); if (edge && x0 < 0) x0 = x; if (!edge && x0 >= 0) { path.moveTo(x0 * C, y * C); path.lineTo(x * C, y * C); n++; x0 = -1; } } }
    borderPath = path; borders = { length: n }; }
  drawMap();
}
function repaint() {
  if (!land) return; const o = off.getContext('2d'), img = o.createImageData(land.gw, land.gh), cache = {};
  const useFlags = flagMode && flagPix && layer === 'owners';
  if (layer === 'terrain' && window.paintTerrain && paintTerrain(img)) { o.putImageData(img, 0, 0); return; }
  if (layer === 'nations' && natMap) { for (let i = 0; i < natMap.length; i++) { const n = natMap[i]; if (!n) continue; const col = cache['n' + n] || (cache['n' + n] = hexRgb((natList[n] || {}).color || '#888888')); img.data.set([col[0], col[1], col[2], 255], i * 4); } o.putImageData(img, 0, 0); return; }
  if (window.paintLayer16 && paintLayer16(img, layer)) { o.putImageData(img, 0, 0); return; }
  for (let i = 0; i < owners.length; i++) { const id = owners[i]; if (!id) continue; if (useFlags && flagPix[i * 4 + 3]) { img.data.set(flagPix.subarray(i * 4, i * 4 + 4), i * 4); continue; } const col = cache[id] || (cache[id] = colorFor(id)); if (col) { const [r, g, b] = hexRgb(col); img.data.set([r, g, b, 255], i * 4); } }
  o.putImageData(img, 0, 0);
}
async function loadDiplo() { if (!me.country) return; const d = await api('diplo/overview'); relColors = {}; for (const c of d.countries) relColors[c.id] = c.war ? '#c0392b' : c.agreements.some((a) => a.type === 'alliance') ? '#2e8b57' : c.agreements.some((a) => a.type === 'nonaggression') ? '#3a9bb5' : c.agreements.some((a) => a.type === 'trade') ? '#d4a017' : '#c9ced4'; }
async function loadAlliances() {
  const d = await api('map/alliances'), bl = (await api('map/blocs')).blocs; blocColor = {}; blocs = [];
  for (const b of bl) { b.members = b.members.filter((id) => countries[id]); if (!b.members.length) continue; b.members.forEach((id) => blocColor[id] = b.color); blocs.push({ color: b.color, name: b.name, members: b.members.map((id) => countries[id].name) }); }
  warLines = d.wars.filter((w) => countries[w.a] && countries[w.b]); alliedLines = (d.vassals || []).filter((w) => countries[w.a] && countries[w.b]);
  computeBlocLabels(bl.filter((b) => b.members.length));
}
// велика назва альянсу: центр і нахил за формою території учасників
function computeBlocLabels(bl) {
  blocLabels = []; if (!land || !bl.length) return; const m2b = {}; bl.forEach((b, k) => b.members.forEach((id) => m2b[id] = k)); const list = [];
  for (const a of regionMoments((i) => { const k = m2b[owners[i]]; return k === undefined ? null : k; }, 60)) { const b = bl[a.key]; const S = shapeOf(a), ang = Math.max(-0.6, Math.min(0.6, S.ang)), len = 4 * Math.sqrt(S.l1) * land.cell, wid = 4 * Math.sqrt(S.l2) * land.cell, name = b.name.toUpperCase();
    const fs = Math.max(18, Math.min(len / (name.length * 0.75), wid * 0.8 + 18, 110)); list.push({ x: S.mx * land.cell, y: S.my * land.cell, ang, fs, name, color: b.color, n: a.n, bid: b.id, emb: b.emb || 0 }); }
  blocLabels = placeLabels(list, 10);
}
let greyRuns = [];
async function loadOcc() { try { const d = await api('map/occ'); occRuns = d.runs; greyRuns = d.grey || []; } catch { occRuns = []; greyRuns = []; } buildOcc(); }
function buildOcc() {
  if (!land) return; if (!occCv) { occCv = document.createElement('canvas'); occCv.width = land.gw; occCv.height = land.gh; }
  const o = occCv.getContext('2d'); o.clearRect(0, 0, land.gw, land.gh); for (const [by, y, x1, x2] of occRuns) { const c = countries[by]; if (!c) continue; o.fillStyle = c.color; o.fillRect(x1, y, x2 - x1 + 1, 1); } o.fillStyle = '#8b9096'; for (const [y, x1, x2] of greyRuns) o.fillRect(x1, y, x2 - x1 + 1, 1);
}
async function loadAir() { airZones = (await api('map/air')).zones; }
async function loadFacs() { if (!me || !me.country) { myFacs = []; return; } try { const d = await api('fac/list'); myFacs = d.facilities; FDEFS = d.defs; FGROUPS = d.groups; window.FD = d.defs; if (selFac && !myFacs.some((f) => f.id === selFac)) selFac = null; } catch {} }
async function setLayer(l) {
  layer = l;
  if (l === 'diplo') await loadDiplo(); if (l === 'alliances') await loadAlliances(); if (l === 'air') await loadAir(); if (l === 'nations') await loadNationsMap();
  if (l === 'logistics' || l === 'supply') await loadLogi(); if (l === 'weather') await loadWeather(); if (l === 'terrain' && window.loadTerrain) await loadTerrain(); if (window.loadForts) await loadForts(); if (window.loadRoads) await loadRoads();
  if (l === 'drones' || l === 'air') await Promise.all([loadAD(), loadADState(), loadKnown(), loadFlights()]);
  if (l === 'facilities' || l === 'logistics') await loadKnown();
  if (l !== 'drones' && l !== 'air') selLaunch = null; buildSupply();
  if (l === 'resources' && !deposits) deposits = (await api('map/deposits')).deposits;
  if (l === 'resources' || l === 'facilities') await loadFacs();
  if (window.loadLayer16) await loadLayer16(l);
  repaint(); drawMap(); legend(); renderSide();
}
function legend() {
  const el = $('#legend'), row = (c, t) => `<div><span class="sw" style="background:${c}"></span>${t}</div>`; let h = '';
  if (layer === 'diplo') h = [['#2f5d8a', 'Ти'], ['#c0392b', 'Війна'], ['#2e8b57', 'Союз'], ['#3a9bb5', 'Пакт про ненапад'], ['#d4a017', 'Торгівля'], ['#c9ced4', 'Нейтрально']].map(([c, t]) => row(c, t)).join('');
  else if (layer === 'alliances') h = (blocs.map((b) => row(b.color, `<b>${esc(b.name)}</b>: ${esc(b.members.join(', '))}`)).join('') || '<div class="muted">Альянсів ще немає</div>') + row('#d5d9de', 'Без альянсу') + '<div><span style="display:inline-block;width:18px;border-top:2px dashed #c0392b;margin-right:6px;vertical-align:middle"></span>Війна</div>';
  else if (layer === 'resources') h = ['oil', 'aluminium', 'chromium', 'tungsten', 'rubber', 'cotton'].map((r) => row(MAPC[r], RESM[r].n)).join('') + '<div class="muted" style="max-width:200px">Яскравіше — багатше родовище. Сталь і паливо не мають родовищ.</div>';
  else if (layer === 'nations') { const cnt = {}; if (natMap) for (let i = 0; i < natMap.length; i += 7) if (natMap[i]) cnt[natMap[i]] = (cnt[natMap[i]] || 0) + 1; h = Object.entries(cnt).sort((a, b) => b[1] - a[1]).slice(0, 14).map(([n]) => row((natList[n] || {}).color || '#888', `<b>${esc((natList[n] || {}).name || '')}</b>${(natList[n] || {}).homeName ? ` <span class="muted">(${esc(natList[n].homeName)})</span>` : ''}`)).join('') + '<div class="muted" style="max-width:230px">Кольором — народ, що живе на землі (не держава!). Лінії — кордони держав. Порожня земля — ніхто не живе.</div>'; }
  else if (layer === 'air') h = '<div class="muted" style="max-width:220px">Кола — повітряний простір аеродромів. Радіус росте з рівнем аеродрому.</div>';
  else if (layer === 'facilities') { const kinds = [...new Set(myFacs.map((f) => f.kind))]; h = kinds.map((k) => row((FDEFS[k] || {}).color, (FDEFS[k] || {}).n)).join('') || '<div class="muted">Об’єктів немає</div>'; }
  if (layer === 'logistics') h = `<div class="lgrow">${ico('capital', 18)} Столиця — головне джерело постачання</div><div class="lgrow">${ico('depot', 18)} Склад, з’єднаний залізницею</div><div class="lgrow">${ico('depot', 18, '#a35a3a')} Склад без залізниці (лише 55%)</div>` + row('#e5e7eb', 'Залізниця, з’єднана зі столицею') + row('#f59e0b', 'Колія не з’єднана зі столицею') + row('#c0392b', 'Перерізана / під загрозою') + '<div class="muted" style="max-width:250px">Як у HOI4: столиця → залізниця → склади → війська. Будуй склад біля фронту й з’єднай його колією зі столицею (або з іншою з’єднаною колією). Червоний «!» — підрозділ відрізаний.</div><div class="row" style="margin-top:6px"><button class="sm" id="railb">Прокласти залізницю</button><button class="ghost sm" id="depb">Склад</button></div>';
  if (layer === 'terrain' && window.terrainLegend) h = terrainLegend();
  if (layer === 'weather' && WX) h = `<div class="lgrow"><b>${esc(WX.monthName)}</b>${WX.mine ? ` · у вас: ${esc(WX.mine.seasonName)}, ${esc(WX.mine.name)}` : ''}</div>` + Object.entries(WXC).map(([k, c]) => `<div class="lgrow"><span class="sw" style="background:${c}"></span>${ico(WXI[k], 16)} ${esc(WX.types[k].n)}${WX.types[k].mv < 1 ? ` <span class="muted">рух ×${WX.types[k].mv}</span>` : ''}</div>`).join('') + '<div class="muted" style="max-width:240px">Зима: мороз і хуртовини забирають солдатів (без одягу — утричі більше), люди споживають більше одягу й електрики. Бездоріжжя й сніг сповільнюють армії. Восени — урожай, улітку — посухи.</div>';
  if (layer === 'supply') h = SUPC.map(([v, c], i) => row(c, i === 0 ? 'Добре забезпечення' : i === 1 ? 'Нормальне' : i === 2 ? 'Слабке' : 'Майже немає')).join('') + '<div class="muted" style="max-width:240px">Постачання від столиці, складів і залізниці. Склад без з’єднання з залізницею дає лише частину. Шар «Логістика» — будувати.</div>';
  if (layer === 'drones') h = `<div class="lgrow">${ico('radar', 18)} Радар (бірюзове коло — зона виявлення)</div><div class="lgrow">${ico('aa_gepard', 18)} Засіб ППО (пунктир — радіус ураження)</div><div class="lgrow">${ico('launcher', 18)} Пускова установка</div><div class="lgrow">${ico('shahed', 18, '#7a4a00')} Ваші дрони / ${ico('shahed', 18, '#780000')} ворожі (видно лише в зоні радарів)</div>`;
  if (window.legend16) h = legend16(layer) || h;
  if (regionPaths.length && ['owners', 'nations', 'terrain', 'diplo', 'alliances', 'resources'].includes(layer)) h += `<div class="lgrow regtg" style="gap:10px;flex-wrap:wrap"><label class="chk" style="margin:0"><input type="checkbox" id="regN" ${regShow.n ? 'checked' : ''} style="width:auto"> Назви республік мапи</label><label class="chk" style="margin:0"><input type="checkbox" id="regB" ${regShow.b ? 'checked' : ''} style="width:auto"> Кордони республік мапи</label></div>`;
  el.innerHTML = h; { const rn = $('#regN'), rb0 = $('#regB'); const sv = () => { try { localStorage.regShow = JSON.stringify(regShow); } catch {} drawMap(); }; if (rn) rn.onchange = () => { regShow.n = rn.checked; sv(); }; if (rb0) rb0.onchange = () => { regShow.b = rb0.checked; sv(); }; } el.classList.toggle('hidden', !h); { const rb = $('#railb'); if (rb) rb.onclick = () => setMode({ kind: 'rail', a: null }); const db2 = $('#depb'); if (db2) db2.onclick = () => startPlace('depot'); }
}
let regShow = { n: true, b: true }; try { regShow = { ...regShow, ...JSON.parse(localStorage.regShow || '{}') }; } catch {}
let flagMode = false; try { flagMode = localStorage.flagMode === '1'; } catch {}
async function loadUnits() { if (!me || !me.country) { myUnits = []; foeUnits = []; visUnits = []; return drawMap(); } try { myUnits = (await api('army/state')).units; foeUnits = (await api('intel/units')).units; visUnits = (await api('units/visible')).units; syncDisp(true); await loadOcc(); await Promise.all([loadFacs(), loadArmyQuick(), loadArmyDraw()]); } catch {} drawMap(); if (tab === 'map' && !typing()) renderSide(); }
function fitMap() { const r = cv.getBoundingClientRect(); if (!land || !r.width) return; const sd = $('#side'), pad = sd && !sd.classList.contains('hidden') && getComputedStyle(sd).position === 'absolute' ? sd.offsetWidth + 24 : 0, W = Math.max(200, r.width - pad); view.s = Math.min(W / land.w, r.height / land.h) * 0.97; view.fs = view.s; view.x = (W - land.w * view.s) / 2; view.y = (r.height - land.h * view.s) / 2; }
function resizeMap() { const r = cv.getBoundingClientRect(); cv.width = r.width * devicePixelRatio; cv.height = r.height * devicePixelRatio; if (land) { fitMap(); drawMap(); } }
addEventListener('resize', () => { if (!$('#mapWrap').classList.contains('hidden')) resizeMap(); });
const GL = { aluminium: 'Al', chromium: 'Cr', steel: 'Fe', tungsten: 'W', oil: 'Н', rubber: 'Гм' };
function drawFacIcon(f, C) { drawFacBadges(C, [f], false); }
// перемальовування мапи не частіше одного разу за кадр
let drawPending = false;
function drawMap() { if (drawPending) return; drawPending = true; requestAnimationFrame(() => { drawPending = false; try { drawMapNow(); } catch (e) { console.error(e); } }); }
function drawMapNow() {
  if (!landReady) return; const css = getComputedStyle(document.documentElement), dpr = devicePixelRatio, K = land.w / 1280, C = land.cell;
  cx.setTransform(1, 0, 0, 1, 0, 0); cx.clearRect(0, 0, cv.width, cv.height); cx.setTransform(view.s * dpr, 0, 0, view.s * dpr, view.x * dpr, view.y * dpr);
  cx.fillStyle = css.getPropertyValue('--land'); cx.fill(landPath, 'evenodd');
  cx.save(); cx.clip(landPath, 'evenodd'); cx.imageSmoothingEnabled = false; cx.drawImage(off, 0, 0, land.w, land.h); if (foreignCv) cx.drawImage(foreignCv, 0, 0, land.w, land.h);
  if (occCv && (occRuns.length || greyRuns.length) && (layer === 'owners' || layer === 'diplo' || layer === 'alliances' || layer === 'supply')) { cx.globalAlpha = .62; cx.drawImage(occCv, 0, 0, land.w, land.h); cx.globalAlpha = 1; }
  if (layer === 'supply') drawSupply(C);
  drawRivers(C);
  if (layer === 'weather') drawWeather(C);
  if (window.drawRoads) drawRoads(C);
  if (window.drawForts) drawForts(C);
  if (layer === 'resources' && deposits) for (const res of Object.keys(deposits)) { if (resSel !== 'all' && resSel !== res) continue; if (!RESM[res]) continue;
    for (const dp of deposits[res]) { const x = (dp.x + .5) * C, y = (dp.y + .5) * C, rr = dp.r * C, g = cx.createRadialGradient(x, y, 0, x, y, rr); const [r, gg, b] = hexRgb(MAPC[res] || RESM[res].c); const a = (resSel === 'all' ? .8 : .92) * Math.min(1, dp.k / 1.3);
      g.addColorStop(0, `rgba(${r},${gg},${b},${a})`); g.addColorStop(.55, `rgba(${r},${gg},${b},${a * .75})`); g.addColorStop(1, `rgba(${r},${gg},${b},0)`); cx.fillStyle = g; cx.beginPath(); cx.arc(x, y, rr, 0, 7); cx.fill();
      if (view.s > view.fs * 1.8 || resSel !== 'all') { cx.fillStyle = '#fff'; cx.font = `700 ${11 / view.s}px sans-serif`; cx.textAlign = 'center'; cx.fillText((GL[res] || '') + ' ×' + dp.k, x, y + 4 / view.s); cx.textAlign = 'start'; } } }
  if (mode.kind === 'confdraw') drawConfSets(C);
  if (preview.length) { cx.globalAlpha = .6; cx.fillStyle = mode.kind === 'confdraw' ? ((mode.take ? me.country.color : (countries[mode.other] || {}).color) || '#888') : mode.kind === 'expand' ? (me.country ? me.country.color : '#888') : mode.kind === 'aterr' ? (mode.add ? (countries[mode.cid] || {}).color || '#888' : '#d33') : mode.kind === 'armyzone' ? (mode.purpose === 'attack' ? '#ef4444' : '#7dd3fc') : mode.kind === 'provdraw' ? (mode.op === 'remove' ? '#d33' : '#facc15') : founding.color; for (const i of preview) cx.fillRect((i % land.gw) * C, ((i / land.gw) | 0) * C, C, C); cx.globalAlpha = 1; }
  if (brushMode()) { if (previewBad.length) { cx.globalAlpha = .55; cx.fillStyle = '#d33'; for (const i of previewBad) cx.fillRect((i % land.gw) * C, ((i / land.gw) | 0) * C, C, C); cx.globalAlpha = 1; } if (hoverC) { cx.strokeStyle = '#fff'; cx.lineWidth = 1.5 / view.s; cx.beginPath(); cx.arc((hoverC.x + .5) * C, (hoverC.y + .5) * C, (brushR + .5) * C, 0, 7); cx.stroke(); } }
  cx.strokeStyle = css.getPropertyValue('--border'); cx.lineWidth = 1.2 / view.s; if (borderPath) cx.stroke(borderPath); cx.restore();
  cx.strokeStyle = css.getPropertyValue('--coast'); cx.lineWidth = 1.4 / view.s; cx.stroke(landPath, 'evenodd');
  if (regionPaths.length && ['owners', 'nations', 'terrain', 'diplo', 'alliances', 'resources'].includes(layer) && (regShow.b || regShow.n)) { cx.save(); cx.setLineDash([5 / view.s, 4 / view.s]); cx.strokeStyle = 'rgba(255,255,255,.38)'; cx.lineWidth = 1.1 / view.s; if (regShow.b) for (const r of regionPaths) cx.stroke(r.path); cx.setLineDash([]);
    if (regShow.n && view.s < view.fs * 6) { cx.textAlign = 'center'; cx.font = `600 ${13 / view.s}px sans-serif`; cx.fillStyle = 'rgba(255,255,255,.55)'; for (const r of regionPaths) { if (r.w < cx.measureText(r.n).width * 0.8) continue; cx.fillText(r.n, r.x, r.y); } cx.textAlign = 'start'; } cx.restore(); }
  if (layer === 'air') for (const z of airZones) { const col = (countries[z.cid] || {}).color || '#888', x = (z.x + .5) * C, y = (z.y + .5) * C; cx.globalAlpha = .14; cx.fillStyle = col; cx.beginPath(); cx.arc(x, y, z.r * C, 0, 7); cx.fill(); cx.globalAlpha = .9; cx.setLineDash([6 / view.s, 4 / view.s]); cx.strokeStyle = col; cx.lineWidth = 2 / view.s; cx.stroke(); cx.setLineDash([]); cx.globalAlpha = 1; drawBadge(cx, 'airfield', x, y, 8 / view.s, { square: true, stroke: col, lw: 2 / view.s }); }
  if (layer === 'alliances') { const cap = (id) => { const c = countries[id]; return [(c.capital % land.gw + .5) * C, (((c.capital / land.gw) | 0) + .5) * C]; };
    cx.lineWidth = 2.4 / view.s; cx.setLineDash([7 / view.s, 5 / view.s]); cx.strokeStyle = '#ef4444'; for (const w of warLines) { const a = cap(w.a), b = cap(w.b); cx.beginPath(); cx.moveTo(a[0], a[1]); cx.lineTo(b[0], b[1]); cx.stroke(); }
    cx.setLineDash([]); cx.strokeStyle = '#2ecc71'; for (const w of alliedLines) { const a = cap(w.a), b = cap(w.b); cx.beginPath(); cx.moveTo(a[0], a[1]); cx.lineTo(b[0], b[1]); cx.stroke(); } }
  if (layer === 'alliances') for (const L of blocLabels) { cx.save(); cx.translate(L.x, L.y); cx.rotate(L.ang); cx.font = `800 ${L.fs}px Georgia,serif`; cx.textAlign = 'center'; cx.textBaseline = 'middle'; try { cx.letterSpacing = (L.fs * 0.18) + 'px'; } catch {}
    cx.lineJoin = 'round'; cx.lineWidth = L.fs * 0.08; cx.strokeStyle = 'rgba(10,8,16,.75)'; cx.strokeText(L.name, 0, 0); cx.fillStyle = 'rgba(240,236,250,.7)'; cx.fillText(L.name, 0, 0); cx.restore(); }
  if (layer !== 'alliances') drawCountryLabels(K);
  if (layer === 'logistics') drawLogi(C);
  drawArmies(C); drawConvoys(C); drawCities(C);
  for (const c of Object.values(countries)) { if (cities.some((q0) => q0.cap && q0.cid === c.id)) { const fe0 = flagImgs[c.id]; if (!(fe0 && fe0.img && c.flag)) continue; }
    const x = (c.capital % land.gw + .5) * C, y = (((c.capital / land.gw) | 0) + .5) * C, kz = Math.min(K, 1.4 / view.s);
    if (!cities.some((q0) => q0.cap && q0.cid === c.id)) { cx.fillStyle = '#000'; cx.strokeStyle = '#fff'; cx.lineWidth = 1.5 / view.s; cx.beginPath(); cx.arc(x, y, 3.2 * kz, 0, 7); cx.fill(); cx.stroke(); }
    const fe = flagImgs[c.id]; if (fe && fe.img && c.flag) { const w = 15 * kz, h = 10 * kz; cx.strokeStyle = '#222'; cx.lineWidth = 1 / view.s; cx.beginPath(); cx.moveTo(x, y - 6 * kz); cx.lineTo(x, y - h - 10 * kz); cx.stroke(); cx.drawImage(fe.img, x, y - h - 10 * kz, w, h); cx.strokeRect(x, y - h - 10 * kz, w, h); } }
  if (me && me.country && (layer === 'facilities' || layer === 'resources' || mode.kind === 'place' || layer === 'drones')) drawFacBadges(C, layer === 'drones' ? myFacs.filter((f) => ['launcher', 'airfield', 'depot', 'port'].includes(f.kind)) : myFacs, false);
  if (knownFacs.length && (layer === 'facilities' || layer === 'drones' || layer === 'logistics')) drawFacBadges(C, knownFacs, true);
  drawAD(C);
  if (layer === 'drones' && adState && selLaunch) { const L = adState.launchers.find((l) => l.id === selLaunch); if (L) { const S = adState.strike.find((x) => x.k === (mode.item || launchSel.item || '')); cx.strokeStyle = '#f5b041'; cx.lineWidth = 2 / view.s; cx.setLineDash([10 / view.s, 6 / view.s]); cx.beginPath(); cx.arc((L.x + .5) * C, (L.y + .5) * C, (S ? S.range : 60) * C, 0, 7); cx.stroke(); cx.setLineDash([]); drawBadge(cx, L.kind, (L.x + .5) * C, (L.y + .5) * C, 11 / view.s, { square: true, stroke: '#f5b041', lw: 3 / view.s }); } }
  for (const f of (window.mapShow && !mapShow.intel ? [] : foeUnits)) { const col = (countries[f.cid] || {}).color || '#888', x = (f.x + .5) * C, y = (f.y + .5) * C, r = Math.max(f.r * C, 9 / view.s);
    cx.globalAlpha = .3; cx.fillStyle = col; cx.beginPath(); cx.arc(x, y, r, 0, 7); cx.fill(); cx.globalAlpha = 1; cx.setLineDash([4 / view.s, 3 / view.s]); cx.strokeStyle = col; cx.lineWidth = 1.5 / view.s; cx.stroke(); cx.setLineDash([]);
    cx.fillStyle = '#fff'; cx.font = `700 ${11 / view.s}px sans-serif`; cx.textAlign = 'center'; cx.fillText(f.type ? UTL[f.type] : f.n || '?', x, y + 4 / view.s); cx.textAlign = 'start'; }
  for (const v of (window.mapShow && mapShow.units !== 'all' ? [] : visUnits)) { const dp = dispPos['v' + v.id], col = (countries[v.cid] || {}).color || '#888', x = ((dp ? dp.x : v.x) + .5) * C, y = ((dp ? dp.y : v.y) + .5) * C;
    const r = drawUnitSymbol(v, x, y, col, v.war ? '#ff4d4d' : '#222', true); if (selVis && selVis.id === v.id) { cx.strokeStyle = '#e6007e'; cx.lineWidth = 3 / view.s; cx.strokeRect(x - r * 1.7, y - r * 1.25, r * 3.4, r * 2.5); }
    if (view.s > view.fs * 1.6) { cx.fillStyle = '#fff'; cx.font = `600 ${9 / view.s}px sans-serif`; cx.textAlign = 'center'; cx.fillText('≈' + short(v.approx), x, y + r + 10 / view.s); cx.textAlign = 'start'; } }
  if (me && me.country && !(window.mapShow && mapShow.units === 'none')) for (const u of myUnits) { const dp = dispPos['u' + u.id], x = ((dp ? dp.x : u.x) + .5) * C, y = ((dp ? dp.y : u.y) + .5) * C;
    if (u.tx != null) { cx.setLineDash([5 / view.s, 4 / view.s]); cx.strokeStyle = u.order_kind === 'attack' ? '#ef4444' : '#f2f2f2'; cx.lineWidth = 1.6 / view.s; cx.beginPath(); cx.moveTo(x, y); cx.lineTo((u.tx + .5) * C, (u.ty + .5) * C); cx.stroke(); cx.setLineDash([]); }
    const r = drawUnitSymbol(u, x, y, me.country.color, u.army_id ? '#c084fc' : '#000');
    if (selSet.has(u.id)) { cx.strokeStyle = '#e6007e'; cx.lineWidth = 3 / view.s; cx.strokeRect(x - r * 1.75, y - r * 1.3, r * 3.5, r * 2.6); }
    if (u.blockade) { cx.strokeStyle = '#5dade2'; cx.lineWidth = 2 / view.s; cx.beginPath(); cx.arc(x, y, r * 1.8, 0, 7); cx.stroke(); }
    if (u.cut) { cx.fillStyle = '#ef4444'; cx.font = `800 ${13 / view.s}px sans-serif`; cx.fillText('!', x + r * 1.6, y - r); } }
  if (window.drawBattles) drawBattles(C);
  if (window.drawLayer16) drawLayer16(C);
  drawFlights(C);
  if (boxSel) { cx.fillStyle = 'rgba(230,0,126,.12)'; cx.strokeStyle = '#e6007e'; cx.lineWidth = 1.2 / view.s; const bx = Math.min(boxSel.x1, boxSel.x2), by = Math.min(boxSel.y1, boxSel.y2); cx.fillRect(bx, by, Math.abs(boxSel.x2 - boxSel.x1), Math.abs(boxSel.y2 - boxSel.y1)); cx.strokeRect(bx, by, Math.abs(boxSel.x2 - boxSel.x1), Math.abs(boxSel.y2 - boxSel.y1)); }
  if (lineDrag) { const a = [(lineDrag.a.x + .5) * C, (lineDrag.a.y + .5) * C], b2 = [(lineDrag.b.x + .5) * C, (lineDrag.b.y + .5) * C], n = selSet.size; cx.strokeStyle = '#e6007e'; cx.lineWidth = 2 / view.s; cx.setLineDash([6 / view.s, 4 / view.s]); cx.beginPath(); cx.moveTo(a[0], a[1]); cx.lineTo(b2[0], b2[1]); cx.stroke(); cx.setLineDash([]); cx.fillStyle = '#e6007e';
    for (let i = 0; i < n; i++) { const t = n === 1 ? .5 : i / (n - 1); cx.beginPath(); cx.arc(a[0] + (b2[0] - a[0]) * t, a[1] + (b2[1] - a[1]) * t, 5 / view.s, 0, 7); cx.fill(); } }
  if (placeHover) { const x = (placeHover.x + .5) * C, y = (placeHover.y + .5) * C; cx.strokeStyle = placeHover.ok ? '#2ecc71' : '#ef4444'; cx.lineWidth = 2.5 / view.s; cx.beginPath(); cx.arc(x, y, 11 / view.s, 0, 7); cx.stroke(); cx.beginPath(); cx.moveTo(x - 15 / view.s, y); cx.lineTo(x + 15 / view.s, y); cx.moveTo(x, y - 15 / view.s); cx.lineTo(x, y + 15 / view.s); cx.stroke(); }
  if (pending) { const x = (pending.x + .5) * C, y = (pending.y + .5) * C; cx.strokeStyle = '#fff'; cx.lineWidth = 1.5 / view.s; cx.beginPath(); cx.arc(x, y, 5 * K, 0, 7); cx.stroke(); }
}
const toCell = (e) => { const r = cv.getBoundingClientRect(), mx = (e.clientX - r.left - view.x) / view.s, my = (e.clientY - r.top - view.y) / view.s; return { x: Math.floor(mx / land.cell), y: Math.floor(my / land.cell) }; };
const depAt = (x, y) => { const out = []; if (!deposits) return out; for (const res in deposits) for (const d of deposits[res]) { const dist = Math.hypot(x - d.x, y - d.y); if (dist < d.r) out.push([res, d.k * (1 - .35 * dist / d.r)]); } return out; };
const nearFac = (e, px = 14) => { const r = cv.getBoundingClientRect(); let hit = null, best = px; for (const f of myFacs) { const d = Math.hypot(view.x + (f.x + .5) * land.cell * view.s - (e.clientX - r.left), view.y + (f.y + .5) * land.cell * view.s - (e.clientY - r.top)); if (d < best) { best = d; hit = f; } } return hit; };
let drag = null, moved = 0;
const mapXY = (e) => { const r = cv.getBoundingClientRect(); return { x: (e.clientX - r.left - view.x) / view.s, y: (e.clientY - r.top - view.y) / view.s }; };

cv.onmousedown = (e) => { if ((brushMode()) && e.button === 0 && !e.ctrlKey) { brushing = true; moved = 0; brushPaint(toCell(e), e.shiftKey); return; }
  if (mode.kind === 'line' && e.button === 0) { const c0 = toCell(e); lineDrag = { a: c0, b: c0 }; moved = 0; return; }
  if (mode.kind === 'idle' && e.shiftKey && e.button === 0 && me && me.country && myUnits.length) { const m0 = mapXY(e); boxSel = { x1: m0.x, y1: m0.y, x2: m0.x, y2: m0.y }; moved = 0; return; } drag = { x: e.clientX, y: e.clientY, vx: view.x, vy: view.y }; moved = 0; cv.style.cursor = 'grabbing'; };
addEventListener('mouseup', () => { if (brushing) { brushing = false; brushAfter(); }
  if (boxSel) { const b = boxSel; boxSel = null; if (moved > 5) { const x1 = Math.min(b.x1, b.x2), x2 = Math.max(b.x1, b.x2), y1 = Math.min(b.y1, b.y2), y2 = Math.max(b.y1, b.y2); myUnits.forEach((u) => { const ux = (u.x + .5) * land.cell, uy = (u.y + .5) * land.cell; if (ux >= x1 && ux <= x2 && uy >= y1 && uy <= y2) selSet.add(u.id); }); selUnit = selSet.size === 1 ? [...selSet][0] : null; card = null; } drawMap(); renderSide(); }
  if (lineDrag) { const l = lineDrag; lineDrag = null; if (Math.hypot(l.b.x - l.a.x, l.b.y - l.a.y) < 2) { drawMap(); } else { const ids = [...selSet]; act(async () => { const r = await orderApi('units/orders', { ids, mode: 'line', x: l.a.x, y: l.a.y, x2: l.b.x, y2: l.b.y }); toast(`Вишикування: ${r.done} підрозділів${r.failed ? `, не вдалось: ${r.failed} (${String(r.firstError).replace('CONFIRM_WAR:', '')})` : ''}`, !!r.failed && !r.done); setMode({ kind: 'idle' }); await loadUnits(); }); } }
  drag = null; cv.style.cursor = 'grab'; });
cv.onmousemove = (e) => {
  if (mode.kind === 'fortline' && mode.a) { hoverC = toCell(e); drawMap(); }
  if (brushMode()) { const c0 = toCell(e); hoverC = c0; if (brushing) brushPaint(c0, e.shiftKey); else drawMap(); }
  if (boxSel) { const m0 = mapXY(e); boxSel.x2 = m0.x; boxSel.y2 = m0.y; moved += Math.abs(e.movementX) + Math.abs(e.movementY); drawMap(); return; }
  if (lineDrag) { lineDrag.b = toCell(e); moved += Math.abs(e.movementX) + Math.abs(e.movementY); drawMap(); return; }
  if (drag) { moved += Math.abs(e.movementX) + Math.abs(e.movementY); view.x = drag.vx + e.clientX - drag.x; view.y = drag.vy + e.clientY - drag.y; drawMap(); return; }
  if (!land) return; const c = toCell(e), tip = $('#tip'), inside = c.x >= 0 && c.y >= 0 && c.x < land.gw && c.y < land.gh, id = inside ? owners[c.y * land.gw + c.x] : 0; let html = '';
  if (id && countries[id]) { const k = countries[id]; html = `<span class="sw" style="background:${esc(k.color)}"></span><b>${esc(k.name)}</b><br><span class="muted">Керує: ${esc(k.owner || '—')}</span>`; }
  if (inside && land.farr && land.farr[c.y * land.gw + c.x]) html = '<b>Закордон</b><br><span class="muted">Поза грою: сюди не пройти й не розширитись</span>';
  if (layer === 'nations' && inside && natMap) { const n = natMap[c.y * land.gw + c.x], N0 = natList[n]; html += N0 ? `<div><span class="sw" style="background:${esc(N0.color)}"></span>Тут живуть: <b>${esc(N0.name)}</b>${N0.homeName ? ` <span class="muted">(батьківщина — ${esc(N0.homeName)})</span>` : ''}</div>` : '<div class="muted">Тут ніхто не живе</div>'; }
  if (layer === 'terrain' && inside && window.terrainTip) html += terrainTip(c.x, c.y);
  if (layer === 'resources' && inside) { const dp = depAt(c.x, c.y).filter(([r]) => resSel === 'all' || r === resSel); html += dp.length ? `<br>${dp.map(([r, k]) => `${RESM[r].n}: ×${nf(k)}`).join('<br>')}` : ''; }
  if ((layer === 'facilities' || layer === 'resources') && me && me.country) { const f = nearFac(e); if (f) html = `<b>${esc((FDEFS[f.kind] || {}).n || f.kind)}</b> · рівень ${f.level}<br><span class="muted">Клік: докладніше</span>`; }
  { const ct = layer !== 'resources' ? cityAt(e) : null; if (ct) { const o = countries[ct.cid]; html = `${ico(ct.cap ? 'capital' : 'city', 18)} <b>${esc(ct.name)}</b>${ct.cap ? ' (столиця)' : ''}<br><span class="muted">${o ? esc(o.name) : 'нейтральна земля'} · рівень ${ct.level} · клік: інформація</span>`; } }
  if ((layer === 'drones' || layer === 'air') && adSites.length) { const rr = cv.getBoundingClientRect(); const sp = adSites.find((q0) => Math.hypot(view.x + (q0.x + .5) * land.cell * view.s - (e.clientX - rr.left), view.y + (q0.y + .5) * land.cell * view.s - (e.clientY - rr.top)) < 10); if (sp) html = `${ico(sp.kind, 18)} <b>${esc(sp.name)}</b><br><span class="muted">${sp.own ? 'ваш' : sp.ally ? 'союзний' : 'ворожий'} · радіус ${sp.rr || sp.r} кл.${sp.broken ? ' · несправний' : ''}</span>`; }
  if (convoysD.length && CONVOY_LAYERS.includes(layer)) { const rr = cv.getBoundingClientRect(); const cvh = convoysD.find((c0) => { const [px, py] = convoyPos(c0); return Math.hypot(view.x + (px + .5) * land.cell * view.s - (e.clientX - rr.left), view.y + (py + .5) * land.cell * view.s - (e.clientY - rr.top)) < 14; }); if (cvh) html = `${ico(cvh.mode === 'sea' || cvh.mode === 'hired' ? 'cargo' : 'truck', 18)} <b>${cvh.mode === 'sea' ? 'Морський конвой' : cvh.mode === 'hired' ? 'Найняті кораблі' : cvh.mode === 'air' ? 'Повітряний міст' : 'Караван'}</b> ${esc(cvh.fromName)} → ${esc(cvh.toName)}<br><span class="muted">${esc(cvh.goods)}${cvh.status === 'back' ? ' · кораблі повертаються' : ` · прибуде через ${nf(Math.max(0, cvh.eta - nowDay()), 1)} діб`}${cvh.fee ? `<br><b class="pos">Ви отримаєте: ${short(cvh.fee)} $</b> (${cvh.to === me.country.id ? 'мито' : 'транзит'})` : cvh.through ? '<br>Проходить через вас, але транзитний збір 0% (Торгівля → Митна політика)' : ''}</span>`; }
  if (flightsD.length) { const rr = cv.getBoundingClientRect(); const fl = flightsD.find((q0) => !q0.dead && Math.hypot(view.x + (q0.px + .5) * land.cell * view.s - (e.clientX - rr.left), view.y + (q0.py + .5) * land.cell * view.s - (e.clientY - rr.top)) < 12); if (fl) html = `<b>${esc(fl.name)}</b> · ${esc((countries[fl.cid] || {}).name || '')}${fl.target ? `<br><span class="muted">ціль: ${esc(fl.target)}</span>` : ''}`; }
  if (window.tip16 && inside) html += tip16(c.x, c.y, e) || '';
  if (html) { tip.innerHTML = html; tip.style.left = e.offsetX + 14 + 'px'; tip.style.top = e.offsetY + 14 + 'px'; tip.classList.remove('hidden'); } else tip.classList.add('hidden');
  if (me && !me.country && !pending) { clearTimeout(hoverT); hoverT = setTimeout(() => previewAt(c, false), 60); }
  if (mode.kind === 'place') { clearTimeout(hoverT); hoverT = setTimeout(() => placePreview(c), 70); }
};
cv.oncontextmenu = (e) => e.preventDefault();
cv.onmouseleave = () => { $('#tip').classList.add('hidden'); hoverC = null; if (brushMode()) drawMap(); };
cv.onwheel = (e) => { e.preventDefault(); const r = cv.getBoundingClientRect(), mx = e.clientX - r.left, my = e.clientY - r.top, f = e.deltaY < 0 ? 1.15 : 1 / 1.15, ns = Math.max(view.fs * .7, Math.min(view.fs * 30, view.s * f)); view.x = mx - (mx - view.x) * ns / view.s; view.y = my - (my - view.y) * ns / view.s; view.s = ns; drawMap(); };
cv.onclick = async (e) => {
  if (moved > 5 || !land || !me) return; const c = toCell(e);
  if (!me.country) return previewAt(c, true);
  if (mode.kind === 'admove') { const id = mode.id; return act(async () => { const r = await api('ad/move', { id, x: c.x, y: c.y }); toast(`Засіб вирушив на нову позицію: прибуде через ${nf(r.days, 2)} доби гри. У дорозі він не стріляє.`); setMode({ kind: 'idle' }); await Promise.all([loadAD(), loadADState()]); drawMap(); }); }
  if (window.mapClick19 && await mapClick19(e, c)) return;
  if (window.mapClickWar && await mapClickWar(e, c)) return;
  if (window.mapClick16 && await mapClick16(e, c)) return;
  if (await mapClick3(e, c)) return;
  if (mode.kind === 'order') return act(async () => { const r = await orderApi('units/order', { id: mode.unit, x: c.x, y: c.y }); toast(r.kind === 'attack' ? 'Наказ: атака!' : 'Наказ: рух'); setMode({ kind: 'idle' }); await loadUnits(); });
  if (brushMode() || mode.kind === 'line') return;
  if (mode.kind === 'gorder') return act(async () => { const r = await orderApi('units/orders', { ids: [...selSet], mode: 'point', x: c.x, y: c.y }); toast(`Наказ отримали: ${r.done}${r.failed ? `, не вдалось: ${r.failed} (${String(r.firstError).replace('CONFIRM_WAR:', '')})` : ''}`, !!r.failed && !r.done); setMode({ kind: 'idle' }); await loadUnits(); });
  if (mode.kind === 'rail') { if (!mode.a) { mode.a = [c.x, c.y]; const el = $('#railhint'); if (el) el.textContent = 'Тепер клікни, де має закінчитись колія'; return; } const a = mode.a; mode.a = null; return act(async () => { const r = await api('rail/build', { ax: a[0], ay: a[1], bx: c.x, by: c.y }); toast(`Залізницю прокладено за ${exact(r.cost)} $`); await loadLogi(); drawMap(); }); }
  if (mode.kind === 'place') return act(async () => { const fk = mode.fkind; await api('econ/build', { kind: fk, x: c.x, y: c.y }); toast(`«${(FDEFS[fk] || {}).n || fk}» додано до черги будівництва`); setMode({ kind: 'idle' }); await loadFacs(); drawMap(); });
  const r = cv.getBoundingClientRect(); let hit = null, best = 12;
  for (const u of myUnits) { const d = Math.hypot(view.x + (u.x + .5) * land.cell * view.s - (e.clientX - r.left), view.y + (u.y + .5) * land.cell * view.s - (e.clientY - r.top)); if (d < best) { best = d; hit = u; } }
  if (hit) { if (e.shiftKey) { selSet.has(hit.id) ? selSet.delete(hit.id) : selSet.add(hit.id); } else selSet = new Set([hit.id]); selUnit = selSet.size === 1 ? [...selSet][0] : null; selFac = null; card = null; drawMap(); return renderSide(); }
  { let vh = null, vb = 12; for (const v of visUnits) { const d = Math.hypot(view.x + (v.x + .5) * land.cell * view.s - (e.clientX - r.left), view.y + (v.y + .5) * land.cell * view.s - (e.clientY - r.top)); if (d < vb) { vb = d; vh = v; } } if (vh) { selVis = vh; card = null; drawMap(); return renderSide(); } }
  if (layer === 'facilities' || layer === 'resources') { const f = nearFac(e); if (f) { selFac = f.id; selUnit = null; card = null; drawMap(); return renderSide(); } }
  selUnit = null; selSet = new Set(); selVis = null; selFac = null; const id = c.x >= 0 && c.y >= 0 && c.x < land.gw && c.y < land.gh ? owners[c.y * land.gw + c.x] : 0;
  if (id === me.country.id) card = { own: true }; else if (id) { card = await api('intel/country?id=' + id).catch(() => null); if (card && window.openCountry) openCountry(id); } else card = null;
  drawMap(); renderSide();
};
async function previewAt(c, lock) {
  const my = ++seq; if (lock) pending = c;
  try { const d = await api(`preview?x=${c.x}&y=${c.y}`); if (my !== seq && !lock) return; if (d.error) { if (lock) { pending = null; preview = []; sideMsg(d.error); } else if (!pending) preview = []; } else if (lock || !pending) { preview = d.cells; if (lock) sideMsg(''); } } catch {}
  drawMap();
}
let brush = new Set(), brushing = false, brushR = 5, hoverC = null, previewBad = [], expandInfo = { cost: 60000, max: 1500 };
function brushPaint(c, erase) {
  if (!land) return; const r = brushR; let ch = false;
  for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) { if (dx * dx + dy * dy > r * r + 1) continue; const x = c.x + dx, y = c.y + dy; if (x < 0 || y < 0 || x >= land.gw || y >= land.gh) continue; const i = y * land.gw + x; if (!land.arr[i]) continue;
    if (erase) { if (brush.delete(i)) ch = true; } else if (mode.kind === 'armyzone' || mode.kind === 'provdraw' ? (mode.purpose === 'defend' || mode.kind === 'provdraw' ? owners[i] === me.country.id : owners[i] && owners[i] !== me.country.id) && !brush.has(i) : mode.kind === 'confdraw' ? !mode.readonly && (mode.take ? owners[i] === mode.other : owners[i] === me.country.id) && !brush.has(i) : mode.kind === 'aterr' ? (mode.add ? owners[i] !== mode.cid : owners[i] === mode.cid) && !brush.has(i) : !owners[i] && !brush.has(i)) { brush.add(i); ch = true; } }
  if (ch) brushAfter(false); else drawMap();
}
function brushAfter(full = true) { if (mode.kind === 'confdraw') confCalc(); else if (mode.kind === 'aterr' || mode.kind === 'armyzone' || mode.kind === 'provdraw') atCalc(); else brushCalc(full); }
function atCalc() { preview = [...brush]; const el = $('#bannerCost'); if (el) el.textContent = brush.size ? (mode.kind === 'armyzone' || mode.kind === 'provdraw' ? `${brush.size} кл.` : `${brush.size} кл. ${mode.add ? 'буде додано' : 'буде прибрано'}`) : 'ще нічого не намальовано'; drawMap(); }
async function atCommit() { if (!brush.size) return toast('Спочатку намалюй клітинки', true); const cid = mode.cid, add = mode.add, cells = [...brush]; act(async () => { await api('admin/territory', { cid, mode: add ? 'add' : 'remove', cells }); toast('Територію змінено'); setMode({ kind: 'idle' }); await refreshMe(); await loadMap(); }); }
function startTerr(cid) { showTab('map'); setLayer('owners').then(() => setMode({ kind: 'aterr', cid, add: true })); }
addEventListener('keydown', (e) => { if (e.key === 'Escape' && tab === 'map' && (mode.kind !== 'idle' || selSet.size)) { selSet = new Set(); selUnit = null; selVis = null; setMode({ kind: 'idle' }); } });
function brushCalc(full = true) {
  const gw = land.gw, my = me.country.id, ok = new Set(), qu = [], nb = (i) => { const x = i % gw, o = []; if (x > 0) o.push(i - 1); if (x < gw - 1) o.push(i + 1); o.push(i - gw, i + gw); return o; };
  for (const i of brush) if (nb(i).some((j) => owners[j] === my)) { ok.add(i); qu.push(i); }
  while (qu.length) { const i = qu.pop(); for (const j of nb(i)) if (brush.has(j) && !ok.has(j)) { ok.add(j); qu.push(j); } }
  preview = [...ok]; previewBad = [...brush].filter((i) => !ok.has(i));
  const el = $('#bannerCost'); if (el) { const n = ok.size, over = n > expandInfo.max; el.textContent = n ? `${n} кл. · ${exact(n * expandInfo.cost)} $` + (previewBad.length ? ` · ${previewBad.length} кл. не межують (червоні)` : '') + (over ? ` · максимум ${expandInfo.max}` : '') : 'ще нічого не намальовано'; }
  drawMap();
}
async function brushCommit() {
  if (!preview.length) return toast('Спочатку намалюй територію', true);
  if (!confirm(`Додати ${preview.length} клітинок за ${exact(preview.length * expandInfo.cost)} $?`)) return;
  act(async () => { const r = await api('econ/expand', { cells: preview }); toast(`Територію розширено: ${r.cells} кл.`); setMode({ kind: 'idle' }); await refreshMe(); await loadMap(); });
}
async function placePreview(c) {
  if (mode.kind !== 'place') return; try { const p = await api(`fac/check?kind=${mode.fkind}&x=${c.x}&y=${c.y}`); placeHover = { x: c.x, y: c.y, ok: !!p.ok }; const el = $('#bannerCost'); if (el) el.textContent = p.err ? p.err : p.zone === true ? `Родовище! Видобуток ×${nf(p.rich)}` : p.zone === false ? 'Поза родовищем: видобуток лише ×0,6' : 'Місце підходить'; } catch {} drawMap();
}
const sideMsg = (t) => { const m = $('#smsg'); if (m) m.textContent = t; };
function setMode(m) {
  mode = m; preview = []; placeHover = null; if (m.kind === 'idle') { brush.clear(); previewBad = []; } const b = $('#banner');
  if (m.kind === 'order') { b.innerHTML = '<span>Клікни на мапі, куди відправити підрозділ</span><button id="bcancel">Скасувати</button>'; b.classList.remove('hidden'); }
  else if (m.kind === 'expand') { brush.clear(); previewBad = []; b.innerHTML = '<span>Малюй пензликом по вільній суші поруч зі своєю територією (Shift — стирати, Ctrl або права кнопка — рух мапи). Пензель: <input type="range" id="bsz" min="1" max="20" value="' + brushR + '" style="width:90px"> <b id="bannerCost"></b></span><button id="bok">Підтвердити</button><button class="ghost" id="bclr">Очистити</button><button id="bcancel">Скасувати</button>'; b.classList.remove('hidden'); $('#bsz').oninput = (e) => { brushR = +e.target.value; drawMap(); }; $('#bclr').onclick = () => { brush.clear(); brushCalc(); }; $('#bok').onclick = brushCommit; api('econ/state').then((d) => { expandInfo = d.expand; brushCalc(); }).catch(() => {}); }
  else if (m.kind === 'gorder') { b.innerHTML = `<span>Клікни на мапі, куди відправити ${selSet.size} підрозділів (вони розійдуться сіткою)</span><button id="bcancel">Скасувати</button>`; b.classList.remove('hidden'); }
  else if (m.kind === 'line') { b.innerHTML = `<span>Затисни ліву кнопку й проведи на мапі лінію: ${selSet.size} підрозділів вишикуються вздовж неї</span><button id="bcancel">Скасувати</button>`; b.classList.remove('hidden'); }
  else if (m.kind === 'aterr') { brush.clear(); previewBad = []; const cn = (countries[m.cid] || {}).name || ''; b.innerHTML = `<span>Редактор території: <b>${esc(cn)}</b>. <select id="atm" style="width:auto"><option value="add">Додати (забирає й у інших)</option><option value="remove">Прибрати</option></select> Shift — стирати намальоване, Ctrl або права кнопка — рух мапи. Пензель: <input type="range" id="bsz" min="1" max="30" value="${brushR}" style="width:90px"> <b id="bannerCost"></b></span><button id="bok">Застосувати</button><button class="ghost" id="bclr">Очистити</button><button id="bcancel">Скасувати</button>`; b.classList.remove('hidden');
    $('#bsz').oninput = (e) => { brushR = +e.target.value; drawMap(); }; $('#atm').onchange = (e) => { mode.add = e.target.value === 'add'; brush.clear(); atCalc(); }; $('#bclr').onclick = () => { brush.clear(); atCalc(); }; $('#bok').onclick = atCommit; atCalc(); }
  else if (m.kind === 'rail') { b.innerHTML = '<span>Залізниця: клікни початок (біля столиці, складу чи кінця колії), потім кінець. <b id="railhint">Обери початок</b></span><button class="ghost" id="railundo">Видалити останню</button><button id="bcancel">Готово</button>'; b.classList.remove('hidden'); $('#railundo').onclick = () => act(async () => { await api('rail/remove', {}); await loadLogi(); drawMap(); }); }
  else if (m.kind === 'confdraw') confBanner(b);
  else if (m.kind === 'adplace') { b.innerHTML = `<span>${ico(m.adk, 22)} Клікни на своїй території, де поставити засіб. Можна ставити кілька поспіль.</span><button id="bcancel">Готово</button>`; b.classList.remove('hidden'); }
  else if (m.kind === 'admove') { b.innerHTML = '<span>Клікни, куди перемістити засіб ППО</span><button id="bcancel">Скасувати</button>'; b.classList.remove('hidden'); }
  else if (m.kind === 'target') { b.innerHTML = `<span>${ico(m.what === 'drone' ? m.item : 'plane', 22)} Обери ціль: клікни по ворожому об’єкту, засобу ППО, місту чи підрозділу. Помаранчеве коло — дальність.</span><button id="bcancel">Скасувати</button>`; b.classList.remove('hidden'); }
  else if (m.kind === 'armyzone') { brush.clear(); previewBad = []; b.innerHTML = `<span>${m.purpose === 'defend' ? 'Зона оборони: малюй пензликом по своїй території' : 'Зона прориву: малюй пензликом по ворожій території, куди армія має прорватися'} (Shift — стирати, права кнопка — рух мапи). Пензель: <input type="range" id="bsz" min="1" max="30" value="${brushR}" style="width:90px"> <b id="bannerCost"></b></span><button id="bok">Готово</button><button class="ghost" id="bclr">Очистити</button><button id="bcancel">Скасувати</button>`; b.classList.remove('hidden'); $('#bsz').oninput = (e) => { brushR = +e.target.value; drawMap(); }; $('#bclr').onclick = () => { brush.clear(); atCalc(); }; $('#bok').onclick = armyZoneCommit; atCalc(); }
  else if (m.kind === 'place') { b.innerHTML = `<span>Розміщення: <b>${esc((FDEFS[m.fkind] || {}).n || m.fkind)}</b>. Клікни на своїй території. <b id="bannerCost"></b></span><button id="bcancel">Скасувати</button>`; b.classList.remove('hidden'); }
  else if (window.warBanner && warBanner(m, b)) { /* війна+: укріплення, десант */ }
  else if (window.admBanner && admBanner(m, b)) { /* адмін: родовища, столиці */ }
  else b.classList.add('hidden');
  const bc = $('#bcancel'); if (bc) bc.onclick = () => { if (m.kind === 'adplace') adPlaceKind = null; setMode({ kind: 'idle' }); }; drawMap(); renderSide();
}
// кнопка «побудувати»: вибір місця на мапі
async function startPlace(kind) {
  await loadFacs(); const d = FDEFS[kind]; if (!d) return toast('Невідомий об’єкт', true); showTab('map'); resSel = d.res && d.res !== 'steel' ? d.res : 'all';
  await setLayer(d.res && d.res !== 'steel' ? 'resources' : 'facilities'); setMode({ kind: 'place', fkind: kind });
}
async function focusCell(x, y) {
  showTab('map'); await setLayer('facilities'); const r = cv.getBoundingClientRect(), s = view.fs * 8; view.s = s; view.x = r.width / 2 - (x + .5) * land.cell * s; view.y = r.height / 2 - (y + .5) * land.cell * s;
  const f = myFacs.find((q) => q.x === x && q.y === y); selFac = f ? f.id : null; drawMap(); renderSide();
}
function renderSide() {
  const s = $('#side'); if (!me) return;
  if (!me.country) {
    s.innerHTML = `<h2>Створи державу</h2><p class="muted">Клікни на вільну сушу: там з'явиться столиця й територія навколо неї. Біля чужих кордонів ставити не можна.</p>
    <label for="cn">Назва держави</label><input id="cn" maxlength="30" value="${esc(founding.name)}"><label for="cc">Колір</label><input id="cc" type="color" value="${founding.color}">
    <div class="err" id="smsg"></div><button id="found" style="margin-top:10px">Заснувати державу</button><div id="exileBox"></div>`; if (window.exileBox) exileBox();
    $('#cn').oninput = (e) => founding.name = e.target.value; $('#cc').oninput = (e) => { founding.color = e.target.value; drawMap(); };
    $('#found').onclick = async () => { if (!pending) return sideMsg('Спочатку клікни на мапі'); try { await api('found', { ...pending, name: founding.name, color: founding.color }); pending = null; preview = []; await refreshMe(); if (window.tutorial && !tutSeen()) tutorial(); } catch (e) { sideMsg(e.message); } };
    return;
  }
  const u = selSet.size === 1 ? myUnits.find((x) => x.id === [...selSet][0]) : null, grp = selSet.size > 1 ? myUnits.filter((x) => selSet.has(x.id)) : [], f = myFacs.find((x) => x.id === selFac), showFac = layer === 'facilities' || layer === 'resources';
  // (21) стара права панель прибрана: шари, показ, кнопки й армії — у «Меню мапи» зліва; тут лише те, що вибрано на мапі
  let h = '';
  if (layer === 'resources') h += `<label for="rs">Який ресурс показати</label><select id="rs"><option value="all">Усі</option>${['oil', 'aluminium', 'chromium', 'tungsten', 'rubber', 'cotton'].map((r) => `<option value="${r}"${resSel === r ? ' selected' : ''}>${RESM[r].n}</option>`).join('')}</select>`;
  if (showFac && FDEFS && Object.keys(FDEFS).length) {
    const cnt = {}; myFacs.forEach((q) => cnt[q.kind] = (cnt[q.kind] || 0) + 1);
    h += `<div class="card pad" style="margin-top:12px"><h3>Об’єкти (${myFacs.length})</h3><div class="muted" style="font-size:13px;margin-bottom:6px">${Object.entries(cnt).map(([k, n]) => `${FDEFS[k].n} ×${n}`).join(' · ') || 'Об’єктів немає'}</div>
      <label for="bk" style="margin-top:4px">Побудувати</label><select id="bk">${Object.entries(FGROUPS).map(([g, gn]) => `<optgroup label="${gn}">${Object.keys(FDEFS).filter((k) => FDEFS[k].g === g).map((k) => `<option value="${k}">${FDEFS[k].n} — ${short(FDEFS[k].price || 0)} $, ${nf(FDEFS[k].days || 0, 1)} діб</option>`).join('')}</optgroup>`).join('')}</select>
      <button id="bgo" class="sm" style="margin-top:8px">Обрати місце на мапі</button></div>`;
  }
  if (layer === 'drones' || layer === 'air') h += adPanelHtml() + launchPanelHtml();
  if (layer === 'terrain' && window.fortPanelHtml) h += fortPanelHtml();
  if (f) { const d = FDEFS[f.kind]; h += `<div class="card pad"><h3>${ico(f.kind, 26)} ${d.n}${f.name ? ' «' + esc(f.name) + '»' : ''}</h3><div class="muted">(${f.x}, ${f.y}) · рівень ${f.level} з ${d.max}${f.upkeep ? ` · утримання ${exact(f.upkeep)} $/добу` : ''}</div><div style="margin:6px 0">${facOutText(f, d)}</div><p class="hint" style="margin:4px 0 8px">${d.d}</p>
    ${f.next && f.upkeep ? `<div class="hint" style="margin:0 0 8px">Після покращення утримання: ${exact(f.upkeepNext)} $/добу (дешевше, ніж ще один окремий об’єкт), але один удар знищить увесь об’єкт.</div>` : ''}
    <div class="row">${f.next ? `<button id="fup" class="sm">Покращити (${short(f.next)} $, ${nf(f.nextDays, 1)} діб)</button>` : ''}${['ship', 'port'].includes(f.kind) && window.openYard ? '<button id="fyard" class="sm">⚓ Корабельня</button>' : ''}<button id="fdel" class="danger sm">Знести</button></div></div>`; }
  else if (u) h += `<div class="card pad"><h3>${esc(u.name)}</h3><div class="muted">${UTN[u.type]} · ${exact(u.personnel)} о/с</div><div>Мораль ${nf(u.morale, 0)}% · Спорядженість ${nf(u.equipCov == null ? 0 : u.equipCov, 0)}%${u.speedMul != null && u.speedMul < 99 ? ` · швидкість ${u.speedMul}%` : ''}</div>${window.eqListHtml ? eqListHtml(u) : ''}${u.commander ? `<div>Командир: <b>${esc(u.commander.name)}</b></div>` : '<div class="muted">Без командира</div>'}${u.battle_id ? '<div class="warn">У бою</div>' : ''}${window.stanceHtml ? stanceHtml([u]) : ''}
    <div class="row" style="margin-top:8px"><button id="uo" class="sm"${u.battle_id ? ' disabled' : ''}>Наказ: рух / атака</button><button id="us" class="ghost sm">Стоп</button>${window.unitWarBtns ? unitWarBtns(u) : ''}${u.type === 'navy' || u.type === 'submarines' ? `<button id="ublk" class="${u.blockade ? '' : 'ghost'} sm" title="Радіус 30 кл.: у війну перехоплює ворожі конвої й блокує порти; у мирний час не пускає (або грабує) конвої держав, яким ти це задав у Торгівлі → Митна політика">${u.blockade ? 'Зняти блокаду' : 'Морська блокада'}</button>` : ''}</div></div>`;
  else if (grp.length) h += `<div class="card pad"><h3>Вибрано підрозділів: ${grp.length}</h3><div class="muted">${exact(grp.reduce((n, x) => n + x.personnel, 0))} о/с · середня мораль ${nf(grp.reduce((n, x) => n + x.morale, 0) / grp.length, 0)}%</div><div style="max-height:120px;overflow:auto;margin:6px 0;font-size:13px">${grp.map((x) => esc(x.name)).join(', ')}</div>${window.stanceHtml ? stanceHtml(grp) : ''}
    <div class="row"><button id="go1" class="sm">Наказ: рух / атака</button><button id="gl" class="sm">Вишикувати в лінію</button><button id="gs" class="ghost sm">Стоп</button><button id="gc" class="ghost sm">Зняти вибір</button></div></div>`;
  else if (card && card.own) h += `<div class="card pad"><h3>${esc(me.country.name)} (ти)</h3><div class="muted">Деталі: вкладка «Моя держава»</div></div>`;
  else if (card) h += dossierHtml(card, true);
  if (selVis) h += `<div class="card pad"><h3><span class="sw" style="background:${esc((countries[selVis.cid] || {}).color || '#888')}"></span>${esc(selVis.name)}</h3><div class="muted">${UTN[selVis.type] || selVis.type} · приблизно ${exact(selVis.approx)} о/с</div>${selVis.war ? '<div class="warn">Ви воюєте з цією державою</div>' : '<div class="muted">Мирна держава</div>'}<div class="row" style="margin-top:6px"><button class="ghost sm" id="vc">Вікно держави</button></div></div>`;
  s.innerHTML = h;
  const rs = $('#rs'); if (rs) rs.onchange = () => { resSel = rs.value; drawMap(); };
  const bgo = $('#bgo'); if (bgo) bgo.onclick = () => startPlace($('#bk').value);
  if (f) { const yd = $('#fyard'); if (yd) yd.onclick = () => openYard(f.id); } 
  if (f) { const up = $('#fup'); if (up) up.onclick = () => act(async () => { await api('fac/upgrade', { id: f.id }); await loadFacs(); renderSide(); }, 'Покращення додано до черги'); $('#fdel').onclick = () => { if (confirm(`Знести «${FDEFS[f.kind].n}»? Це не можна скасувати.`)) act(async () => { await api('fac/destroy', { id: f.id }); selFac = null; await refreshMe(); }, 'Об’єкт знесено'); }; }
  if (grp.length) { $('#go1').onclick = () => setMode({ kind: 'gorder' }); $('#gl').onclick = () => setMode({ kind: 'line' }); $('#gc').onclick = () => { selSet = new Set(); selUnit = null; drawMap(); renderSide(); }; $('#gs').onclick = () => act(async () => { for (const x of grp) await api('units/stop', { id: x.id }); await loadUnits(); }); }
  const vc = $('#vc'); if (vc) vc.onclick = () => window.openCountry && openCountry(selVis.cid);
  const sall = $('#sall'); if (sall) sall.onclick = () => { selSet = new Set(myUnits.filter((x) => (UTD[x.type] || 'land') === 'land' && !x.battle_id).map((x) => x.id)); selUnit = selSet.size === 1 ? [...selSet][0] : null; drawMap(); renderSide(); };
  if (u && window.bindUnitWar) bindUnitWar(u);
  if (u) { $('#uo').onclick = () => setMode({ kind: 'order', unit: u.id }); $('#us').onclick = () => act(async () => { await api('units/stop', { id: u.id }); await loadUnits(); }); const bl = $('#ublk'); if (bl) bl.onclick = () => act(async () => { const r = await api('units/blockade', { id: u.id, on: !u.blockade }); toast(u.blockade ? 'Блокаду знято' : `Блокаду оголошено${r.ports ? `: заблоковано портів ${r.ports}` : ''}`); await loadUnits(); await loadBlockades(); renderSide(); }); }
  if (layer === 'drones' || layer === 'air') bindAdPanel(); if (layer === 'terrain' && window.bindFortPanel) bindFortPanel();
  s.querySelectorAll('[data-go]').forEach((b) => b.onclick = () => { const [t, id] = b.dataset.go.split(':'); if (t === 'diplo') { if (window.openCountry) openCountry(+id, 'diplo'); } else { window.intelSel = +id; window.meSub = 'intel'; showTab('me'); } });
}
function facOutText(f, d) { return typeof facOut === 'function' ? facOut(f, d) : ''; }

// шар «Нації»: хто де живе
let natMap = null, natList = {}, natVer = 0;
async function loadNationsMap() { try { const d = await api('map/nations'); if (d.ver === natVer && natMap) return; natVer = d.ver; natList = {}; for (const n of d.nations) natList[n.id] = n; natMap = new Int32Array(land.gw * land.gh); let k = 0; for (let i = 0; i < d.rle.length; i += 2) { natMap.fill(d.rle[i], k, k + d.rle[i + 1]); k += d.rle[i + 1]; } } catch { natMap = null; } }
