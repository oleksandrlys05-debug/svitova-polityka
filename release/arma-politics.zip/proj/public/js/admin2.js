// Адмін: прапори, ідеології, резервні копії
ASUB.push(['flags', 'Прапори й ідеології'], ['backups', 'Резервні копії']);
async function aFlags(b) {
  const d = await api('owners'), list = d.countries;
  b.innerHTML = `<p class="hint" style="margin-top:0">Прапор можна замінити або видалити; гравець зможе завантажити свій знову. Ідеологію адмін може змінити одразу.</p>` + list.map((c) => `<div class="card pad" data-c="${c.id}"><div class="row"><span class="sw" style="background:${esc(c.color)}"></span><b>${esc(c.name)}</b> <span class="muted">${c.bot ? 'бот' : esc(c.owner || '')}</span>${c.flag ? `<img src="${flagUrl(c)}" alt="" style="height:36px;max-width:90px;border:1px solid #8886;border-radius:2px">` : '<span class="muted">без прапора</span>'}</div>
    <div class="row" style="margin-top:8px"><input type="file" accept="image/png,image/jpeg,image/svg+xml" class="ff" style="width:auto"><button class="sm fs">Замінити прапор</button>${c.flag ? '<button class="danger sm fd">Видалити прапор</button>' : ''}
      <select class="fi" style="width:auto">${Object.entries(IDN).map(([k, n]) => `<option value="${k}"${c.ideology === k ? ' selected' : ''}>${n}</option>`).join('')}</select><button class="ghost sm fis">Змінити ідеологію</button></div></div>`).join('');
  b.querySelectorAll('.card[data-c]').forEach((el) => { const cid = +el.dataset.c;
    el.querySelector('.fs').onclick = () => { const f = el.querySelector('.ff').files[0]; if (!f) return toast('Обери файл', true); const r = new FileReader(); r.onload = () => act(async () => { await api('admin/flag/set', { cid, data: r.result }); await refreshMe(); renderAdmin(); }, 'Прапор замінено'); r.readAsDataURL(f); };
    const fd = el.querySelector('.fd'); if (fd) fd.onclick = () => { if (confirm('Видалити прапор цієї держави?')) act(async () => { await api('admin/flag/delete', { cid }); await refreshMe(); renderAdmin(); }, 'Прапор видалено'); };
    el.querySelector('.fis').onclick = () => act(async () => { await api('admin/ideology', { cid, ideology: el.querySelector('.fi').value }); await refreshMe(); renderAdmin(); }, 'Ідеологію змінено'); });
}
async function aBackups(b) {
  const d = await api('admin/backups'), fmt = (t) => new Date(t).toLocaleString('uk-UA');
  b.innerHTML = `<div class="card pad"><h3>Резервні копії бази</h3><p class="hint" style="margin-top:0">Копії створюються автоматично кожні ${d.every} хв (зберігається останніх ${d.keep}). Інтервал і кількість — у «Налаштування світу» (backupMin, backupKeep). Відновлення зупиняє сервер: запусти його знову (start.bat), і гра повернеться до стану копії. Перед відновленням автоматично робиться копія поточного стану.</p>
    <div class="row"><button id="bkn">Створити копію зараз</button></div>
    ${d.items.length ? `<table style="margin-top:10px"><tr><th>Файл</th><th>Створено</th><th class="r">Розмір</th><th></th></tr>${d.items.map((x) => `<tr><td>${esc(x.name)}</td><td>${fmt(x.ts)}</td><td class="r">${nf(x.size / 1024 / 1024, 2)} МБ</td><td class="r"><button class="danger sm" data-rs="${esc(x.name)}">Відновити</button></td></tr>`).join('')}</table>` : '<p class="muted">Копій ще немає.</p>'}</div>`;
  $('#bkn').onclick = () => act(async () => { await api('admin/backup/create', {}); renderAdmin(); }, 'Копію створено');
  b.querySelectorAll('[data-rs]').forEach((x) => x.onclick = () => { if (confirm(`Відновити стан гри з копії ${x.dataset.rs}? Усе, що було після неї, буде втрачено. Сервер зупиниться.`)) act(async () => { const r = await api('admin/backup/restore', { name: x.dataset.rs }); if (r.restart && window.waitRestart) waitRestart('', 'Відновлюю гру з резервної копії…'); else alert(r.msg); }); });
}
