Сюди можна покласти свої іконки ресурсів (PNG, бажано 64x64 з прозорим фоном).
Назви файлів: aluminium.png, chromium.png, oil.png, rubber.png, steel.png, tungsten.png, fuel.png
Якщо файл є, сайт покаже його. Якщо ні, покаже вбудовану просту іконку.
