#!/data/data/com.termux/files/usr/bin/bash
# «Світова політика»: оновити гру (збереження не зачіпається).
#   bash update-android.sh         — завантажити найновішу версію з інтернету (GitHub); без інтернету — з архіву в «Завантаженнях»
#   bash update-android.sh local   — лише з архіву arma-politics.zip у «Завантаженнях»
#   bash update-android.sh check   — тихо перевірити й оновити, якщо є новіша (так робить start-android.sh)
REL=${SP_REL:-https://raw.githubusercontent.com/oleksandrlys05-debug/svitova-polityka/main/release}
G=~/proj; MODE=$1
verof() { grep -o '"version": *"[^"]*"' "$1" 2>/dev/null | head -1 | sed 's/.*"\([0-9.]*\)"$/\1/'; }
newer() { [ "$1" != "$2" ] && [ "$(printf '%s\n%s\n' "$1" "$2" | sort -V | tail -1)" = "$1" ]; }
install_zip() { [ -f "$G/stop-android.sh" ] && [ "$MODE" != "check" ] && bash "$G/stop-android.sh" >/dev/null 2>&1
  if [ -f "$G/data/game.db" ]; then mkdir -p "$G/data/backups"; cp "$G/data/game.db" "$G/data/backups/before-update-$(date +%Y%m%d-%H%M%S).db"; fi
  cd ~ && unzip -o -q "$1" || { echo "Не вдалося розпакувати архів."; return 1; }
  [ -f "$G/install-widget.sh" ] && bash "$G/install-widget.sh" quiet
  command -v termux-toast >/dev/null 2>&1 && termux-toast "Гру оновлено до $(verof "$G/package.json")"
  echo "Гру оновлено до версії $(verof "$G/package.json") (збереження на місці, резервна копія — у data/backups)."; }

if [ "$MODE" != "local" ]; then
  command -v curl >/dev/null 2>&1 || pkg install -y curl >/dev/null 2>&1
  command -v unzip >/dev/null 2>&1 || pkg install -y unzip >/dev/null 2>&1
  LJ=$(curl -fsSL --max-time 12 "$REL/latest.json?t=$(date +%s)" 2>/dev/null)
  if [ -n "$LJ" ]; then
    NEW=$(printf '%s' "$LJ" | grep -o '"version": *"[^"]*"' | head -1 | sed 's/.*"\([0-9.]*\)"$/\1/'); CUR=$(verof "$G/package.json"); CUR=${CUR:-0}
    if newer "$NEW" "$CUR"; then
      echo "Вийшло оновлення $NEW (у вас $CUR). Завантажую…"; TMP=$(mktemp -d)
      if curl -fSL --max-time 300 -o "$TMP/arma-politics.zip" "$REL/arma-politics.zip?t=$(date +%s)"; then install_zip "$TMP/arma-politics.zip"; R=$?; rm -rf "$TMP"; exit $R; fi
      rm -rf "$TMP"; echo "Не вдалося завантажити оновлення."; [ "$MODE" = "check" ] && exit 2
    else [ "$MODE" = "check" ] && exit 0; echo "У вас найновіша версія ($CUR)."; exit 0; fi
  else [ "$MODE" = "check" ] && { echo "Не вдалося перевірити оновлення (немає інтернету) — запускаю як є."; exit 0; }; echo "Немає інтернету — шукаю архів у «Завантаженнях»…"; fi
fi
DL=~/storage/downloads
[ -d "$DL" ] || { echo "Немає доступу до «Завантажень». Виконайте один раз: termux-setup-storage"; exit 1; }
ZIP=$(ls -t "$DL"/arma-politics*.zip 2>/dev/null | head -1)
[ -z "$ZIP" ] && { echo "У «Завантаженнях» немає arma-politics.zip. Спершу скачайте його туди."; exit 1; }
echo "Знайдено: $ZIP"; install_zip "$ZIP"
