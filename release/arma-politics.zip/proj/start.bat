@echo off
chcp 65001 >nul
node --no-warnings server.js
pause
