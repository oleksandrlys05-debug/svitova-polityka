#!/data/data/com.termux/files/usr/bin/bash
# «Світова політика»: запуск сервера на телефоні Android або окулярах Meta Quest (через Termux).
# Використання:  bash start-android.sh          — сервер + посилання для друзів через інтернет (Cloudflare)
#                bash start-android.sh local    — лише сервер (для гри в одній Wi-Fi мережі)
cd "$(dirname "$0")" || exit 1
PORT=${PORT:-3000}

# (21) сервер уже запущено? тоді просто показуємо посилання
if [ -f server.pid ] && kill -0 "$(cat server.pid)" 2>/dev/null; then
  echo "Сервер уже працює."; [ -f link.txt ] && echo "  Посилання для друзів:   $(cat link.txt)"; echo "  Гра на цьому пристрої:  http://localhost:$PORT"
  echo "Зупинити — ярлик «Зупинити гру» або: bash ~/proj/stop-android.sh"; exit 0
fi

# (21.1) оновлення обов’язкове: якщо вийшла новіша версія — спершу оновлюємось (без інтернету запускаємо як є)
if [ -z "$SP_NO_UPDATE" ] && [ -f update-android.sh ]; then bash update-android.sh check; R=$?; [ $R -eq 2 ] && { echo "Оновлення не завантажилось. Спробуйте ще раз (без оновлення друзі з новою версією не зайдуть)."; exit 1; }
  # скрипт міг оновитись — запускаємо вже нову версію
  if [ -z "$SP_UPDATED" ]; then SP_UPDATED=1 SP_NO_UPDATE=1 exec bash "$0" "$@"; fi; fi

# Node.js 22.13+ (вбудована база даних SQLite)
if ! command -v node >/dev/null 2>&1; then echo "Встановлюю Node.js…"; pkg update -y && pkg install -y nodejs-lts || pkg install -y nodejs; fi
V=$(node -e "const [a,b]=process.versions.node.split('.').map(Number);console.log(a*100+b)")
if [ "$V" -lt 2213 ]; then echo "Потрібен Node.js 22.13 або новіший (зараз $(node -v)). Виконайте: pkg upgrade -y && pkg install -y nodejs"; exit 1; fi

# не даємо Android приспати Termux, поки працює сервер
command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock

if [ "$1" != "local" ] && ! command -v cloudflared >/dev/null 2>&1; then echo "Встановлюю cloudflared (посилання для друзів)…"; pkg install -y cloudflared; fi

echo "Запускаю сервер гри на порту $PORT…"
PORT=$PORT node --no-warnings server.js &
SRV=$!
echo $SRV > server.pid; rm -f link.txt
sleep 4

IP=$(ifconfig 2>/dev/null | grep -A1 wlan0 | grep -o 'inet [0-9.]*' | cut -d' ' -f2)
[ -z "$IP" ] && IP=$(ip -4 addr show wlan0 2>/dev/null | grep -o 'inet [0-9.]*' | cut -d' ' -f2)
echo ""
echo "  Гра на цьому пристрої:  http://localhost:$PORT"
[ -n "$IP" ] && echo "  У тій самій Wi-Fi:      http://$IP:$PORT"

if [ "$1" != "local" ] && command -v cloudflared >/dev/null 2>&1; then
  rm -f cf.log
  cloudflared tunnel --no-autoupdate --protocol http2 --url "http://localhost:$PORT" > cf.log 2>&1 &
  CF=$!
  echo $CF > cf.pid
  for i in $(seq 1 40); do URL=$(grep -o 'https://[a-z0-9-]*\.trycloudflare\.com' cf.log 2>/dev/null | head -1); [ -n "$URL" ] && break; sleep 1; done
  if [ -n "$URL" ]; then
    echo "  Посилання для друзів:   $URL"; echo "$URL" > link.txt
    # Termux:API (необов’язково): посилання — у буфер обміну й у сповіщення з кнопками
    if command -v termux-clipboard-set >/dev/null 2>&1; then
      echo -n "$URL" | termux-clipboard-set && echo "  (посилання скопійовано — просто вставте його друзям у месенджер)"
      command -v termux-toast >/dev/null 2>&1 && termux-toast "Гра запущена. Посилання скопійовано"
      command -v termux-notification >/dev/null 2>&1 && termux-notification --id svitpol --ongoing --title "Світова політика: сервер працює" --content "$URL" \
        --button1 "Поділитися" --button1-action "termux-share -a send '$URL'" --button2 "Копіювати" --button2-action "echo -n '$URL' | termux-clipboard-set" \
        --button3 "Зупинити" --button3-action "bash $(pwd)/stop-android.sh"
    fi
  else echo "  Посилання не з’явилося (перевірте інтернет). Подробиці: cf.log"; fi
fi
echo ""
echo "Щоб зупинити сервер — Ctrl+C (або закрийте сесію Termux)."
trap 'kill $SRV $CF 2>/dev/null; rm -f server.pid cf.pid link.txt; command -v termux-notification-remove >/dev/null 2>&1 && termux-notification-remove svitpol; command -v termux-wake-unlock >/dev/null 2>&1 && termux-wake-unlock; exit 0' INT TERM
wait $SRV
rm -f server.pid cf.pid link.txt; [ -n "$CF" ] && kill $CF 2>/dev/null
command -v termux-notification-remove >/dev/null 2>&1 && termux-notification-remove svitpol
