// Політична гра Arma 3: точка входу (Node.js 22.13+, без залежностей).
// Запускає гру (game.js) і перезапускає її, коли гра просить (код виходу 75): новий світ на іншій мапі, відновлення з резервної копії.
const { fork } = require('child_process'), path = require('path');
let child = null, stopping = false;
const start = () => {
  child = fork(path.join(__dirname, 'game.js'), process.argv.slice(2), { stdio: 'inherit', execArgv: process.execArgv });
  child.on('exit', (code) => { child = null; if (stopping) return process.exit(code || 0); if (code === 75) { console.log('Перезапуск світу…'); return setTimeout(start, 400); } process.exit(code == null ? 1 : code); });
};
for (const s of ['SIGINT', 'SIGTERM', 'SIGHUP', 'SIGBREAK']) { try { process.on(s, () => { stopping = true; if (child) child.kill(); else process.exit(0); }); } catch { /* сигнал не підтримується */ } }
process.on('exit', () => { if (child) { try { child.kill(); } catch { /* вже немає */ } } });
start();
