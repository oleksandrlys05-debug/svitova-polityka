#!/data/data/com.termux/files/usr/bin/bash
# «Світова політика»: зупинити сервер на телефоні (Termux)
cd "$(dirname "$0")" || exit 1
for f in server.pid cf.pid; do [ -f "$f" ] && kill "$(cat "$f")" 2>/dev/null; rm -f "$f"; done
pkill -f "node --no-warnings server.js" 2>/dev/null; pkill -f "cloudflared tunnel" 2>/dev/null
rm -f link.txt
command -v termux-notification-remove >/dev/null 2>&1 && termux-notification-remove svitpol
command -v termux-wake-unlock >/dev/null 2>&1 && termux-wake-unlock
command -v termux-toast >/dev/null 2>&1 && termux-toast "Сервер гри зупинено"
echo "Сервер гри зупинено."
