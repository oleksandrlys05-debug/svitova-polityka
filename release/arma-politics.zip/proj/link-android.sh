#!/data/data/com.termux/files/usr/bin/bash
# «Світова політика»: показати / скопіювати / надіслати посилання для друзів
cd "$(dirname "$0")" || exit 1
if [ ! -f link.txt ]; then echo "Посилання ще немає: спочатку запустіть гру (ярлик «Запустити гру»)."; command -v termux-toast >/dev/null 2>&1 && termux-toast "Спершу запустіть гру"; exit 1; fi
URL=$(cat link.txt); echo "Посилання для друзів: $URL"
if command -v termux-share >/dev/null 2>&1; then echo -n "$URL" | termux-clipboard-set; termux-share -a send "$URL"; else echo "(Щоб надсилати одним дотиком — встановіть Termux:API, див. інструкцію)"; fi
