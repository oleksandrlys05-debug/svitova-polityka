// «Світова політика»: лобі з кількома іграми на одному сервері (оновлення 21.2).
// Кожна гра — окремий процес game.js зі своєю текою збереження. З 21.4 акаунт один на всі ігри: лобі його зберігає, а в гру входить сам (SSO). Лобі приймає всіх на одному порту
// і пересилає запити в обрану гру (за кукі spw). Нова гра спершу 5 хвилин чекає голосування за мапу.
// Адмін лобі — той, хто відкриває гру на самому комп'ютері-хості (не через посилання/тунель).
const http = require('http'), net = require('net'), fs = require('fs'), path = require('path'), crypto = require('crypto'), { fork } = require('child_process');
const ROOT = __dirname, DATA = process.env.GAME_DATA || path.join(ROOT, 'data'), PORT = +process.env.PORT || 3000;
const GAME_VER = require('./package.json').version, MAPS = require('./lib/maps.js').LIST;
const VOTE_MS = +process.env.SP_VOTE_MS || 5 * 60 * 1000, MIN_GAMES = 3, MAX_PER_PLAYER = 2;
const STATE_F = path.join(DATA, 'lobby.json');
fs.mkdirSync(DATA, { recursive: true });

// ---------- стан ----------
let S = null;
const save = () => { const t = STATE_F + '.tmp'; fs.writeFileSync(t, JSON.stringify(S, null, 1)); fs.renameSync(t, STATE_F); };
const dirOf = (g) => (g.dir === '.' ? DATA : path.join(DATA, g.dir));
const mapDir = (id) => (id === 'classic' ? path.join(ROOT, 'data') : path.join(ROOT, 'maps', id));
const maps = () => MAPS.filter((m) => fs.existsSync(path.join(mapDir(m.id), 'land.json')));
const mapName = (id) => (MAPS.find((m) => m.id === id) || { name: id }).name;
const readMap = (dir) => { try { return JSON.parse(fs.readFileSync(path.join(dir, 'map.json'), 'utf8')).id || 'classic'; } catch { return 'classic'; } };
const newGame = () => { const id = Math.max(0, ...S.games.map((g) => g.id)) + 1; const g = { id, name: `Гра ${id}`, status: 'voting', map: null, dir: id === 1 && !S.games.length ? '.' : `worlds/${id}`, voteEnds: Date.now() + VOTE_MS, votes: {}, created: Date.now() }; S.games.push(g); return g; };
try { S = JSON.parse(fs.readFileSync(STATE_F, 'utf8')); } catch { S = null; }
if (!S) { S = { games: [], members: {}, secret: crypto.randomBytes(18).toString('hex') };
  if (fs.existsSync(path.join(DATA, 'game.db'))) S.games.push({ id: 1, name: 'Гра 1', status: 'running', map: readMap(DATA), dir: '.', created: Date.now() }); // теперішній світ — «Гра 1»
  while (S.games.filter((g) => g.status !== 'closed').length < MIN_GAMES) newGame(); save(); }
const SECRET = S.secret;
if (S.approveNew === undefined) S.approveNew = true;

// ---------- (21.4) акаунти: один на всі ігри ----------
const ACC_F = path.join(DATA, 'accounts.json');
let A = null; try { A = JSON.parse(fs.readFileSync(ACC_F, 'utf8')); } catch { A = { users: [], sessions: {}, wsess: {} }; }
const saveAcc = () => { const t = ACC_F + '.tmp'; fs.writeFileSync(t, JSON.stringify(A)); fs.renameSync(t, ACC_F); };
const hashPw = (pw, salt) => crypto.scryptSync(pw, salt, 32).toString('hex');
const userById = (id) => A.users.find((u) => u.id === id) || null;
const acctOf = (req) => { const t = cookies(req).spl; const id = t && A.sessions[t]; return id ? userById(id) : null; };
const newSess = (uid) => { const t = crypto.randomBytes(24).toString('hex'); A.sessions[t] = uid; saveAcc(); return `spl=${t}; Path=/; HttpOnly; SameSite=Lax; Max-Age=31536000`; };
// запит до гри від імені лобі (з секретом)
const worldPost = (g, p, b) => new Promise((resolve) => { const P = procs.get(g.id); if (!P || !P.ready) return resolve(null); const data = JSON.stringify(b || {});
  const r = http.request({ host: '127.0.0.1', port: P.port, method: 'POST', path: p, headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data), 'x-sp-secret': SECRET }, timeout: 8000 }, (res) => { let t = ''; res.on('data', (c) => (t += c)); res.on('end', () => { try { resolve({ code: res.statusCode, ...JSON.parse(t) }); } catch { resolve(null); } }); });
  r.on('error', () => resolve(null)); r.on('timeout', () => r.destroy()); r.end(data); });
// старі акаунти в іграх із тим самим ніком і паролем прив'язуються самі
const linkAll = async (u, pw) => { const out = []; for (const g of S.games.filter((x) => x.status === 'running')) { const r = await worldPost(g, '/api/lobby/link', { uid: u.id, name: u.name, password: pw }); if (r && r.linked) { delete A.wsess[`${u.id}:${g.id}`]; out.push(g.id); } } if (out.length) { if (!u.approved) u.approved = true; saveAcc(); } return out; };
const worldSid = async (u, g, host) => { const k = `${u.id}:${g.id}`; if (A.wsess[k]) return A.wsess[k]; const r = await worldPost(g, '/api/lobby/sso', { uid: u.id, name: u.name, email: u.email, host: !!host }); if (!r || !r.sid) return null; A.wsess[k] = r.sid; saveAcc(); return r.sid; };

// ---------- процеси ігор ----------
const procs = new Map(); // id -> { child, port, ready, stopping }
const freePort = () => new Promise((res, rej) => { const s = net.createServer(); s.unref(); s.on('error', rej); s.listen(0, '127.0.0.1', () => { const p = s.address().port; s.close(() => res(p)); }); });
const log = (...a) => console.log('[лобі]', ...a);
const startWorld = async (g) => {
  if (procs.has(g.id) || g.status !== 'running') return; const dir = dirOf(g); fs.mkdirSync(dir, { recursive: true });
  if (g.map && !fs.existsSync(path.join(dir, 'game.db'))) fs.writeFileSync(path.join(dir, 'map.json'), JSON.stringify({ id: g.map }));
  const port = await freePort(), P = { child: null, port, ready: false, stopping: false, fails: 0 }; procs.set(g.id, P);
  const run = () => { P.ready = false;
    P.child = fork(path.join(ROOT, 'game.js'), [], { stdio: 'inherit', execArgv: process.execArgv, env: { ...process.env, PORT: String(port), GAME_DATA: dir, LOBBY_SECRET: SECRET, WORLD_ID: String(g.id), WORLD_NAME: g.name } });
    P.child.on('exit', (code) => { P.child = null; P.ready = false; if (P.stopping) return procs.delete(g.id);
      if (code === 75) { log(`${g.name}: перезапуск світу`); return setTimeout(run, 400); }
      P.fails++; log(`${g.name}: процес завершився (код ${code}), перезапуск через ${Math.min(30, P.fails * 3)} с`); setTimeout(run, Math.min(30000, P.fails * 3000)); });
    const ping = () => { if (!P.child) return; const r = http.get({ host: '127.0.0.1', port, path: '/api/ping', timeout: 2000 }, (res) => { res.resume(); P.ready = true; P.fails = 0; }); r.on('error', () => setTimeout(ping, 400)); r.on('timeout', () => r.destroy()); };
    setTimeout(ping, 300); };
  run(); };
const stopWorld = (id) => new Promise((res) => { const P = procs.get(id); if (!P || !P.child) { procs.delete(id); return res(); } P.stopping = true; P.child.once('exit', () => res()); P.child.kill(); setTimeout(res, 5000); });

// ---------- голосування ----------
const finishVote = (g) => { const counts = {}; for (const m of Object.values(g.votes || {})) counts[m] = (counts[m] || 0) + 1;
  const av = maps().map((m) => m.id), top = Math.max(0, ...Object.values(counts)), best = top ? Object.keys(counts).filter((k) => counts[k] === top && av.includes(k)) : av;
  g.map = best[Math.floor(Math.random() * best.length)] || 'classic'; g.result = counts; g.status = 'running'; g.started = Date.now(); delete g.voteEnds; save();
  log(`${g.name}: голосування завершено — мапа «${mapName(g.map)}»`); startWorld(g); };
setInterval(() => { for (const g of S.games) if (g.status === 'voting' && Date.now() >= g.voteEnds) finishVote(g); }, 1000);

// ---------- допоміжне ----------
const cookies = (req) => Object.fromEntries(String(req.headers.cookie || '').split(';').map((x) => x.trim()).filter(Boolean).map((x) => { const i = x.indexOf('='); return [x.slice(0, i), x.slice(i + 1)]; }));
const clientIp = (req) => String(req.headers['cf-connecting-ip'] || req.socket.remoteAddress || '').split(',')[0].trim();
// хост — запит із самого комп'ютера, не через тунель Cloudflare
const isHost = (req) => /^(127\.|::1$|::ffff:127\.)/.test(String(req.socket.remoteAddress || '')) && !req.headers['cf-connecting-ip'] && !req.headers['cf-ray'] && !req.headers['x-forwarded-for'];
const json = (res, code, o, hdr = {}) => { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...hdr }); res.end(JSON.stringify(o)); };
const body = (req) => new Promise((r) => { let b = ''; req.on('data', (c) => { b += c; if (b.length > 1e5) req.destroy(); }); req.on('end', () => { try { r(JSON.parse(b || '{}')); } catch { r({}); } }); });
const verCmp = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d; } return 0; };
const oldApp = (req) => { const ua = String(req.headers['user-agent'] || ''); if (!/Electron\//.test(ua)) return null; const toks = [...ua.matchAll(/SvitovaPolityka\/([\d.]+)/g)].map((x) => x[1]).sort((a, b) => verCmp(b, a)), self = toks.length >= 2, v = toks[0] || '0'; return verCmp(v, GAME_VER) < 0 ? (self ? v : 'стара') : null; };
const devOf = (req, res) => { let d = cookies(req).spdev; if (!/^[a-f0-9]{24}$/.test(d || '')) { d = crypto.randomBytes(12).toString('hex'); res.__dev = `spdev=${d}; Path=/; SameSite=Lax; Max-Age=315360000`; } return d; };
const myGames = (key) => (S.members[key] || []).filter((id) => S.games.some((g) => g.id === id && g.status !== 'closed'));
const info = new Map(); // кеш довідки ігор
const fetchInfo = (g) => { const P = procs.get(g.id); if (!P || !P.ready) return; const r = http.get({ host: '127.0.0.1', port: P.port, path: '/api/lobbyinfo', headers: { 'x-sp-secret': SECRET }, timeout: 3000 }, (res) => { let b = ''; res.on('data', (c) => (b += c)); res.on('end', () => { try { info.set(g.id, JSON.parse(b)); } catch { /* ні */ } }); }); r.on('error', () => {}); r.on('timeout', () => r.destroy()); };
setInterval(() => { for (const g of S.games) if (g.status === 'running') fetchInfo(g); }, 5000);

const view = (req, dev, me) => ({ version: GAME_VER, host: isHost(req), max: MAX_PER_PLAYER, mine: me ? myGames(`u${me.id}`) : [], now: Date.now(), cur: +cookies(req).spw || 0,
  me: me ? { id: me.id, name: me.name, approved: !!me.approved || isHost(req) } : null, approveNew: !!S.approveNew,
  pending: isHost(req) ? A.users.filter((u) => !u.approved).map((u) => ({ id: u.id, name: u.name, email: u.email, created: u.created })) : [],
  maps: maps().map((m) => ({ id: m.id, name: m.name, desc: m.desc, img: `/lobby/maps/${m.id}.png` })),
  games: S.games.filter((g) => g.status !== 'closed').map((g) => { const P = procs.get(g.id), i = info.get(g.id) || {}, counts = {};
    if (g.status === 'voting') for (const m of Object.values(g.votes || {})) counts[m] = (counts[m] || 0) + 1;
    const vk = me ? `u${me.id}` : dev;
    return { id: g.id, name: g.name, status: g.status, map: g.map, mapName: g.map ? mapName(g.map) : '', left: g.voteEnds ? Math.max(0, g.voteEnds - Date.now()) : 0, counts, myVote: g.votes ? g.votes[vk] || null : null,
      ready: !!(P && P.ready), day: i.day, players: i.players, users: i.users, paused: i.paused }; }) });

// ---------- сторінки й API лобі ----------
const LOBBY_HTML = path.join(ROOT, 'public', 'lobby.html');
const lobbyApi = async (req, res, url) => {
  const dev = devOf(req, res), hdr = res.__dev ? { 'Set-Cookie': res.__dev } : {}, p = url.pathname, host = isHost(req);
  const fail = (m, code = 400) => json(res, code, { error: m }, hdr);
  const me = acctOf(req);
  if (p === '/lobby/api/state') return json(res, 200, view(req, dev, me), hdr);
  if (req.method !== 'POST') return fail('Не знайдено', 404);
  const b = await body(req), g = S.games.find((x) => x.id === +b.game && x.status !== 'closed');
  // ---- акаунт ----
  if (p === '/lobby/api/register') { const name = String(b.name || '').trim(), pw = String(b.password || ''), email = String(b.email || '').trim().toLowerCase();
    if (!/^[\p{L}\p{N}_ -]{3,20}$/u.test(name)) return fail('Нік: 3–20 символів (літери, цифри, _ - пробіл)'); if (pw.length < 4) return fail('Пароль має містити мінімум 4 символи');
    if (!/^[^\s@<>]{1,64}@[^\s@<>]{1,120}\.[a-zа-яіїєґ]{2,24}$/iu.test(email)) return fail('Вкажіть справжню електронну пошту (наприклад, ім’я@gmail.com)');
    if (A.users.some((u) => u.name.toLowerCase() === name.toLowerCase())) return fail('Цей нік уже зайнятий'); if (A.users.some((u) => u.email === email)) return fail('На цю пошту вже зареєстровано акаунт');
    const ip = clientIp(req); if (!host && A.users.filter((u) => u.ip === ip && u.created > Date.now() - 864e5).length >= 3) return fail('З цієї адреси вже створено 3 акаунти за добу. Спробуйте завтра.', 429);
    const salt = crypto.randomBytes(12).toString('hex'), u = { id: Math.max(0, ...A.users.map((x) => x.id)) + 1, name, email, salt, hash: hashPw(pw, salt), approved: host || !S.approveNew, created: Date.now(), ip };
    A.users.push(u); saveAcc(); const linked = await linkAll(u, pw);
    return json(res, 200, { ok: true, approved: !!u.approved, linked: linked.length }, { 'Set-Cookie': [res.__dev, newSess(u.id)].filter(Boolean) }); }
  if (p === '/lobby/api/login') { const u = A.users.find((x) => x.name.toLowerCase() === String(b.name || '').trim().toLowerCase());
    if (!u || hashPw(String(b.password || ''), u.salt) !== u.hash) return fail('Невірний нік або пароль'); if (u.banned) return fail('Акаунт заблоковано', 403);
    await linkAll(u, String(b.password || '')); return json(res, 200, { ok: true }, { 'Set-Cookie': [res.__dev, newSess(u.id)].filter(Boolean) }); }
  if (p === '/lobby/api/logout') { const t = cookies(req).spl; if (t) { delete A.sessions[t]; saveAcc(); } return json(res, 200, { ok: true }, { 'Set-Cookie': 'spl=; Path=/; Max-Age=0' }); }
  if (p === '/lobby/api/vote') { if (!g || g.status !== 'voting') return fail('Голосування вже завершено'); if (!maps().some((m) => m.id === b.map)) return fail('Невідома мапа'); g.votes[me ? `u${me.id}` : dev] = b.map; save(); return json(res, 200, { ok: true }, hdr); }
  if (!me && ['/lobby/api/link', '/lobby/api/enter', '/lobby/api/leave'].includes(p)) return fail(host ? 'Щоб грати, створіть собі акаунт і в лобі (адміністратор теж)' : 'Спершу увійдіть або зареєструйтесь', 401);
  // прив'язати старий акаунт гри (якщо в грі інший нік чи пароль)
  if (p === '/lobby/api/link') { if (!g || g.status !== 'running') return fail('Гру не знайдено'); const r = await worldPost(g, '/api/lobby/link', { uid: me.id, name: b.name, password: b.password });
    if (!r) return fail('Гра не відповідає, спробуйте ще раз'); if (r.taken) return fail('Цей акаунт гри вже прив’язаний до іншого гравця'); if (!r.linked) return fail('Невірний нік або пароль у цій грі');
    delete A.wsess[`${me.id}:${g.id}`]; if (!me.approved) me.approved = true; saveAcc(); return json(res, 200, { ok: true, message: `Готово: у «${g.name}» ви тепер граєте за «${r.name}»${r.country ? ` (${r.country})` : ''}.` }, hdr); }
  if (p === '/lobby/api/enter') { if (!g || g.status !== 'running') return fail('Ця гра ще не почалась');
    if (!me.approved && !host) return fail('Ваш акаунт ще чекає схвалення адміністратора сервера.');
    const key = `u${me.id}`, mine = myGames(key); if (!host && !mine.includes(g.id) && mine.length >= MAX_PER_PLAYER) return fail(`Можна грати максимум у ${MAX_PER_PLAYER} іграх. Спершу покиньте одну з них (кнопка «Покинути»).`);
    return json(res, 200, { ok: true }, { ...hdr, 'Set-Cookie': [res.__dev, `spw=${g.id}; Path=/; SameSite=Lax; Max-Age=315360000`, `spwn=${encodeURIComponent(g.name)}; Path=/; SameSite=Lax; Max-Age=315360000`].filter(Boolean) }, void (!host && !mine.includes(g.id) && (S.members[key] = [...mine, g.id], save()))); }
  if (p === '/lobby/api/leave') { S.members[`u${me.id}`] = (S.members[`u${me.id}`] || []).filter((id) => id !== +b.game); save(); return json(res, 200, { ok: true, message: 'Ви покинули гру в лобі: тепер можна зайти в іншу. Ваш акаунт і держава в тій грі лишаються, поки адмін гри їх не видалить.' }, hdr); }
  // ---- далі — лише господар сервера ----
  if (!host) return fail('Це може лише адміністратор (на комп’ютері, де запущено сервер)', 403);
  if (p === '/lobby/api/approve') { const u = userById(+b.uid); if (!u) return fail('Гравця не знайдено'); if (b.no) { A.users = A.users.filter((x) => x.id !== u.id); for (const [t, id] of Object.entries(A.sessions)) if (id === u.id) delete A.sessions[t]; } else u.approved = true; saveAcc(); return json(res, 200, { ok: true }, hdr); }
  if (p === '/lobby/api/approvenew') { S.approveNew = !!b.on; save(); return json(res, 200, { ok: true }, hdr); }
  if (p === '/lobby/api/create') { const n = newGame(); save(); return json(res, 200, { ok: true, id: n.id }, hdr); }
  if (!g) return fail('Гру не знайдено', 404);
  if (p === '/lobby/api/endvote') { if (g.status !== 'voting') return fail('Голосування вже завершено'); finishVote(g); return json(res, 200, { ok: true }, hdr); }
  if (p === '/lobby/api/rename') { const n = String(b.name || '').trim().slice(0, 40); if (!n) return fail('Вкажіть назву'); g.name = n; save(); const P = procs.get(g.id); if (P) { await stopWorld(g.id); startWorld(g); } return json(res, 200, { ok: true }, hdr); }
  if (p === '/lobby/api/close') { if (S.games.filter((x) => x.status !== 'closed').length <= 1) return fail('Має лишитися хоча б одна гра'); await stopWorld(g.id); g.status = 'closed'; g.closed = Date.now(); save();
    return json(res, 200, { ok: true, message: `«${g.name}» закрито. Її збереження лишилось у теці ${g.dir === '.' ? 'data' : 'data/' + g.dir}.` }, hdr); }
  return fail('Не знайдено', 404);
};

// ---------- пересилання запитів у гру (вхід — акаунтом лобі) ----------
const proxy = async (req, res, g, dev) => {
  const P = procs.get(g.id), host = isHost(req), me = acctOf(req), isApi = req.url.startsWith('/api/');
  if (!P || !P.ready) { if (isApi) return json(res, 503, { error: 'Гра запускається, спробуйте за кілька секунд' }); res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' }); return res.end('<!DOCTYPE html><meta charset="utf-8"><meta http-equiv="refresh" content="2"><body style="background:#0f0d1a;color:#ece9f7;font:18px system-ui;display:flex;align-items:center;justify-content:center;height:100vh">Гра запускається…</body>'); }
  const toLobby = (msg) => { if (isApi) return json(res, 401, { error: msg, lobby: true }); res.writeHead(302, { Location: '/lobby', 'Cache-Control': 'no-store' }); return res.end(); };
  if (!me) return toLobby('Увійдіть у лобі');
  if (!me.approved && !host) return toLobby('Акаунт чекає схвалення адміністратора');
  const pth = req.url.split('?')[0];
  if (pth === '/api/register' || pth === '/api/login') return json(res, 400, { error: 'Вхід і реєстрація — у лобі (кнопка «◂ Ігри»)', lobby: true });
  if (pth === '/api/logout') { const t = cookies(req).spl; if (t) { delete A.sessions[t]; saveAcc(); } return json(res, 200, { ok: true }, { 'Set-Cookie': 'spl=; Path=/; Max-Age=0' }); }
  const sid = await worldSid(me, g, host); if (!sid) return json(res, 502, { error: 'Не вдалося увійти в гру, спробуйте ще раз' });
  const h = { ...req.headers }; delete h['x-sp-local']; delete h['x-sp-secret']; h.cookie = `sid=${sid}`;
  if (!h['cf-connecting-ip']) h['x-forwarded-for'] = clientIp(req); if (host) h['x-sp-local'] = SECRET;
  const up = http.request({ host: '127.0.0.1', port: P.port, method: req.method, path: req.url, headers: h }, (r) => {
    // сесія в грі зникла (світ перестворено) — наступний запит увійде заново
    if (r.statusCode === 401) { r.resume(); delete A.wsess[`${me.id}:${g.id}`]; saveAcc(); return json(res, 401, { error: 'Сесію оновлено — перезавантажте сторінку', relogin: true }); }
    const out = { ...r.headers }; delete out['set-cookie']; if (res.__dev) out['set-cookie'] = [res.__dev];
    res.writeHead(r.statusCode, out); r.pipe(res); });
  up.on('error', () => { if (!res.headersSent) json(res, 502, { error: 'Гра не відповідає, спробуйте ще раз' }); else res.end(); });
  req.on('aborted', () => up.destroy()); res.on('close', () => up.destroy());
  req.pipe(up);
};

const oldPage = (v) => `<!DOCTYPE html><html lang="uk"><head><meta charset="utf-8"><title>Потрібне оновлення</title></head><body style="margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#0f0d1a;color:#ece9f7;font:16px/1.6 system-ui"><div style="max-width:600px;background:#1b1830;border:1px solid #2e2a48;border-radius:20px;padding:28px 32px"><h1 style="margin-top:0">Спершу оновіть гру</h1><p>На сервері версія <b>${GAME_VER}</b>, у вашій програмі — <b>${v}</b>.</p><p>${v === 'стара' ? 'Один раз завантажте нову програму: <a style="color:#c4a5ff" href="https://github.com/oleksandrlys05-debug/svitova-polityka#readme">сторінка гри</a>. Далі вона оновлюватиметься сама.' : 'Закрийте програму й відкрийте знову — натисніть «Оновити зараз».'}</p></div></body></html>`;

http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x'), p = url.pathname;
    if (p === '/api/version') return json(res, 200, { version: GAME_VER, game: 'svitova-polityka', lobby: true });
    if (p === '/api/ping') return json(res, 200, { ok: true });
    const ov = oldApp(req); if (ov) { if (p.startsWith('/api/') || p.startsWith('/lobby/api/')) return json(res, 426, { error: `Спершу оновіть гру: на сервері версія ${GAME_VER}, у вас ${ov}.`, update: GAME_VER }); if (!/\.(js|css|png|jpg|svg|ico|woff2?)$/.test(p)) { res.writeHead(426, { 'Content-Type': 'text/html; charset=utf-8' }); return res.end(oldPage(ov)); } }
    if (p === '/lobby' || p === '/lobby/') { const dev = devOf(req, res); res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store', ...(res.__dev ? { 'Set-Cookie': res.__dev } : {}) }); void dev; return fs.createReadStream(LOBBY_HTML).pipe(res); }
    if (p.startsWith('/lobby/maps/')) { const id = path.basename(p, '.png'); const f = path.join(ROOT, 'public', 'img', 'maps', `${id}.png`); if (!/^[a-z0-9]+$/.test(id) || !fs.existsSync(f)) { res.writeHead(404); return res.end(); } res.writeHead(200, { 'Content-Type': 'image/png', 'Cache-Control': 'max-age=86400' }); return fs.createReadStream(f).pipe(res); }
    if (p.startsWith('/lobby/api/')) return await lobbyApi(req, res, url);
    const dev = devOf(req, res), w = +cookies(req).spw || 0, g = S.games.find((x) => x.id === w && x.status === 'running');
    if (!g) { if (p.startsWith('/api/')) return json(res, 409, { error: 'Спершу оберіть гру в лобі', lobby: true }); res.writeHead(302, { Location: '/lobby', 'Cache-Control': 'no-store', ...(res.__dev ? { 'Set-Cookie': res.__dev } : {}) }); return res.end(); }
    return await proxy(req, res, g, dev);
  } catch (e) { console.error('[лобі]', e); if (!res.headersSent) json(res, 500, { error: 'Помилка лобі' }); }
}).listen(PORT, () => { log(`Лобі запущено: http://localhost:${PORT}/lobby  (ігор: ${S.games.filter((g) => g.status !== 'closed').length})`); for (const g of S.games) if (g.status === 'running') startWorld(g); });

const shutdown = async () => { for (const id of [...procs.keys()]) await stopWorld(id); process.exit(0); };
for (const s of ['SIGINT', 'SIGTERM', 'SIGHUP', 'SIGBREAK']) { try { process.on(s, shutdown); } catch { /* сигнал не підтримується */ } }
process.on('exit', () => { for (const P of procs.values()) { try { P.child && P.child.kill(); } catch { /* ні */ } } });
