#!/data/data/com.termux/files/usr/bin/bash
# «Світова політика»: ярлики для запуску однією кнопкою (Termux:Widget) і автозапуск (Termux:Boot)
#   bash ~/proj/install-widget.sh        — створити ярлики
#   bash ~/proj/install-widget.sh boot   — ще й автозапуск сервера після ввімкнення телефона
P=~/proj
mkdir -p ~/.shortcuts ~/.shortcuts/icons 2>/dev/null
mk() { printf '#!/data/data/com.termux/files/usr/bin/bash\n%s\n' "$2" > ~/.shortcuts/"$1"; chmod +x ~/.shortcuts/"$1"; }
mk "Запустити гру" "bash $P/start-android.sh"
mk "Зупинити гру" "bash $P/stop-android.sh; sleep 2"
mk "Оновити гру з Завантажень" "bash $P/update-android.sh; sleep 4"
mk "Посилання для друзів" "bash $P/link-android.sh; sleep 3"
[ -f $P/public/img/app-192.png ] && for n in "Запустити гру" "Зупинити гру" "Оновити гру з Завантажень" "Посилання для друзів"; do cp $P/public/img/app-192.png ~/.shortcuts/icons/"$n.png" 2>/dev/null; done
if [ "$1" = "boot" ]; then
  mkdir -p ~/.termux/boot
  printf '#!/data/data/com.termux/files/usr/bin/bash\ntermux-wake-lock\nbash %s/start-android.sh > %s/boot.log 2>&1\n' "$P" "$P" > ~/.termux/boot/svitova-polityka; chmod +x ~/.termux/boot/svitova-polityka
  echo "Автозапуск увімкнено (потрібен застосунок Termux:Boot, відкрийте його один раз). Вимкнути: rm ~/.termux/boot/svitova-polityka"
fi
command -v termux-clipboard-set >/dev/null 2>&1 || { [ "$1" = "quiet" ] || echo "Порада: pkg install -y termux-api (+ застосунок Termux:API) — тоді посилання саме копіюється й ним можна поділитися."; }
[ "$1" = "quiet" ] || echo "Готово! Додайте на головний екран віджет Termux:Widget — там будуть кнопки: «Запустити гру», «Зупинити гру», «Оновити гру з Завантажень», «Посилання для друзів»."
