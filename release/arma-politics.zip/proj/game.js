// Політична гра Arma 3: сама гра (запускає server.js, який перезапускає її на прохання — вибір мапи, відновлення з копії)
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
// якщо головний процес зник (закрили програму) — зупиняємось і ми
if (process.send) process.on('disconnect', () => process.exit(0));
const ctx = require('./lib/core');
const { q, q1, run } = ctx, PORT = process.env.PORT || 3000;
const routes = new Map(), R = (method, p, fn, opts = {}) => routes.set(method + ' ' + p, { fn, opts });
const callRouteLater = (m, p, c, b) => { const r = routes.get(m + ' /api/' + p); if (!r) throw new Error('route ' + p); return r.fn({ u: { role: 'bot' }, c, b: b || {}, url: new URL('http://x'), req: null, res: null }); };
ctx.callRoute = callRouteLater;
// обгортка вже зареєстрованого маршруту (напр., парламент перевіряє рішення перед виконанням)
ctx.wrapRoute = (m, p, wrap) => { const r = routes.get(m + ' ' + p); if (!r) throw new Error('no route ' + p); const fn = r.fn; r.fn = (args) => wrap(args, () => fn(args)); };
for (const m of ['facilities', 'rivers', 'econ', 'army', 'logistics', 'intel', 'vassals', 'blocs', 'currency', 'decrees', 'ideology', 'flags', 'diplo', 'botai', 'diplo2', 'world', 'incur', 'armies', 'botlife', 'puppets', 'warfare', 'food', 'civgoods', 'labs', 'business', 'nations', 'airwar', 'confs', 'trade', 'market', 'convoys', 'events', 'parliament', 'llm', 'botchat', 'puppetctl', 'rellog', 'rename', 'embargo', 'court', 'cities', 'diplopts', 'elections', 'aid', 'weather', 'history', 'finance', 'society', 'warplus', 'diplo3', 'volunteers', 'combat2', 'fixes16', 'tech16', 'botdiplo16', 'politics16', 'city16', 'religion16', 'names16', 'prov16', 'world16', 'mob16', 'eqm16', 'rankhide', 'worldev', 'alerts', 'breakdown', 'causes16', 'press16', 'long17', 'world17', 'decay17', 'admin19', 'ctl18', 'happy18', 'gear19', 'tmpl19', 'defco19', 'fix20', 'corp20', 'sanc20', 'mafia20', 'ship20', 'treaty20', 'annex20', 'fix21', 'upd21', 'war21', 'war21b', 'design21', 'bot21', 'bloc21', 'bot22', 'backup', 'maps', 'admin', 'perfcache']) { const pf = ctx.decFx; require('./lib/' + m)(ctx, R); if (ctx.decFx !== pf && m !== 'perfcache') (ctx.fxLayers = ctx.fxLayers || []).push([m, ctx.decFx]); }

const hashPw = (pw, salt) => crypto.scryptSync(pw, salt, 32).toString('hex');
const zlib = require('zlib');
const wantsGz = (res) => /\bgzip\b/.test((res.req && res.req.headers['accept-encoding']) || '');
const json = (res, code, obj) => { const s = JSON.stringify(obj); if (s.length > 1200 && wantsGz(res)) { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Encoding': 'gzip', Vary: 'Accept-Encoding' }); return res.end(zlib.gzipSync(s, { level: 4 })); } res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(s); };
const gzCache = new Map();
const body = (req) => new Promise((ok) => { let b = ''; req.on('data', (c) => { b += c; if (b.length > 2e6) req.destroy(); }); req.on('end', () => { try { ok(JSON.parse(b || '{}')); } catch { ok({}); } }); });
const cookie = (req) => Object.fromEntries((req.headers.cookie || '').split(';').map((s) => s.trim().split('=')).filter((p) => p[0]));
const userOf = (req) => { const t = cookie(req).sid; return t ? q1('SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=?', t) || null : null; };
const session = (res, uid) => { const t = crypto.randomBytes(24).toString('hex'); run('INSERT INTO sessions VALUES(?,?)', t, uid); res.setHeader('Set-Cookie', `sid=${t}; Path=/; HttpOnly; SameSite=Lax; Max-Age=31536000`); };
const rle = () => { const o = [], ow = ctx.owner; let p = ow[0], n = 0; for (let i = 0; i < ctx.N; i++) { if (ow[i] === p) n++; else { o.push(p, n); p = ow[i]; n = 1; } } o.push(p, n); return o; };

// ---------- годинник гри ----------
let last = Date.now();
const night = () => { if (!ctx.setting('nightPause')) return false; const h = new Date().getHours(), a = ctx.setting('nightFrom'), b = ctx.setting('nightTo'); return a < b ? h >= a && h < b : h >= a || h < b; };
const step = (dt, noMove) => ctx.tx(() => { ctx.setDay(ctx.day() + dt); if (!noMove) { try { ctx.tickMove(dt); } catch (e) { console.error('tickMove', e); } } for (const f of ['tickCurrency', 'tickEcon', 'tickArmy', 'tickDiplo', 'tickIntel', 'tickVassals', 'tickConfs', 'tickPolitics', 'tickMarket', 'tickEvents']) { try { ctx[f](dt); } catch (e) { console.error(f, e); } } });
ctx.advance = (days) => { let left = days; while (left > 0) { const d = Math.min(1, left); step(d); left -= d; } ctx.saveDay(); ctx.push('tick'); };
let lastMove = Date.now();
setInterval(() => {
  const now = Date.now(), gap = now - last; last = now;
  if (ctx.setting('paused') || night() || gap > 10 * 60 * 1000) return;
  step(Math.min(gap / 3.6e6 * ctx.setting('timeScale'), 5), true); ctx.saveDay(); ctx.push('tick');
}, 10000);
// рух підрозділів: короткі кроки раз на ~2 с, щоб не стрибали на весь шлях за один тік
setInterval(() => {
  const now = Date.now(), gap = now - lastMove; lastMove = now;
  if (ctx.setting('paused') || night() || gap > 60000) return;
  try { ctx.tx(() => { ctx.tickMove(gap / 3.6e6 * ctx.setting('timeScale')); ctx.botMove && ctx.botMove(); }); } catch (e) { console.error('move', e); }
}, 2000);

// ---------- API ----------
// стан своєї держави для клієнта: лічильники об'єктів і потоки ресурсів рахуються наново, щоб підказки були актуальними
const meCountry = (c) => { const st = ctx.stats(c); ctx.syncFac(c.id, st); const fl = ctx.flows(c, st, ctx.bonusMap(c.id)); st.flow = fl; for (const r of ctx.RES) st.resources[r].prod = fl[r].prod; return { ...ctx.pubCountry(c), stats: st, manpower: ctx.manpower(c, st), popCap: ctx.popCap(c) }; };
async function api(req, res, url) {
  const m = req.method, p = url.pathname, u = userOf(req);
  if (p === '/api/events' && u) return ctx.sse(req, res, u.id);
  if (p === '/api/land') return json(res, 200, ctx.land);
  if (p === '/api/maps') return json(res, 200, ctx.mapsInfo());
  if (p === '/api/ping') return json(res, 200, { map: ctx.MAP.id, restarting: !!ctx.restarting, mapVer: ctx.mapVer, occVer: ctx.occVer || 0, day: ctx.day(), ts: Date.now(), paused: !!(ctx.setting('paused') || night()), scale: ctx.setting('timeScale') });
  if (p === '/api/owners') return json(res, 200, { rle: rle(), countries: ctx.countries().map(ctx.pubCountry) });
  if (p === '/api/register' && m === 'POST') {
    const b = await body(req), name = String(b.name || '').trim(), pw = String(b.password || '');
    if (!/^[\p{L}\p{N}_ -]{3,20}$/u.test(name)) return json(res, 400, { error: 'Нік: 3–20 символів (літери, цифри, _ - пробіл)' });
    if (pw.length < 4) return json(res, 400, { error: 'Пароль має містити мінімум 4 символи' });
    if (q1('SELECT 1 FROM users WHERE name=?', name)) return json(res, 400, { error: 'Цей нік уже зайнятий' });
    // (21) e-mail обов’язковий і унікальний; з однієї адреси — не більше 3 реєстрацій на добу; нові акаунти чекають схвалення адміна (якщо так налаштовано)
    const email = String(b.email || '').trim().toLowerCase();
    if (!/^[^\s@<>]{1,64}@[^\s@<>]{1,120}\.[a-zа-яіїєґ]{2,24}$/iu.test(email)) return json(res, 400, { error: 'Вкажи справжню електронну пошту (наприклад, ім’я@gmail.com)' });
    if (q1('SELECT 1 FROM users WHERE lower(email)=?', email)) return json(res, 400, { error: 'На цю пошту вже зареєстровано акаунт' });
    const ip = String(req.headers['cf-connecting-ip'] || req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim(), dayAgo = Date.now() - 864e5;
    // (21.2) у лобі з кількома іграми адміном гри стає господар сервера (запит із самого комп'ютера-хоста), а не перший зареєстрований
    const LOB = process.env.LOBBY_SECRET, hostReq = LOB ? req.headers['x-sp-local'] === LOB : false;
    const first = LOB ? hostReq : !q1('SELECT 1 FROM users'), salt = crypto.randomBytes(12).toString('hex');
    if (!first && ip && !/^(127\.|::1$|::ffff:127\.)/.test(ip) && q1('SELECT COUNT(*) n FROM users WHERE reg_ip=? AND created>?', ip, dayAgo).n >= 3) return json(res, 429, { error: 'З цієї адреси вже створено 3 акаунти за добу. Спробуй завтра або попроси адміна.' });
    const approved = first || !ctx.setting('approveNew') ? 1 : 0;
    const r = run('INSERT INTO users(name,salt,hash,role,discord,email,approved,reg_ip,created) VALUES(?,?,?,?,?,?,?,?,?)', name, salt, hashPw(pw, salt), first ? 'admin' : 'player', String(b.discord || '').slice(0, 40), email, approved, ip, Date.now()); session(res, Number(r.lastInsertRowid));
    if (!first) for (const a of q("SELECT id FROM users WHERE role='admin'")) ctx.notifyUser ? ctx.notifyUser(a.id, `Новий гравець: ${name} (${email})${approved ? '' : ' — чекає схвалення (Адмін → Гравці)'}.`) : null;
    // перший гравець (адмін) обрав іншу мапу — створюємо світ на ній (сервер перезапуститься сам)
    if (first && !LOB && b.map && String(b.map) !== ctx.MAP.id && ctx.mapsInfo().list.some((x) => x.id === String(b.map))) { ctx.newWorld(String(b.map)); return json(res, 200, { ok: true, restart: true, map: String(b.map) }); }
    return json(res, 200, { ok: true });
  }
  if (p === '/api/login' && m === 'POST') {
    const b = await body(req), r = q1('SELECT * FROM users WHERE name=?', String(b.name || '').trim());
    if (!r || hashPw(String(b.password || ''), r.salt) !== r.hash) return json(res, 400, { error: 'Невірний нік або пароль' }); if (r.banned) return json(res, 403, { error: 'Акаунт заблоковано адміністратором' });
    session(res, r.id); return json(res, 200, { ok: true });
  }
  if (p === '/api/logout' && m === 'POST') { const t = cookie(req).sid; if (t) run('DELETE FROM sessions WHERE token=?', t); return json(res, 200, { ok: true }); }
  if (!u) return json(res, 401, { error: 'Потрібен вхід' }); if (u.banned) return json(res, 403, { error: 'Акаунт заблоковано' });
  const c = ctx.countryOf(u);
  if (p === '/api/flag' && m === 'GET') return ctx.serveFlag(res, +url.searchParams.get('id'));
  if (p === '/api/bloc/emblem' && m === 'GET' && ctx.serveEmblem) return ctx.serveEmblem(res, +url.searchParams.get('id'));
  if (p === '/api/me') return json(res, 200, { lobby: process.env.WORLD_ID ? { id: +process.env.WORLD_ID, name: process.env.WORLD_NAME || '' } : null, user: { id: u.id, name: u.name, role: u.role, approved: u.approved !== 0, email: u.email || '' }, country: c ? meCountry(c) : null, cons: ctx.CONS, world: { day: ctx.day(), paused: !!(ctx.setting('paused') || night()), scale: ctx.setting('timeScale'), ts: Date.now(), mapVer: ctx.mapVer, occVer: ctx.occVer || 0 }, settings: { startSize: ctx.setting('startSize'), minGap: ctx.setting('minGap') }, unread: q1('SELECT COUNT(*) n FROM notifications WHERE user_id=? AND read=0', u.id).n, unreadImp: q1('SELECT COUNT(*) n FROM notifications WHERE user_id=? AND read=0 AND lvl>=2', u.id).n });
  if (p === '/api/preview') { const x = +url.searchParams.get('x'), y = +url.searchParams.get('y'), err = ctx.canFound(x, y); return json(res, 200, err ? { error: err } : { cells: ctx.territory(y * ctx.gw + x, ctx.setting('startSize')) }); }
  if (p === '/api/found' && m === 'POST') {
    if (c) return json(res, 400, { error: 'У тебе вже є держава' }); if (u.approved === 0 && u.role !== 'admin') return json(res, 403, { error: 'Твій акаунт ще не схвалив адміністратор. Держава з’явиться після схвалення — напиши адміну.' }); const b = await body(req), name = String(b.name || '').trim().slice(0, 30), color = String(b.color || '');
    if (name.length < 2) return json(res, 400, { error: 'Введи назву держави (мінімум 2 символи)' }); if (!/^#[0-9a-fA-F]{6}$/.test(color)) return json(res, 400, { error: 'Невірний колір' });
    try { ctx.createCountry({ name, color, ownerId: u.id, x: b.x, y: b.y }); if (b.slant && ctx.SLANTS && ctx.SLANTS[b.slant]) { const nc = ctx.countryOf(u); if (nc) { const st = ctx.stats(nc.id); st.slant = b.slant; ctx.saveStats(nc.id, st); } } } catch (e) { return json(res, e.code || 500, { error: e.message }); } ctx.push('state'); return json(res, 200, { ok: true });
  }
  const route = routes.get(m + ' ' + p);
  // дії від імені маріонетки: сюзерен керує її зовнішньою політикою (?as=<id маріонетки>)
  let cc = c, actAs = null; { const asId = +(url.searchParams.get('as') || req.headers['x-act-as'] || 0);
    if (asId && c && asId !== c.id) { const v = ctx.vassalRow(asId); if (!v || v.master !== c.id || v.kind !== 'puppet') return json(res, 403, { error: 'Це не ваша маріонетка' }); if (!ctx.PUPPET_ROUTES.some((x) => p.startsWith(x))) return json(res, 403, { error: 'Від імені маріонетки доступна лише зовнішня політика' }); cc = ctx.country(asId); actAs = { master: c.id, puppet: asId }; } }
  if (route) {
    if (route.opts.admin && u.role !== 'admin') return json(res, 403, { error: 'Лише для адміна' });
    const b = m === 'POST' ? await body(req) : {};
    try { ctx.actAs = actAs; const out = route.opts.notx ? await route.fn({ u, c: cc, b, url, req, res, actAs }) : await ctx.tx(() => route.fn({ u, c: cc, b, url, req, res, actAs })); ctx.actAs = null; if (actAs && m === 'POST') ctx.notify(actAs.puppet, `Сюзерен ${ctx.cname(actAs.master)} діє від вашого імені: ${p.replace('/api/', '')}.`); if (route.opts.admin && m === 'POST') ctx.audit(u.name, `${p} ${JSON.stringify(b).slice(0, 220)}`); return json(res, 200, out || { ok: true }); }
    catch (e) { ctx.actAs = null; const code = typeof e.code === 'number' ? e.code : 0; if (!code) console.error(p, e); return json(res, code || 500, { error: code ? e.message : 'Помилка сервера' }); }
  }
  json(res, 404, { error: 'Не знайдено' });
}
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css', '.png': 'image/png', '.svg': 'image/svg+xml', '.webp': 'image/webp', '.jpg': 'image/jpeg', '.webmanifest': 'application/manifest+json', '.json': 'application/json', '.ico': 'image/x-icon' };
// (21.1) версія гри: програма (Electron) старішої версії не може зайти — спершу оновлення
const GAME_VER = require('./package.json').version, DL_PAGE = 'https://github.com/oleksandrlys05-debug/svitova-polityka#readme';
const verCmp = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d; } return 0; };
ctx.GAME_VER = GAME_VER;
const oldApp = (req) => { const ua = String(req.headers['user-agent'] || ''); if (!/Electron\//.test(ua)) return null; const toks = [...ua.matchAll(/SvitovaPolityka\/([\d.]+)/g)].map((x) => x[1]).sort((a, b) => verCmp(b, a)), self = toks.length >= 2, v = toks[0] || '0'; return verCmp(v, GAME_VER) < 0 ? (self ? v : 'стара') : null; };
const oldPage = (v) => `<!DOCTYPE html><html lang="uk"><head><meta charset="utf-8"><title>Потрібне оновлення</title><style>body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#0f0d1a;color:#ece9f7;font:16px/1.6 "Segoe UI",system-ui,sans-serif}.b{max-width:620px;background:#1b1830;border:1px solid #2e2a48;border-radius:20px;padding:28px 32px}h1{margin:0 0 10px;font-size:26px}a{color:#c4a5ff}code{background:#120f22;padding:2px 6px;border-radius:6px}</style></head><body><div class="b"><h1>Спершу оновіть гру</h1><p>На сервері версія <b>${GAME_VER}</b>, а у вашій програмі — <b>${v}</b>. Зі старою версією зайти не можна.</p>${v === 'стара' ? `<p>Ваша програма ще не вміє оновлюватися сама. Один раз завантажте нову версію тут: <a href="${DL_PAGE}">${DL_PAGE}</a> (розпакуйте поверх старої — збереження не зникнуть). Далі гра оновлюватиметься автоматично.</p>` : '<p>Закрийте програму й відкрийте знову — на головному екрані натисніть <b>«Оновити зараз»</b>. Це кілька секунд, збереження не зачіпаються.</p>'}</div></body></html>`;
http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x');
    if (url.pathname === '/api/version') return json(res, 200, { version: GAME_VER, game: 'svitova-polityka' });
    // (21.2) коротка довідка для лобі (лише з секретом лобі)
    if (url.pathname === '/api/lobbyinfo') { if (!process.env.LOBBY_SECRET || req.headers['x-sp-secret'] !== process.env.LOBBY_SECRET) return json(res, 403, { error: 'ні' });
      const hum = q("SELECT COUNT(*) n FROM countries WHERE is_bot=0")[0].n, us = q('SELECT COUNT(*) n FROM users')[0].n, bots = q('SELECT COUNT(*) n FROM countries WHERE is_bot=1')[0].n;
      return json(res, 200, { day: Math.floor(ctx.day()), users: us, players: hum, bots, map: ctx.MAP.id, paused: !!ctx.setting('paused') }); }
    { const ov = oldApp(req); if (ov && url.pathname !== '/api/ping') { if (url.pathname.startsWith('/api/')) return json(res, 426, { error: `Спершу оновіть гру: на сервері версія ${GAME_VER}, у вас ${ov}.`, update: GAME_VER }); if (url.pathname === '/' || url.pathname.endsWith('.html')) { res.writeHead(426, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' }); return res.end(oldPage(ov)); } } }
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);
    const root = path.join(__dirname, 'public'), f = path.join(root, url.pathname === '/' ? 'index.html' : path.normalize(url.pathname).replace(/^(\.\.[/\\])+/, ''));
    if (!f.startsWith(root) || !fs.existsSync(f) || fs.statSync(f).isDirectory()) { res.writeHead(404); return res.end('404'); }
    const st = fs.statSync(f), etag = `W/"${st.size}-${Math.round(st.mtimeMs)}"`, ext = path.extname(f), hd = { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': ext === '.png' || ext === '.svg' || ext === '.webp' ? 'public, max-age=86400' : 'no-cache', ETag: etag };
    if (req.headers['if-none-match'] === etag) { res.writeHead(304, hd); return res.end(); }
    if (['.html', '.js', '.css', '.svg'].includes(ext) && /\bgzip\b/.test(req.headers['accept-encoding'] || '')) { let z = gzCache.get(f); if (!z || z.etag !== etag) { z = { etag, buf: zlib.gzipSync(fs.readFileSync(f), { level: 9 }) }; gzCache.set(f, z); } res.writeHead(200, { ...hd, 'Content-Encoding': 'gzip', Vary: 'Accept-Encoding' }); return res.end(z.buf); }
    res.writeHead(200, hd); fs.createReadStream(f).pipe(res);
  } catch (e) { console.error(e); if (!res.headersSent) json(res, 500, { error: 'Помилка сервера' }); }
}).listen(PORT, process.env.LOBBY_SECRET ? '127.0.0.1' : undefined, () => console.log(`Сервер запущено: http://localhost:${PORT}`));
