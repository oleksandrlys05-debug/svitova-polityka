// Світова політика — програма для Windows (Electron). Завантажується з main.js (запускача) — вбудована або оновлена версія.
// Режими: «Створити гру» (сервер працює всередині програми + тунель «Поділитися грою») і «Підключитися до гри» (за посиланням чи адресою)
const { app, BrowserWindow, ipcMain, dialog, Menu, clipboard, shell, nativeImage } = require('electron');
const path = require('path'), fs = require('fs'), os = require('os'), http = require('http'), https = require('https'), zlib = require('zlib'), crypto = require('crypto'), { spawn } = require('child_process');
const SP = global.SP || { appDir: __dirname, gameDir: null, builtinDir: __dirname, updDir: null };
const VER = require('./package.json').version, BUILTIN_VER = (() => { try { return require(path.join(SP.builtinDir, 'package.json')).version; } catch { return VER; } })();

app.setName('Svitova Polityka');
if (!app.requestSingleInstanceLock()) { app.quit(); process.exit(0); }

const RES = app.isPackaged ? process.resourcesPath : path.join(__dirname, '..');
const GAME = SP.gameDir || (app.isPackaged ? path.join(RES, 'game') : path.join(__dirname, '..'));
const CF = path.join(RES, process.platform === 'win32' ? 'cloudflared.exe' : 'cloudflared');
const USER = app.getPath('userData'), DATA = path.join(USER, 'data'), SETF = path.join(USER, 'settings.json'), LOGF = path.join(USER, 'server.log');
const ICON = path.join(__dirname, 'icon.png');
fs.mkdirSync(DATA, { recursive: true });

let win = null, server = null, tunnel = null, mode = null, port = 3000, shareUrl = '', quitting = false, tunnelState = 'off', tunnelErr = '';
const S = (() => { try { return JSON.parse(fs.readFileSync(SETF, 'utf8')); } catch { return {}; } })();
const saveS = () => { try { fs.writeFileSync(SETF, JSON.stringify(S, null, 1)); } catch { /* ні */ } };
const log = (s) => { try { fs.appendFileSync(LOGF, `[${new Date().toISOString()}] ${s}\n`); } catch { /* ні */ } };
const lanIps = () => Object.values(os.networkInterfaces()).flat().filter((i) => i && i.family === 'IPv4' && !i.internal).map((i) => i.address);
// інформація для гри: посилання для друзів (сервер віддає її адміну в грі)
const writeShare = () => { try { fs.writeFileSync(path.join(DATA, 'share.json'), JSON.stringify({ tunnel: shareUrl, state: tunnelState, err: tunnelErr, lan: lanIps().map((ip) => `http://${ip}:${port}`), port, at: Date.now() })); } catch { /* ні */ } };
const send = (ch, d) => { if (win && !win.isDestroyed()) win.webContents.send(ch, d); };

// ---------- сервер ----------
const ping = (p) => new Promise((ok) => { const r = http.get({ host: '127.0.0.1', port: p, path: '/api/ping', timeout: 1500 }, (res) => { res.resume(); ok(true); }); r.on('error', () => ok(false)); r.on('timeout', () => { r.destroy(); ok(false); }); });
const startServer = (p) => new Promise((resolve, reject) => {
  port = p; let out = '', done = false;
  server = spawn(process.execPath, [path.join(GAME, 'server.js')], { cwd: GAME, env: { ...process.env, ELECTRON_RUN_AS_NODE: '1', PORT: String(p), GAME_DATA: DATA, NODE_NO_WARNINGS: '1' }, windowsHide: true });
  const onData = (b) => { const t = b.toString(); out = (out + t).slice(-4000); log('server: ' + t.trim()); };
  server.stdout.on('data', onData); server.stderr.on('data', onData);
  server.on('exit', (code) => { log('server exit ' + code); const restore = fs.existsSync(path.join(DATA, 'restore.json')); server = null;
    if (!done) { done = true; return reject(new Error(/EADDRINUSE/.test(out) ? `Порт ${p} зайнятий іншою програмою. Оберіть інший порт.` : `Сервер не запустився:\n${out.slice(-800)}`)); }
    if (quitting) return;
    if (restore) { startServer(p).then(() => { if (win) win.loadURL(`http://localhost:${p}/`); }).catch((e) => dialog.showErrorBox('Помилка', e.message)); return; } // відновлення з резервної копії
    dialog.showMessageBox(win, { type: 'error', title: 'Сервер зупинився', message: 'Сервер гри несподівано зупинився.', detail: out.slice(-800), buttons: ['Перезапустити', 'Закрити'] }).then((r) => { if (r.response === 0) startServer(p).then(() => win && win.reload()).catch((e) => dialog.showErrorBox('Помилка', e.message)); });
  });
  (async () => { for (let i = 0; i < 60 && !done; i++) { if (await ping(p)) { done = true; return resolve(); } await new Promise((r) => setTimeout(r, 400)); } if (!done) { done = true; reject(new Error('Сервер не відповідає. Подробиці у файлі server.log')); } })();
});
const stopServer = () => { if (server) { try { server.kill(); } catch { /* ні */ } server = null; } };

// ---------- тунель Cloudflare (безкоштовне посилання для друзів, без VPN і налаштувань роутера) ----------
const startTunnel = () => {
  stopTunnel(); if (!fs.existsSync(CF)) { tunnelState = 'error'; tunnelErr = 'Не знайдено cloudflared.exe поруч із програмою'; writeShare(); send('share', shareInfo()); return; }
  tunnelState = 'starting'; tunnelErr = ''; shareUrl = ''; writeShare(); send('share', shareInfo());
  tunnel = spawn(CF, ['tunnel', '--no-autoupdate', '--url', `http://localhost:${port}`], { windowsHide: true });
  const onData = (b) => { const t = b.toString(); log('tunnel: ' + t.trim()); const m = t.match(/https:\/\/[a-z0-9-]+\.trycloudflare\.com/); if (m && !shareUrl) { shareUrl = m[0]; tunnelState = 'on'; writeShare(); send('share', shareInfo()); shareDialog(true); } };
  tunnel.stdout.on('data', onData); tunnel.stderr.on('data', onData);
  tunnel.on('exit', (code) => { log('tunnel exit ' + code); tunnel = null; if (quitting) return; if (tunnelState !== 'off') { tunnelState = 'error'; tunnelErr = 'Тунель закрився. Перевірте інтернет і натисніть «Перезапустити тунель».'; shareUrl = ''; writeShare(); send('share', shareInfo()); } });
  setTimeout(() => { if (tunnelState === 'starting') { tunnelErr = 'Тунель запускається довше, ніж зазвичай (перевірте інтернет чи антивірус).'; writeShare(); send('share', shareInfo()); } }, 30000);
};
const stopTunnel = () => { if (tunnel) { const t = tunnel; tunnel = null; tunnelState = 'off'; try { t.kill(); } catch { /* ні */ } } shareUrl = ''; };
const shareInfo = () => ({ url: shareUrl, state: tunnelState, err: tunnelErr, lan: lanIps().map((ip) => `http://${ip}:${port}`), port });
const shareDialog = async (auto) => {
  if (mode !== 'host') return; const s = shareInfo();
  const detail = (s.url ? `Посилання для друзів (інтернет):\n${s.url}\n\nНадішліть його друзям у Discord. Вони відкривають його в браузері або в цій програмі («Підключитися до гри»). Після перезапуску програми посилання буде нове.` : s.state === 'starting' ? 'Тунель ще запускається… Зачекайте кілька секунд.' : `Тунель вимкнено.${s.err ? '\n' + s.err : ''}`) + (s.lan.length ? `\n\nУ тій самій мережі (Wi-Fi, квартира):\n${s.lan.join('\n')}` : '');
  const buttons = s.url ? ['Скопіювати посилання', 'Закрити'] : ['Запустити тунель', 'Закрити'];
  const r = await dialog.showMessageBox(win, { type: 'info', title: 'Поділитися грою', message: auto ? 'Гру відкрито для друзів!' : 'Поділитися грою', detail, buttons, defaultId: 0, cancelId: 1 });
  if (r.response === 0) { if (s.url) clipboard.writeText(s.url); else startTunnel(); }
};

// ---------- (21.1) оновлення: перевірка на GitHub, малий пакет (лише гра й оболонка), резервна копія, перезапуск ----------
app.userAgentFallback = `${app.userAgentFallback} SvitovaPolityka/${VER}`;
const cmp = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d; } return 0; };
const UPD_URL = S.updUrl || process.env.SP_UPDATE_URL || 'https://raw.githubusercontent.com/oleksandrlys05-debug/svitova-polityka/main/release/latest.json';
const UPD = { state: 'idle', latest: null, err: '', pct: 0 }; let updCheck = null;
const updInfo = () => ({ state: UPD.state, version: VER, latest: UPD.latest ? { version: UPD.latest.version, notes: UPD.latest.notes || [], page: UPD.latest.page || '' } : null, err: UPD.err, pct: UPD.pct });
const fetchBuf = (url, { timeout = 10000, max = 300e6, onProgress, redirects = 5 } = {}) => new Promise((resolve, reject) => {
  const lib = url.startsWith('https:') ? https : http, r = lib.get(url, { timeout, headers: { 'User-Agent': `SvitovaPolityka/${VER}`, 'Cache-Control': 'no-cache' } }, (res) => {
    if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && redirects > 0) { res.resume(); return resolve(fetchBuf(new URL(res.headers.location, url).href, { timeout, max, onProgress, redirects: redirects - 1 })); }
    if (res.statusCode !== 200) { res.resume(); return reject(Object.assign(new Error(`HTTP ${res.statusCode}`), { status: res.statusCode })); }
    const total = +res.headers['content-length'] || 0, parts = []; let n = 0;
    res.on('data', (c) => { n += c.length; if (n > max) { r.destroy(); return reject(new Error('Файл завеликий')); } parts.push(c); if (onProgress && total) onProgress(n / total); });
    res.on('end', () => resolve(Buffer.concat(parts))); res.on('error', reject); });
  r.on('timeout', () => r.destroy(new Error('Немає відповіді (перевірте інтернет)'))); r.on('error', reject); });
const checkUpdate = () => { if (updCheck) return updCheck; UPD.state = 'checking'; UPD.err = ''; send('upd', updInfo());
  updCheck = (async () => { try { const j = JSON.parse((await fetchBuf(`${UPD_URL}${UPD_URL.includes('?') ? '&' : '?'}t=${Date.now()}`, { timeout: 9000, max: 2e6 })).toString('utf8')); UPD.latest = j;
      UPD.state = cmp(j.version, VER) > 0 ? (j.minApp && cmp(j.minApp, BUILTIN_VER) > 0 ? 'full' : 'available') : 'ok'; log(`оновлення: у нас ${VER}, найновіша ${j.version} → ${UPD.state}`); }
    catch (e) { UPD.state = 'offline'; UPD.err = e.message; log('оновлення: не вдалося перевірити — ' + e.message); }
    finally { updCheck = null; send('upd', updInfo()); } return updInfo(); })(); return updCheck; };
const rmrf = (p) => { try { fs.rmSync(p, { recursive: true, force: true }); } catch { /* ні */ } };
const applyUpdate = async () => {
  const j = UPD.latest; if (!j || UPD.state !== 'available') throw new Error('Оновлення немає');
  if (mode === 'host') { stopTunnel(); stopServer(); }
  UPD.state = 'downloading'; UPD.pct = 0; send('upd', updInfo());
  try {
    const url = new URL(j.pkg, UPD_URL).href, buf = await fetchBuf(`${url}${url.includes('?') ? '&' : '?'}t=${Date.now()}`, { timeout: 30000, max: 200e6, onProgress: (p) => { UPD.pct = Math.round(p * 100); send('upd', updInfo()); } });
    if (j.sha256 && crypto.createHash('sha256').update(buf).digest('hex') !== j.sha256) throw new Error('Файл оновлення пошкоджений (не збігається контрольна сума). Спробуйте ще раз.');
    UPD.state = 'installing'; send('upd', updInfo());
    // формат пакета: gzip( "SPKG1\n" + 4 байти довжини заголовка + JSON {version, files:[[шлях, розмір]]} + вміст файлів підряд )
    const raw = zlib.gunzipSync(buf); if (raw.slice(0, 6).toString() !== 'SPKG1\n') throw new Error('Неправильний пакет оновлення');
    const hl = raw.readUInt32LE(6), pkg = JSON.parse(raw.slice(10, 10 + hl).toString('utf8')); if (!Array.isArray(pkg.files) || !pkg.version || cmp(pkg.version, VER) <= 0) throw new Error('Неправильний пакет оновлення');
    const dirName = `v${pkg.version}`, D = path.join(SP.updDir, dirName), T = D + '.tmp'; rmrf(T); fs.mkdirSync(T, { recursive: true });
    let off = 10 + hl; for (const [rel, size] of pkg.files) { const data = raw.slice(off, off + size); off += size; if (data.length !== size) throw new Error('Пакет оновлення обрізаний'); const norm = path.normalize(rel); if (norm.startsWith('..') || path.isAbsolute(norm) || !/^(app|game)[\\/]/.test(norm)) continue; const f = path.join(T, norm); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, data); }
    if (!fs.existsSync(path.join(T, 'app', 'core.js')) || !fs.existsSync(path.join(T, 'game', 'game.js'))) throw new Error('Пакет оновлення неповний');
    // резервна копія збереження перед оновленням
    const db = path.join(DATA, 'game.db'); if (fs.existsSync(db)) { const bk = path.join(DATA, 'backups'); fs.mkdirSync(bk, { recursive: true }); fs.copyFileSync(db, path.join(bk, `before-update-${pkg.version}-${Date.now()}.db`)); }
    rmrf(D); fs.renameSync(T, D);
    let prev = null; try { prev = JSON.parse(fs.readFileSync(path.join(SP.updDir, 'current.json'), 'utf8')).dir; } catch { /* ні */ }
    fs.writeFileSync(path.join(SP.updDir, 'current.json'), JSON.stringify({ version: pkg.version, dir: dirName, at: Date.now() }));
    for (const x of fs.readdirSync(SP.updDir)) if (x !== dirName && x !== prev && x !== 'current.json') rmrf(path.join(SP.updDir, x)); // лишаємо нову й попередню
    log(`оновлено до ${pkg.version}`); UPD.state = 'done'; send('upd', updInfo());
    setTimeout(() => { quitting = true; app.relaunch(); app.exit(0); }, 900); return { ok: true };
  } catch (e) { UPD.state = 'available'; UPD.err = e.message; send('upd', { ...updInfo(), state: 'error' }); log('оновлення не вдалося: ' + e.message); throw e; }
};
// перед грою: оновлення обов’язкове (якщо інтернету немає — дозволяємо грати як є)
const needUpdateGate = async () => { if (UPD.state === 'idle' || UPD.state === 'checking') await checkUpdate();
  if (UPD.state === 'available') throw new Error(`Вийшло оновлення ${UPD.latest.version}. Спершу натисніть «Оновити зараз» — це кілька секунд, збереження не зачіпаються.`);
  if (UPD.state === 'full') throw new Error(`Вийшла версія ${UPD.latest.version}, для неї треба один раз завантажити програму заново (кнопка «Завантажити»).`); };
// версія хоста: до старого чи новішого сервера не підключаємось
const hostVersion = (url) => fetchBuf(new URL('api/version', url).href, { timeout: 7000, max: 1e5 }).then((b) => { try { return JSON.parse(b.toString('utf8')).version || '0'; } catch { return '0'; } }, (e) => (e.status === 404 ? '0' : null));

// ---------- вікно й меню ----------
const loadLauncher = (err) => { mode = null; buildMenu(); win.loadFile(path.join(__dirname, 'launcher.html'), { query: err ? { err } : {} }); };
function buildMenu() {
  const T = [
    { label: 'Гра', submenu: [
      { label: 'Головне меню програми', click: async () => { if (mode === 'host' && !(await confirmStop())) return; stopTunnel(); stopServer(); loadLauncher(); } },
      { label: 'Оновити сторінку', accelerator: 'F5', click: () => win && win.reload() },
      { label: 'На весь екран', accelerator: 'F11', click: () => win && win.setFullScreen(!win.isFullScreen()) },
      { label: 'Масштаб +', accelerator: 'CmdOrCtrl+=', click: () => win && win.webContents.setZoomLevel(win.webContents.getZoomLevel() + 0.5) },
      { label: 'Масштаб −', accelerator: 'CmdOrCtrl+-', click: () => win && win.webContents.setZoomLevel(win.webContents.getZoomLevel() - 0.5) },
      { label: 'Масштаб 100%', accelerator: 'CmdOrCtrl+0', click: () => win && win.webContents.setZoomLevel(0) },
      { type: 'separator' }, { label: 'Вихід', role: 'quit' }] },
  ];
  if (mode === 'host') T.push({ label: 'Сервер', submenu: [
    { label: 'Поділитися грою…', accelerator: 'CmdOrCtrl+Shift+S', click: () => shareDialog(false) },
    { label: 'Скопіювати посилання для друзів', click: () => { if (shareUrl) clipboard.writeText(shareUrl); else shareDialog(false); } },
    { label: 'Перезапустити тунель', click: () => startTunnel() },
    { type: 'separator' },
    { label: 'Відкрити теку зі збереженнями', click: () => shell.openPath(DATA) },
    { label: 'Журнал сервера', click: () => shell.openPath(LOGF) }] });
  T.push({ label: 'Довідка', submenu: [{ label: 'Інструменти розробника', accelerator: 'CmdOrCtrl+Shift+I', click: () => win && win.webContents.toggleDevTools() }, { label: 'Про програму', click: () => dialog.showMessageBox(win, { title: 'Про програму', message: `Світова політика ${VER}`, detail: `Збереження: ${DATA}\nElectron ${process.versions.electron}, Node ${process.versions.node}` }) }] });
  Menu.setApplicationMenu(Menu.buildFromTemplate(T));
}
const confirmStop = async () => { const r = await dialog.showMessageBox(win, { type: 'question', title: 'Зупинити сервер?', message: 'Ви — хост гри. Якщо вийти, сервер зупиниться і друзі відключаться.', detail: 'Гру збережено автоматично — наступного разу все продовжиться з того ж місця.', buttons: ['Вийти', 'Скасувати'], defaultId: 1, cancelId: 1 }); return r.response === 0; };

function createWindow() {
  win = new BrowserWindow({ width: 1500, height: 920, minWidth: 1000, minHeight: 640, backgroundColor: '#0f0d1a', title: 'Світова політика', icon: fs.existsSync(ICON) ? nativeImage.createFromPath(ICON) : undefined, show: false,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, spellcheck: false } });
  win.once('ready-to-show', () => { win.maximize(); win.show(); });
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
  win.webContents.on('did-fail-load', (e, code, desc, url, isMain) => { if (isMain && mode === 'join' && code !== -3) loadLauncher(`Не вдалося підключитися до ${url} (${desc}). Перевірте адресу й чи запущена гра в хоста.`); });
  win.on('close', async (e) => { if (quitting || mode !== 'host') return; e.preventDefault(); if (await confirmStop()) { quitting = true; app.quit(); } });
  win.on('page-title-updated', (e) => e.preventDefault());
  loadLauncher();
}

// ---------- запити з головного меню програми (лише зі сторінки лаунчера, не з сайту гри) ----------
const local = (e) => { const u = (e.senderFrame && e.senderFrame.url) || ''; if (!u.startsWith('file:')) throw new Error('Недоступно'); };
const normAddr = (a) => { let s = String(a || '').trim(); if (!s) throw new Error('Введіть посилання чи адресу'); if (!/^https?:\/\//i.test(s)) s = (/trycloudflare\.com|\.(com|net|org|io|app|dev)\b/i.test(s) ? 'https://' : 'http://') + s;
  const u = new URL(s); if (u.protocol === 'http:' && !u.port && /^\d+\.\d+\.\d+\.\d+$/.test(u.hostname)) u.port = '3000'; return u.origin + '/'; };
ipcMain.handle('settings', () => ({ ...S, version: VER, upd: updInfo(), dataDir: DATA, hasSave: fs.existsSync(path.join(DATA, 'game.db')), lan: lanIps(), hasCf: fs.existsSync(CF) }));
ipcMain.handle('host', async (e, o) => { local(e); await needUpdateGate();
  const p = Math.max(1024, Math.min(65535, Math.round(+o.port || 3000))); S.mode = 'host'; S.port = p; S.share = !!o.share; saveS();
  stopServer(); await startServer(p); mode = 'host'; buildMenu(); win.loadURL(`http://localhost:${p}/`); writeShare();
  if (o.share) startTunnel(); else { tunnelState = 'off'; writeShare(); } return { ok: true };
});
ipcMain.handle('join', async (e, a) => { local(e); const url = normAddr(a); await needUpdateGate();
  const hv = await hostVersion(url); if (hv !== null && cmp(hv, VER) < 0) throw new Error(`У хоста стара версія гри (${hv === '0' ? 'до 21.1' : hv}), у вас ${VER}. Попросіть хоста оновити гру — тоді підключитесь.`);
  if (hv !== null && cmp(hv, VER) > 0) { checkUpdate(); throw new Error(`У хоста новіша версія (${hv}), у вас ${VER}. Спершу оновіть гру.`); } S.mode = 'join'; S.addr = url; S.recent = [url, ...(S.recent || []).filter((x) => x !== url)].slice(0, 6); saveS(); mode = 'join'; buildMenu(); win.loadURL(url); return { ok: true, url }; });
ipcMain.handle('openData', (e) => { local(e); return shell.openPath(DATA); });
ipcMain.handle('importSave', async (e) => { local(e);
  const r = await dialog.showOpenDialog(win, { title: 'Оберіть файл game.db з теки data браузерної версії', filters: [{ name: 'База гри', extensions: ['db'] }], properties: ['openFile'] }); if (r.canceled || !r.filePaths[0]) return { ok: false };
  const dst = path.join(DATA, 'game.db'); if (fs.existsSync(dst)) { const bk = path.join(DATA, 'backups'); fs.mkdirSync(bk, { recursive: true }); fs.copyFileSync(dst, path.join(bk, `before-import-${Date.now()}.db`)); }
  for (const x of ['-wal', '-shm']) try { fs.unlinkSync(dst + x); } catch { /* ні */ } fs.copyFileSync(r.filePaths[0], dst); return { ok: true };
});
// у грі: адмін бачить кнопку «Поділитися»
ipcMain.handle('checkUpdate', (e) => { local(e); return checkUpdate(); });
ipcMain.handle('update', (e) => { local(e); return applyUpdate(); });
ipcMain.handle('openPage', (e, u) => { local(e); if (/^https:\/\/github\.com\//.test(String(u))) shell.openExternal(String(u)); return true; });
ipcMain.handle('toLauncher', async () => { if (mode === 'host' && !(await confirmStop())) return false; stopTunnel(); stopServer(); loadLauncher(); return true; });
ipcMain.handle('shareInfo', () => (mode === 'host' ? shareInfo() : null));
ipcMain.handle('shareDialog', () => shareDialog(false));
ipcMain.handle('copy', (e, t) => { clipboard.writeText(String(t || '')); return true; });
ipcMain.handle('restartTunnel', () => { if (mode === 'host') startTunnel(); return true; });

app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
app.whenReady().then(() => { createWindow(); checkUpdate(); setInterval(() => { if (!mode) checkUpdate(); }, 30 * 60 * 1000); });
app.on('before-quit', () => { quitting = true; stopTunnel(); stopServer(); try { fs.unlinkSync(path.join(DATA, 'share.json')); } catch { /* ні */ } });
app.on('window-all-closed', () => app.quit());
