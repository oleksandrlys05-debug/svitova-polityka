// Міст між сторінками й програмою: лаунчер (хост/підключення) і кнопка «Поділитися» в грі
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('desktop', {
  isApp: true,
  settings: () => ipcRenderer.invoke('settings'),
  host: (o) => ipcRenderer.invoke('host', o),
  join: (a) => ipcRenderer.invoke('join', a),
  openData: () => ipcRenderer.invoke('openData'),
  importSave: () => ipcRenderer.invoke('importSave'),
  shareInfo: () => ipcRenderer.invoke('shareInfo'),
  shareDialog: () => ipcRenderer.invoke('shareDialog'),
  copy: (t) => ipcRenderer.invoke('copy', t),
  restartTunnel: () => ipcRenderer.invoke('restartTunnel'),
  onShare: (fn) => ipcRenderer.on('share', (e, d) => fn(d)),
  // (21.1) оновлення
  checkUpdate: () => ipcRenderer.invoke('checkUpdate'),
  update: () => ipcRenderer.invoke('update'),
  openPage: (u) => ipcRenderer.invoke('openPage', u),
  onUpd: (fn) => ipcRenderer.on('upd', (e, d) => fn(d)),
  toLauncher: () => ipcRenderer.invoke('toLauncher'),
});
