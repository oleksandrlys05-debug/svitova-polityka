// Світова політика — запускач програми (Electron).
// Якщо програма вже завантажила оновлення (тека «update» поруч зі збереженнями), запускає новішу версію; інакше — вбудовану.
// Сам цей файл оновлюється лише з повним архівом програми.
const { app } = require('electron');
const path = require('path'), fs = require('fs');
app.setName('Svitova Polityka');
const cmp = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d; } return 0; };
const U = path.join(app.getPath('userData'), 'update');
let appDir = __dirname, gameDir = null;
try {
  const cur = JSON.parse(fs.readFileSync(path.join(U, 'current.json'), 'utf8')), D = path.join(U, String(cur.dir || '').replace(/[\\/]/g, ''));
  if (cmp(cur.version, require('./package.json').version) > 0 && fs.existsSync(path.join(D, 'app', 'core.js')) && fs.existsSync(path.join(D, 'game', 'game.js'))) { appDir = path.join(D, 'app'); gameDir = path.join(D, 'game'); }
} catch { /* оновлень ще немає */ }
global.SP = { appDir, gameDir, builtinDir: __dirname, updDir: U };
try { require(path.join(appDir, 'core.js')); }
catch (e) {
  if (appDir === __dirname) throw e;
  // оновлення пошкоджене — повертаємось до вбудованої версії
  try { fs.unlinkSync(path.join(U, 'current.json')); } catch { /* ні */ }
  try { fs.appendFileSync(path.join(app.getPath('userData'), 'server.log'), `[${new Date().toISOString()}] оновлення не запустилось: ${e.stack}\n`); } catch { /* ні */ }
  app.relaunch(); app.exit(0);
}
